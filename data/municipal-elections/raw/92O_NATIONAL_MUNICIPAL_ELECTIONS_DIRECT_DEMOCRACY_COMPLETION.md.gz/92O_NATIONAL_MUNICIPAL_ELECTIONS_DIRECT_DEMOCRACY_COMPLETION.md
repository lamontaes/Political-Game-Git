# 92O_NATIONAL_MUNICIPAL_ELECTIONS_DIRECT_DEMOCRACY_COMPLETION — 2026-09-05
**Comprehensive 50-State Statutory Frameworks, Charter Variations, Electoral Mechanics, and Direct Democracy Architectures for American Municipal Governance**

- **Document Identifier:** `92O_NATIONAL_MUNICIPAL_ELECTIONS_DIRECT_DEMOCRACY_COMPLETION — 2026-09-05`
- **Research Lane:** Antigravity (Google DeepMind)
- **As-Of / Retrieval Date:** 2026-09-05
- **Temporal Target:** Current 2026 Legal Baseline (incorporating recent statutes: Virginia 2021 municipal November election consolidation § 24.2-222.1, California Voter Participation Rights Act SB 415, Idaho 2020/2022 Boise district mandates § 50-707A, Portland Oregon 2024 STV charter reform, Fargo ND / St. Louis MO approval voting implementations, Chicago mayor recall authorization 10 ILCS 5/21A, and latest statutory codifications)
- **Primary Consumers:**
  1. `#98 Municipal Governance` (Jurisdiction authority, charter selection, office schemas)
  2. `Local Candidacy & Elections Engine` (`src/simulation/election-contests.ts` and future local modules)
  3. `Future Local Political Life` (Career milestones, mayoral appointments, ward politics, council workflows)
- **Companion Machine Artifact:** [`92O_NATIONAL_MUNICIPAL_ELECTIONS_DIRECT_DEMOCRACY.json`](file:///Users/lamontae/Documents/PG%20AntiGravity/docs/research/92O_NATIONAL_MUNICIPAL_ELECTIONS_DIRECT_DEMOCRACY.json) (356 KB, 51 validated jurisdictions)
- **Controlling Project Authorities:**
  - Game Constitution (Principles 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 19, 22, 24, 25, 26, 27, 29, 31, 32)
  - Decision Log (D-001 through D-074)
  - `docs/research/92I_ANTIGRAVITY_KENTUCKY_MUNICIPAL_GOVERNANCE_IMPLEMENTATION_CARGO — 2026-09-05.md` (Kentucky worked example)
  - `docs/research/92J_ANTIGRAVITY_KENTUCKY_LOCAL_POLITICAL_CAREER_AND_GOVERNANCE_IMPLEMENTATION_RESEARCH — 2026-09-05.md`
- **Operational Mode:** Grounded Legal, Institutional, and Simulation-System Research Only. No source code modifications in `src/`. No pull requests. No GitHub edits. Zero forbidden metrics.
- **Epistemic Classification Standard:**
  - `[FACT]`: Verified empirical constitutional article, statutory code, municipal charter, or official election board rule.
  - `[SOURCE]`: Explicit citation of first-party legal authority, exact section/statute, and effective vintage.
  - `[INFERENCE]`: Institutional deduction, mechanical game logic translation, or procedural workflow derived from established municipal practice.
  - `[PRODUCT RECOMMENDATION]`: Concrete architectural data model, state schema field, or gameplay rule-pack specification for *Our Civic Duty*.
  - `[UNRESOLVED]`: Specific statutory ambiguity, pending judicial challenge, or unresolved municipal boundary edge case.

---

## TABLE OF CONTENTS
1. [Executive Summary & National Research Scope](#1-executive-summary--national-research-scope)
2. [Comparative Typological Syntheses Across 8 Core Modules](#2-comparative-typological-syntheses-across-8-core-modules)
   - 2.1 Partisan vs. Nonpartisan Balloting Landscape & Vacancy Succession
   - 2.2 Election Timing & Calendar Consolidation
   - 2.3 Representation Architectures: Wards, At-Large, and Proportional Systems
   - 2.4 Executive Selection: Strong Mayor vs. Council Selection vs. Selectboards
   - 2.5 Runoff, Plurality, and Majority Threshold Rules
   - 2.6 Municipal Recall Architectures & Retention Barriers
   - 2.7 Municipal Initiative & Protest Referenda
   - 2.8 Electoral Administration & Cost Allocations
3. [The Six American Municipal Option Families](#3-the-six-american-municipal-option-families)
4. [Distinctive Jurisdictions & Structural Edge Cases](#4-distinctive-jurisdictions--structural-edge-cases)
   - 4.1 New England Town Governance (CT, MA, ME, NH, RI, VT)
   - 4.2 New Jersey Faulkner Act & Traditional Municipal Codes
   - 4.3 Virginia's 38 Independent Cities & Other City-County Hybrids
   - 4.4 District of Columbia Home Rule Governance
   - 4.5 Alaska Boroughs & Unified Municipalities
   - 4.6 Hawaii County-Dominant Local Governance
   - 4.7 Consolidated City-Counties & Hero Metro Charters
5. [Master 50-State + DC Jurisdictional Profiles](#5-master-50-state--dc-jurisdictional-profiles)
6. [Implementation-Ready Simulation Cargo & TypeScript Contracts](#6-implementation-ready-simulation-cargo--typescript-contracts)
7. [Catalog of Unresolved Source Conflicts & Frontier Fields](#7-catalog-of-unresolved-source-conflicts--frontier-fields)
8. [Primary Statutory, Constitutional, and Regulatory Citation Registry](#8-primary-statutory-constitutional-and-regulatory-citation-registry)

---

## 1. EXECUTIVE SUMMARY & NATIONAL RESEARCH SCOPE

### 1.1. Context and Mission Mandate
`[FACT]` Packet `92I` established the empirical implementation cargo for Kentucky municipal governance—specifically analyzing the Lexington-Fayette Urban County Government (LFUCG), Louisville-Jefferson County Metro Government, and the City of Bowling Green. However, 92I explicitly served as a worked example, not a national default.
`[FACT]` In American local government law, there is no single 'standard American city.' Across the 50 states, municipal political life is shaped by deep historical fragmentation between Dillon's Rule states and Constitutional Home Rule states, partisan primaries and nonpartisan ballots, Spring standalone elections and November consolidated cycles, pure plurality rules and mandatory 50%+1 runoffs, and widely varying direct democracy rights.
`[FACT]` This packet (`92O`) establishes the authoritative, comprehensive 50-state plus District of Columbia national matrix (51 jurisdictions total). Every state is modeled using a dual framework: (1) Baseline State Statutory Framework, (2) Locally Selectable Option Families, and (3) Named Exceptions / Hero Charters. No single monolithic rule is claimed for any state where local charter variation exists.

### 1.2. Key National Findings Across 50 States + DC
`[FACT]` Across the 51 sovereign American jurisdictions:
1. **Partisan vs. Nonpartisan Elections:**
   - ~75% of American municipalities conduct nonpartisan elections.
   - In **4 states** (**Indiana**, **New York**, **Pennsylvania**, **Mississippi**), municipal elections are **mandatory partisan by default**; candidates compete in party primaries (or party caucuses) and appear on general election ballots with party designations.
   - In **Connecticut**, municipal elections are partisan by default, with mandatory statutory **minority-party representation quotas** (C.G.S. § 9-167a) capping the number of seats any single political party may hold on a council or board.
   - In **Ohio**, statutory cities conduct partisan primaries and elections, but charter cities universally opt for nonpartisan ballots under the 1912 Home Rule Amendment.
   - In **North Carolina** and **South Carolina**, general state law authorizes individual municipalities to choose by charter between nonpartisan plurality, nonpartisan runoff, nonpartisan primary, or full partisan elections.
   - **Party Precinct Committeeperson Caucus Succession:** In **Indiana** (IC § 3-13-8-1) and **Ohio statutory cities** (R.C. § 733.31), when a partisan municipal official vacates, the seat is filled **solely by a private caucus of the vacating official's political party precinct committeepersons** without any vote by the city council or citizens!
2. **Election Timing & The Turnout Wedge:**
   - **Even-Year November Consolidation:** Mandated statewide in **California** (California Voter Participation Rights Act / SB 415), **Arizona** (A.R.S. § 16-204), **Nevada**, **Oregon**, **Wyoming**, **North Dakota**, **Kentucky**, and **Hawaii**; turnout commonly ranges between 60% and 80%.
   - **Odd-Year November Consolidation (The Off-Year Shield):** Standard in **Ohio**, **Pennsylvania**, **New York**, **Washington**, **Colorado**, **Utah**, **Kansas**, **Iowa**, **Georgia**, and **North Carolina**; turnout ranges between 25% and 45%.
   - **Standalone Spring Elections:** Retained in **Wisconsin** (April Spring Election), **Missouri** (April Municipal Election), **Illinois** (April Consolidated Election), **Oklahoma** (April General), **Texas** (Uniform May Date), and New Jersey Faulkner nonpartisan cities (May); turnout typically falls between 12% and 25%, granting immense leverage to organized interest groups (public-sector labor, developers, neighborhood federations).
   - **Town Meeting Day:** Celebrated annually in **Vermont** (first Tuesday in March), **New Hampshire** (second Tuesday in March), and **Maine** (March/April).
   - **Virginia's 2021 Abolition of May Elections:** Virginia enacted Va. Code § 24.2-222.1 in 2021, moving all municipal elections from May to November, eliminating local spring balloting statewide.
3. **Runoff & Voting Rules:**
   - **Mandatory 50%+1 Southern Runoff:** Enforced in **Georgia** (O.C.G.A. § 21-2-501; top-two runoff 4 weeks later), **Texas General Law Type A** (TLGC § 22.010), **Louisiana** (Open Jungle Primary with top-two general runoff), and **Mississippi** party primaries.
   - **Preliminary Top-Two Runoff Systems:** Enforced in **Washington** (August top-two primary), **Nebraska** (May nonpartisan primary), **Wyoming**, **California charter cities**, and **Chicago**.
   - **Approval Voting:** Active in **Fargo, North Dakota** (adopted 2018) and **St. Louis, Missouri** (adopted 2020 for nonpartisan primary with top-two runoff).
   - **Ranked-Choice Voting (RCV) / Instant Runoff Voting (IRV):** Approved and operational in **San Francisco, CA**, **Oakland, CA**, **Berkeley, CA**, **Portland, ME**, **Minneapolis, MN**, **St. Paul, MN**, **Cambridge, MA** (Proportional STV), **Takoma Park, MD**, **Santa Fe, NM**, **Burlington, VT**, **Utah Municipal RCV Pilot Project**, and **Portland, Oregon** (historic 2024 reform establishing 4 multi-member districts electing 3 members each via Single Transferable Vote).
4. **Direct Democracy: Recall, Initiative, and Protest Referendum:**
   - **Recall is strictly UNCONSTITUTIONAL or PROHIBITED** in **14 states**: **Pennsylvania** (*Citizens Committee to Recall Rizzo*, 470 Pa. 1), **New York** (*Matter of Cassella v. City of Schenectady*, 281 A.D. 428), **Indiana** (barred by courts and Home Rule Act), **Kentucky** (Ky. Const. §§ 150/152), **South Carolina**, **Utah**, **Alabama** (general law), **Connecticut**, **New Hampshire**, **Vermont**, **Delaware**, **Maryland** (general law), **Virginia** (judicial removal trial only under Va. Code § 24.2-233), and **Iowa** (judicial removal trial only under Code Ch. 66).
   - **Universal Political Recall Without Cause:** Constitutionally guaranteed in **California**, **Arizona**, **Colorado**, **Nevada**, **Oregon**, **Wisconsin**, and **Michigan**; petitions require 10% to 25% of voters and trigger special recall elections.
   - **Strict Cause / Judicial Sufficiency Barriers:** In **Washington** (RCW § 29A.56.140), **Georgia** (O.C.G.A. § 21-4-6), and **Florida** (F.S. § 100.361), petitions cannot be circulated without proving legal malfeasance or misfeasance in a formal court hearing.
   - **The Idaho Retention Barrier (Idaho Code § 34-1712):** An official is not recalled merely by a 50%+1 vote; the affirmative recall votes must **equal or exceed the total votes cast for the official in their original election**!

---

## 2. COMPARATIVE TYPOLOGICAL SYNTHESES ACROSS 8 CORE MODULES

### 2.1. Partisan vs. Nonpartisan Balloting Landscape & Vacancy Succession
`[FACT]` While ~75% of American cities operate under nonpartisan ballots (a legacy of the Progressive Era municipal reform movement intended to weaken party machines), political party affiliation remains legally binding in several major states:
- **Mandatory Partisan Regimes:** In Indiana (IC § 3-10-6-1), Pennsylvania (25 P.S. § 2862), New York (Election Law § 6-108), and Mississippi (Miss. Code § 21-11-1), candidates for mayor and city council must be nominated in party primaries or file independent petitions.
- **Party Caucus Vacancy Succession:** In Indiana (IC § 3-13-8-1) and Ohio statutory cities (R.C. § 733.31), vacancies in partisan seats are filled **not by the council, not by the mayor, and not by special election**—they are filled by a closed meeting of the precinct committeepersons of the vacating member's party.
- **Statutory Minority Party Quotas:** In Connecticut (C.G.S. § 9-167a) and the District of Columbia (D.C. Code § 1-204.01), state/federal law caps majority party dominance. In Connecticut, on a 9-member council, no party may hold more than 6 seats; in D.C., no party may nominate more than two candidates for four at-large seats.
- **Informal Partisan Shadow Ballots:** In nominally nonpartisan cities (e.g. Chicago, Los Angeles, Seattle), political parties, central labor councils, and county party executive committees issue official endorsement slate cards and fund independent expenditure committees, recreating partisan dynamics without ballot labels.

### 2.2. Election Timing & Calendar Consolidation
`[FACT]` Municipal election timing creates massive variance in voter turnout and electorate composition:
1. **Consolidated Even-Year November (60–80% Turnout):** State statutes in California, Arizona, Nevada, Oregon, and Kentucky force municipal elections onto presidential and midterm ballots. Municipal candidates share the ballot with federal and state races, producing high turnout but subjecting local candidates to national coattail swings.
2. **Consolidated Odd-Year November (25–45% Turnout):** Practiced in Ohio, Pennsylvania, New York, Washington, Colorado, and North Carolina. The electorate is older, wealthier, and more heavily composed of property owners attuned to municipal taxes, zoning, and public safety.
3. **Standalone Spring (10–25% Turnout):** Practiced in Wisconsin, Missouri, Illinois, Oklahoma, and Texas. Low turnout creates an environment where municipal employee unions, police and fire associations, and organized neighborhood federations exercise decisive electoral power.
4. **Town Meeting Day (March):** Practiced in Vermont, New Hampshire, and Maine. Direct deliberative democracy where citizens assemble to vote budgets and policies on the floor, accompanied by secret Australian balloting for executive selectboards.

### 2.3. Representation Architectures: Wards, At-Large, and Proportional Systems
`[FACT]` The structure of municipal councils is governed by federal Voting Rights Act (VRA) jurisprudence and state statutory frameworks:
- **Pure At-Large:** Common in small towns and traditional commission cities. Every voter votes for every council seat. Widely targeted by federal Section 2 VRA litigation and state acts (e.g. California Voting Rights Act of 2001, Washington Voting Rights Act of 2018) for diluting minority voting power.
- **Single-Member Districts (Wards):** Universal in major metropolitan cities (Chicago: 50 wards; Los Angeles: 15 districts; New York City: 51 districts). Councilmembers represent geographically bounded constituencies with heightened constituent casework demands.
- **Hybrid (Ward + At-Large):** Practiced in LFUCG (12 district + 3 at-large), Indianapolis (25 districts), Columbus OH (transitioned to 9 residential districts), Atlanta (12 district + 3 at-large posts + President). At-large members frequently serve as council leaders or vice mayors.
- **Multi-Member Proportional RCV / Single Transferable Vote:** Historically used in Cambridge, MA (9 at-large councilors via STV); adopted by Portland, Oregon in 2024 (4 geographic districts electing 3 councilors each via STV, creating a 12-member council).

### 2.4. Executive Selection: Strong Mayor vs. Council Selection vs. Selectboards
`[FACT]` Executive authority is sharply differentiated across four institutional archetypes:
1. **Strong Mayor-Council:** Mayor is directly elected citywide, serves as chief executive officer, appoints and removes department heads, prepares the municipal budget, and holds veto power over council ordinances (overridden by 2/3 or 3/4 council vote). Exemplars: New York City, Chicago, Los Angeles, Houston, Philadelphia, Atlanta, Detroit, Louisville Metro, LFUCG.
2. **Council-Manager (Professional Administration):** City Council is the governing legislature; council appoints a professionally trained City Manager (ICMA credentialed) who exercises administrative authority, hires/fires staff, and executes the budget. The Mayor is chosen by council or directly elected as a ceremonial presiding officer with NO veto power. Exemplars: Phoenix, Dallas, Austin, San Jose, Charlotte, Grand Rapids, Des Moines, Portland ME.
3. **Commission Form (Galveston Plan):** Plural executive where elected commissioners collectively act as the city council and individually serve as heads of administrative departments (e.g. Commissioner of Public Works, Commissioner of Finance, Commissioner of Public Safety). Largely abandoned due to administrative friction and lack of executive accountability, but preserved in traditional North Dakota cities and South Dakota commissioner cities.
4. **Town Selectboard (Plural Executive):** Board of Selectmen/Selectboard (3 to 5 members, 3-year staggered terms) acts collectively as the executive board of the town, executing Town Meeting warrants and managing public ways.

### 2.5. Runoff, Plurality, and Majority Threshold Rules
`[FACT]` The legal threshold required to win municipal office determines campaign strategy and coalition dynamics:
- **Mandatory Majority Runoff (50% + 1):** In Georgia, Texas General Law Type A, Louisiana, and Mississippi primaries, a candidate must clear 50% of the vote. If no candidate clears 50%, a secondary runoff election is held 2 to 4 weeks later between the top two finishers.
- **Top-Two Nonpartisan Primary:** In Washington, Nebraska, Wyoming, and California, nonpartisan primaries held months in advance eliminate all candidates except the top two, who advance to the general election ballot.
- **Pure Plurality:** In Pennsylvania, New York, Ohio, Indiana, and Colorado statutory cities, the candidate with the highest number of votes wins office on election night, even with 30% or less of the vote in crowded fields.
- **Ranked-Choice Instant Runoff Voting (IRV):** Voters rank candidates in order of preference. If no candidate achieves a majority of first-preference votes, the lowest candidate is eliminated and their ballots redistributed until one candidate achieves a majority. Eliminates the cost and depressed turnout of separate runoff elections.

### 2.6. Municipal Recall Architectures & Retention Barriers
`[FACT]` State law establishes three radically different recall doctrines:
1. **Political Recall Without Cause (Western Tradition):** California, Arizona, Colorado, Nevada, Oregon, and Wisconsin grant voters the unfettered constitutional right to recall any elected municipal officer for purely political or policy disagreements. Statements of reasons cannot be reviewed or challenged in court. Petitions require 10% to 25% of voters.
2. **Judicial Cause / Sufficiency Hearing Barrier (Southern & Northwestern Tradition):** In Washington (RCW § 29A.56.140), Georgia (O.C.G.A. § 21-4-6), and Florida (F.S. § 100.361), petitions cannot be circulated without specific legal grounds (malfeasance, misfeasance, or violation of oath of office). Washington mandates a formal court trial before a Superior Court judge before petition circulation is authorized.
3. **The Idaho Retention Barrier (Idaho Code § 34-1712):** Recall is legally ineffective unless the YES vote exceeds 50% AND equals or exceeds the total votes cast for the official in their original election.
4. **Absolute Constitutional / Judicial Prohibition:** Pennsylvania (*Citizens Committee to Recall Rizzo*), New York (*Matter of Cassella*), Indiana, Kentucky, South Carolina, and Utah strictly prohibit municipal recall under general law.

### 2.7. Municipal Initiative & Protest Referenda
`[FACT]` Direct citizen lawmaking is strictly regulated by subject-matter exemptions and statutory filing windows:
- **Indirect vs. Direct Initiative:** In indirect initiative states (California, Wisconsin, Ohio, Montana, Michigan), a certified citizen petition is submitted first to the city council, which has 20 to 60 days to adopt the ordinance without alteration; if council fails to act, the measure is placed on the ballot. In direct initiative states (Arizona, South Dakota, Utah), certified petitions go directly to the ballot.
- **Protest Referendum Suspensive Windows:** A protest referendum petitions an ordinance passed by the city council before it takes effect:
  - **10 to 14 Days:** North Dakota (§ 40-12-08), Missouri 3rd Class (§ 78.220), Connecticut towns (14 days).
  - **20 to 30 Days:** California (30 days), Ohio (30 days), Washington (30 days), South Dakota (20 days).
  - **Suspensive Power:** In California, Ohio, and South Dakota, filing a certified petition **immediately suspends the legal operation of the ordinance** until voters decide the question.
- **Universal Subject-Matter Exemptions:** State statutes uniformly bar initiatives and protest referenda on: (1) Annual budget and appropriations for current operating expenses, (2) Tax levies and tax rate adjustments, (3) Emergency ordinances passed by supermajority (2/3 or 3/4) declaring an immediate threat to public peace, health, or safety, and (4) Administrative or ministerial acts (e.g. executing contracts authorized by prior ordinance, or individual zoning permits).

### 2.8. Electoral Administration & Cost Allocations
`[FACT]` The administrative entity conducting municipal elections dictates cost burdens and logistical coordination:
- **County-Administered Coordinated Model:** In California, Arizona, Ohio, Pennsylvania, Washington, and Iowa, the County Board of Elections / Registrar of Voters conducts municipal contests concurrently with federal and state elections. The county bills the municipality a proportional share of actual operational expenses.
- **Municipal Clerk Independent Administration:** In Wisconsin, New England towns, and standalone Mississippi/Alabama cities, the municipal clerk or town board of civil authority administers voter registration, polling places, and ballot canvassing directly, with 100% of costs borne by the municipal treasury.
- **State-Administered Enclave Model:** In the District of Columbia, an independent District Board of Elections conducts all primary, general, and Advisory Neighborhood Commission elections.

---

## 3. THE SIX AMERICAN MUNICIPAL OPTION FAMILIES

```mermaid
graph TD
    A[50-State Municipal Legal Landscape] --> B[Family 1: New England Town Meeting]
    A --> C[Family 2: Mid-Atlantic Partisan Dillon]
    A --> D[Family 3: Southern Runoff / General Law]
    A --> E[Family 4: Midwestern Optional-Charter]
    A --> F[Family 5: Western Constitutional Direct Democracy]
    A --> G[Family 6: Consolidated City-Counties & Unified Metros]
    B --> B1[CT, MA, ME, NH, RI, VT]
    C --> C1[DE, MD, NJ, NY, PA, VA]
    D --> D1[AL, AR, FL, GA, LA, MS, NC, SC, TN, TX]
    E --> E1[IA, IL, IN, KS, MI, MN, MO, NE, ND, OH, SD, WI]
    F --> F1[AK, AZ, CA, CO, HI, ID, MT, NV, NM, OK, OR, UT, WA, WY]
    G --> G1[LFUCG, Louisville Metro, Indianapolis, Nashville, Denver, SF, Philadelphia, Honolulu, Anchorage]
```

The 50 states plus DC cluster into six institutional families whose core characteristics govern candidacy, campaign timing, council governance, and direct citizen challenges. Complete descriptions are formalized in Section 4 of the companion machine cargo `92O_NATIONAL_MUNICIPAL_ELECTIONS_DIRECT_DEMOCRACY.json`.

---

## 4. DISTINCTIVE JURISDICTIONS & STRUCTURAL EDGE CASES

### 4.1. New England Town Governance (CT, MA, ME, NH, RI, VT)
`[FACT]` The New England town represents America's oldest surviving form of pure direct democracy. Unlike Midwestern or Southern townships (which are administrative subdivisions of counties), New England towns possess full general municipal powers:
- **Legislative Body:** Open Town Meeting (all registered electors assemble in person to debate and vote on bylaws and appropriations) or Representative Town Meeting (electors elect town meeting members by precinct).
- **Plural Executive:** Board of Selectmen / Selectboard (3 or 5 members, 3-year staggered terms) acts collectively as the executive board.
- **Warrant Articles:** Any citizen can place binding legislation on the town meeting warning by submitting a petition signed by 10 to 50 registered voters.
- **New Hampshire's SB 2 Official Ballot System (RSA 40:13):** Splitting town meeting into two sessions: (1) Deliberative Session (articles debated and amended), and (2) Official Ballot Voting Day (all articles voted by secret Australian ballot on second Tuesday in March).

### 4.2. New Jersey Faulkner Act & Traditional Municipal Codes
`[FACT]` New Jersey municipal law is a laboratory of statutory options under the Optional Municipal Charter Law (Faulkner Act, N.J.S.A. 40:69A-1 et seq.):
- **Faulkner Plans A-D:** Plan A (Strong Mayor-Council), Plan B (Council-Manager), Plan C (Small Municipality), Plan D (Mayor-Council-Administrator).
- **Electoral Freedom:** Faulkner municipalities can opt for: (1) Partisan November elections, (2) Nonpartisan May elections (second Tuesday in May), or (3) Nonpartisan November elections.
- **Direct Democracy Rights:** Faulkner Act guarantees citizen initiative (10-15% signatures) and protest referendum (15% signatures within 20 days; N.J.S.A. 40:69A-184). In non-Faulkner traditional boroughs/townships, citizen ordinance initiative does NOT exist.

### 4.3. Virginia's 38 Independent Cities & Other City-County Hybrids
`[FACT]` Under the Constitution of Virginia (Art. VII), all 38 incorporated cities are completely independent of any county government. A resident of Richmond, Norfolk, Alexandria, or Virginia Beach does not live in a county, does not pay county taxes, and does not vote for county commissioners. The City Council and Mayor administer all municipal functions, while citizens simultaneously elect five constitutional county officers: Sheriff, Commonwealth's Attorney, Circuit Court Clerk, Commissioner of the Revenue, and Treasurer.
`[FACT]` Other prominent independent cities in the United States include **Baltimore, Maryland** (Md. Const. Art. XI), **St. Louis, Missouri** (Mo. Const. Art. VI § 31), and **Carson City, Nevada** (NRS Title 21).

### 4.4. District of Columbia Home Rule Governance
`[FACT]` Governed by the District of Columbia Home Rule Act of 1973 (Public Law 93-198; D.C. Code Title 1):
- **Executive & Council:** Elected Mayor + 13-member Council of the District of Columbia (8 ward members + 4 at-large members + 1 Chairman elected at-large).
- **Mandatory Minority Party Quota:** D.C. Code § 1-204.01 mandates that for at-large council seats, no political party may nominate more than two candidates, guaranteeing that at least two at-large seats are held by minority party or independent members.
- **Congressional Layover & Veto Review:** Under D.C. Code § 1-206.02, every local act passed by the Council and signed by the Mayor must undergo a mandatory 30-day (for civil acts) or 60-day (for criminal acts) Congressional Layover Period during which Congress may enact a Joint Resolution of Disapproval signed by the President to nullify the local law.
- **Advisory Neighborhood Commissions (ANCs):** 345+ single-member districts of ~2,000 residents each electing nonpartisan commissioners every 2 years; ANCs possess the statutory right to 'great weight' in municipal zoning, licensing, and public works decisions under D.C. Code § 1-309.10.

### 4.5. Alaska Boroughs & Unified Municipalities
`[FACT]` Alaska local government is structured under Alaska Const. Art. X into Boroughs (areawide local governments) and underlying cities. In four regions, total city-borough consolidation has produced Unified Municipalities: Anchorage, Juneau, Sitka, and Wrangell. The municipal assembly exercises both municipal and borough powers areawide. Under AS 29.26.040, Alaska local elections occur uniformly on the first Tuesday in October annually.

### 4.6. Hawaii County-Dominant Local Governance
`[FACT]` Under Hawaii Const. Art. VIII, Hawaii has **zero incorporated municipal corporations** (no cities or towns) below the county level. The City and County of Honolulu governs the entire island of Oahu. Local government statewide consists strictly of 4 unified county governments: Honolulu, Hawaii County, Maui County, and Kauai County. All local elections are strictly nonpartisan and held concurrently with state even-year primaries (August) and generals (November).

### 4.7. Consolidated City-Counties & Hero Metro Charters
`[FACT]` Major consolidated city-counties merge municipal corporations with county governments, creating unique hybrid institutions:
- **Lexington-Fayette Urban County Government (LFUCG; KRS Ch. 67A):** Nonpartisan even-year elections; 15 councilmembers (12 district, 3 at-large); Vice Mayor is highest at-large vote getter; no general ordinance initiative/referendum (92I worked example).
- **Louisville-Jefferson County Metro Government (KRS Ch. 67C):** Partisan even-year elections; 26 single-member districts; directly elected Mayor with veto; no general ordinance initiative/referendum.
- **Indianapolis-Marion County Unigov (IC Title 36 Art. 3):** Partisan odd-year elections; 25 single-member districts; directly elected Mayor.
- **Metropolitan Government of Nashville and Davidson County (T.C.A. Title 7):** Nonpartisan August odd-year elections with September 50%+1 runoff; 40-member council (35 districts, 5 at-large) + directly elected Mayor and Vice Mayor.
- **City and County of Denver (Colo. Const. Art. XX):** Nonpartisan May odd-year elections with June runoff; Strong Mayor with veto; 13 councilmembers (11 districts, 2 at-large).

---

## 5. MASTER 50-STATE + DC JURISDICTIONAL PROFILES

The dossiers below detail the statutory framework, optional charter variants, electoral systems, vacancy filling rules, recall mechanisms, and direct democracy parameters for all 50 states plus the District of Columbia.

### US-AL — Alabama
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `dillons_rule_strict` | Authority: `Ala. Code Title 11; Ala. Const. Art. IV`
  - `[FACT]` Strict Dillon's Rule; municipalities have only powers expressly granted by state legislature; local constitutional amendments dominate governance.
- **Primary Statutory Forms:**
  - `Mayor-Council` (Ala. Code § 11-43-1 et seq.): Default statutory form for Class 2-8 cities.
  - `Commission` (Ala. Code § 11-44-1 et seq.): Voter petition and referendum.
  - `Council-Manager` (Ala. Code § 11-44E-1 et seq. (Optional Council-Manager Act)): Voter petition and referendum in eligible population classes.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Ala. Code § 11-46-20`)
  - `Election Timing:` `quadrennial_late_summer_august` (Statute: `Ala. Code § 11-46-21 (Fourth Tuesday in August every 4 years, e.g. 2020, 2024, 2028)`)
  - `Runoff / Voting Rule:` `majority_50_plus_1` | Trigger: `50.0%` | Statute: `Ala. Code § 11-46-55 (Top-two runoff held on fourth Tuesday following regular election)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, hybrid_districts_and_at_large` | Default: `single_member_districts (Class 1-6) / at-large (Class 7-8)` (Statute: `Ala. Code § 11-43-63`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Mayor elected at-large with strong administrative powers, veto power in cities > 12,000 (Ala. Code § 11-43-40).
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `Ala. Code Title 11 Ch. 46 (City clerk acts as election administrator; city council canvasses)` | Cost Rule: 100% borne by municipal treasury
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Ala. Code § 11-43-42, § 11-44E-23`
  - `[FACT]` Council vacancy filled by vote of remaining council within 60 days. Mayor vacancy filled by Council President. If council deadlocks, Governor appoints.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `Ala. Code Title 11 (Absent in general law; exists only in specific local legislative acts)`
    - `Mechanics:` General law provides no recall. Officials subject only to judicial impeachment under Ala. Const. Art. VII § 175.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `Ala. Code Title 11` | Notes: Citizen ordinance initiative is not authorized under general municipal law; available only for changing form of government or local option liquor votes.
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `Ala. Code Title 11` | Notes: Citizen protest referendum on city ordinances is absent in general municipal law.
- **Named Exceptions & Hero Charters:**
  - **Birmingham:** Governed by Mayor-Council Act of 1953 (Ala. Acts 1953, No. 452); 9 single-member council districts; strong mayor with full appointment/veto; odd-year August elections (2021, 2025).
  - **Mobile:** Governed by Mobile Zoghby Act (Ala. Acts 1985, No. 85-237); 7 council districts; requires 5-vote supermajority for ordinance passage; strong mayor.
- **Epistemic First-Party Sources:** `Ala. Code Title 11 Ch. 43, 44, 46; Ala. Const. Art. IV, VII; Alabama League of Municipalities Legal Handbook (2025/2026)`

---

### US-AK — Alaska
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Alaska Const. Art. X; AS Title 29 (Municipal Government)`
  - `[FACT]` Maximum local self-government constitutional mandate (Art. X § 1); Home rule municipalities possess plenary legislative authority not denied by statute or charter.
- **Primary Statutory Forms:**
  - `Home Rule Municipality` (AS 29.04.010, AS 29.10): Charter commission drafting and voter adoption.
  - `First Class City` (AS 29.04.020, AS 29.20): Statutory council-manager or mayor-council general law.
  - `Second Class City` (AS 29.04.030): Simplified council structure; council chooses mayor from its own membership.
  - `Unified Municipality / Home Rule Borough` (AS 29.06.130): Total borough-city consolidation (Anchorage, Juneau, Sitka, Wrangell).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `AS 29.26.010`)
  - `Election Timing:` `annual_autumn_october` (Statute: `AS 29.26.040 (First Tuesday in October annually)`)
  - `Runoff / Voting Rule:` `locally_selectable` | Trigger: `40.0%` | Statute: `AS 29.26.060 (Plurality default; municipality may require 40% or 50% majority with top-two runoff)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, multi_member_apportionment_sections` | Default: `pure_at_large (cities) / district sections (boroughs)` (Statute: `AS 29.20.140, AS 29.20.300`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: In 1st class cities, mayor elected at-large; holds veto over council unless manager plan adopted (AS 29.20.250). In 2nd class cities, council elects mayor from own members (AS 29.20.230).
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `AS 29.26.010 - 29.26.050 (Municipal clerk conducts; assembly/council serves as canvassing board)` | Cost Rule: 100% municipal/borough responsibility
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `6 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `AS 29.20.180, AS 29.20.280`
  - `[FACT]` Governing body appoints qualified voter to fill vacancy until next regular October election. If more than 180 days remain before regular election and unexpired term exceeds one year, special election may be called.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `True` | Threshold: `25.0%` of `votes_cast_for_office` | Window: `60 days`
    - `Authority:` `AS 29.26.240 - 29.26.350; Alaska Const. Art. XI § 8`
    - `Mechanics:` Two-stage petition. Application signed by 10 sponsor voters; if certified by clerk, full petitions require 25% signatures. Yes/No recall question; if recalled, seat is vacant and filled under vacancy rules.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `25.0%` | Exempt Subjects: `appropriations, tax_levies, local_ordinances_affecting_personnel_rules`
    - `Authority:` `AS 29.26.100 - 29.26.190` | Notes: Petitions require 25% of votes cast at last regular election. Council has 30 days to enact ordinance substantially identical; if not enacted, placed on ballot.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `25.0%`
    - `Authority:` `AS 29.26.170 - 29.26.190` | Notes: Protest petition filed within 30 days after ordinance enactment suspends legal operation of ordinance until election.
- **Named Exceptions & Hero Charters:**
  - **Municipality of Anchorage:** Unified home-rule municipality; 11 assembly members from 6 districts; directly elected strong mayor with veto (overridden by 8 votes); nonpartisan April general election (grandfathered exception to October timing under Charter § 7.01).
  - **City and Borough of Juneau:** Unified home-rule municipality; 8 assembly members elected areawide but residency-district apportioned + directly elected mayor; Council-Manager form; October election timing.
- **Epistemic First-Party Sources:** `Alaska Const. Art. X, XI; Alaska Statutes Title 29 (Municipal Government); Alaska Municipal League Governance Guide (2025/2026)`

---

### US-AZ — Arizona
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Ariz. Const. Art. 13 § 2; A.R.S. Title 9`
  - `[FACT]` Constitutional charter cities (>3,500 pop) have plenary organic law supremacy over local municipal affairs. General law towns governed by Common Council statutory code.
- **Primary Statutory Forms:**
  - `Common Council (Town)` (A.R.S. § 9-231 et seq.): Statutory incorporation default.
  - `City (Common Council / Manager)` (A.R.S. § 9-271 et seq.): Cities > 3,000 population opting into statutory city organization.
  - `Charter City` (Ariz. Const. Art. 13 § 2; A.R.S. § 9-281): 14-member board of freeholders drafted charter approved by voters.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `A.R.S. § 9-821.01`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `A.R.S. § 16-204, § 16-204.01 (State law preemptively consolidated all municipal elections with statewide even-year primary in August and general election in November)`)
  - `Runoff / Voting Rule:` `top_two_primary_runoff` | Trigger: `50.0%` | Statute: `A.R.S. § 9-821.01 (Candidate receiving majority of all votes cast at primary is elected outright; for remaining unfilled seats, top two candidates advance to November general)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, hybrid_wards_and_at_large` | Default: `pure_at_large (statutory towns) / district councils (charter cities)` (Statute: `A.R.S. § 9-232, § 9-273`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Under A.R.S. § 9-232.03, towns may directly elect mayor by ordinance. Charter cities define mayor powers (mostly Council-Manager with weak/presiding mayor, e.g. Phoenix, Tucson).
  - `Administration:` `county_election_board_coordinated` | Authority: `A.R.S. § 16-205 (County recorder and elections department administer municipal elections on consolidated even-year ballot)` | Cost Rule: Pro-rata cost share paid by municipality to county
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `18 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `A.R.S. § 9-235, § 16-230`
  - `[FACT]` Council appoints qualified elector to fill vacancy for unexpired term. If majority of council seats become vacant, County Board of Supervisors appoints interim members.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `simultaneous_incumbent_replacement` | Grounds Required: `False` | Threshold: `25.0%` of `votes_cast_for_office` | Window: `120 days`
    - `Authority:` `Ariz. Const. Art. 8 Pt. 1; A.R.S. Title 19 Ch. 2`
    - `Mechanics:` Incumbent automatically appears on recall ballot as candidate unless resigning within 5 days. Challengers file nominating petitions. Plurality winner takes office.
  - `Municipal Initiative:` Authorized: `True` | Type: `direct_to_ballot` | Threshold: `15.0%` | Exempt Subjects: `administrative_matters, zoning_ordinances`
    - `Authority:` `Ariz. Const. Art. 4 Pt. 1 § 1(8); A.R.S. Title 19 Ch. 1` | Notes: 15% of registered voters in city/town. Strict compliance standard for petition forms. Goes directly to ballot at next consolidated general election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Ariz. Const. Art. 4 Pt. 1 § 1(8); A.R.S. § 19-142` | Notes: 10% of registered voters filed within 30 days of ordinance passage suspends ordinance until voted upon.
- **Named Exceptions & Hero Charters:**
  - **Phoenix:** Council-Manager charter; 8 single-member council districts + Mayor elected at-large; runoff required if no candidate clears 50%; standalone election timing grandfathering eliminated by A.R.S. § 16-204.
  - **Tucson:** Unique modified ward system (nominated in ward primaries, elected at-large in general election; upheld in Gonzales v. City of Tucson, 727 F.3d 949); even-year election schedule.
- **Epistemic First-Party Sources:** `Ariz. Const. Art. 4, 8, 13; A.R.S. Title 9, Title 16, Title 19; Arizona League of Cities and Towns Municipal Handbook (2025)`

---

### US-AR — Arkansas
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `Ark. Code Ann. Title 14; Ark. Const. Amend. 7`
  - `[FACT]` Municipal Home Rule Act of 1971 (A.C.A. § 14-43-601); broad legislative powers subject to state preemption.
- **Primary Statutory Forms:**
  - `Mayor-Council (1st / 2nd Class)` (A.C.A. § 14-43-501 et seq.): Default general law form based on population.
  - `City Manager` (A.C.A. § 14-47-101 et seq.): Voter petition and election (cities > 2,500).
  - `City Administrator` (A.C.A. § 14-48-101 et seq.): Voter petition and election.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_default_partisan_optional` (Statute: `A.C.A. § 14-42-206 (Nonpartisan default; cities of 1st class may opt by ordinance to hold party primaries)`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `A.C.A. § 14-42-202 (First Tuesday after first Monday in November of even-numbered years)`)
  - `Runoff / Voting Rule:` `majority_50_plus_1` | Trigger: `50.0%` | Statute: `A.C.A. § 7-5-106, § 14-42-206 (In cities > 20,000, 50%+1 required, or 40% with a 20% margin over runner-up; otherwise top-two runoff held 3 weeks later)`
  - `District / Ward / At-Large:` Options: `single_member_wards, two_aldermen_per_ward, pure_at_large` | Default: `two_aldermen_per_ward (1st Class cities; A.C.A. § 14-43-501)` (Statute: `A.C.A. § 14-43-501, § 14-44-103`)
  - `Mayor Selection:` `direct_popular_election, board_selected_from_membership` | Strong vs. Weak: Direct election in Mayor-Council (4-yr term, full administrative head and veto power; A.C.A. § 14-43-504). In City Manager cities, Board of Directors elects mayor from own members or voters elect board president.
  - `Administration:` `county_election_board_coordinated` | Authority: `A.C.A. § 7-5-101 (County Board of Election Commissioners conducts municipal general and runoff elections)` | Cost Rule: Apportioned to municipality based on proportion of ballot
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `12 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `A.C.A. § 14-42-106, § 14-43-501`
  - `[FACT]` City council fills aldermanic vacancy by majority vote for unexpired term. For mayor vacancy with > 1 year remaining, special election called; if < 1 year, council elects successor.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `35.0%` of `votes_cast_for_office` | Window: `30 days`
    - `Authority:` `A.C.A. § 14-47-112 (Manager), § 14-48-114 (Admin)`
    - `Mechanics:` Authorized ONLY in City Manager (35% signatures) and City Administrator (25% signatures) forms. Strictly barred in Mayor-Council cities (general law provides no recall for aldermen/mayor).
  - `Municipal Initiative:` Authorized: `True` | Type: `direct_to_ballot` | Threshold: `15.0%` | Exempt Subjects: `appropriations, local_administrative_matters`
    - `Authority:` `Ark. Const. Amend. 7; A.C.A. § 7-9-111` | Notes: 15% of votes cast for mayor at last preceding general election. Petitions filed with city clerk > 60 days before general election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `15.0%`
    - `Authority:` `Ark. Const. Amend. 7; A.C.A. § 14-55-301` | Notes: 15% petition filed within 30 days of ordinance publication suspends ordinance until voted on at election.
- **Named Exceptions & Hero Charters:**
  - **Little Rock:** Operates under City Manager form (A.C.A. Title 14 Ch. 47); 7-member Board of Directors (3 at-large, 4 wards); directly elected Mayor; nonpartisan November elections with runoff.
  - **Fort Smith:** City Administrator form (A.C.A. Title 14 Ch. 48); 7-member Board of Directors; direct recall available under § 14-48-114.
- **Epistemic First-Party Sources:** `Ark. Const. Amend. 7; Ark. Code Ann. Title 7, Title 14; Arkansas Municipal League Handbook (2025)`

---

### US-CA — California
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Cal. Const. Art. XI §§ 3, 5; Cal. Gov. Code § 34000 et seq.`
  - `[FACT]` Plenary constitutional home rule for Charter Cities over 'municipal affairs' (Cal. Const. Art. XI § 5(a)). General Law cities governed by Government Code Title 4.
- **Primary Statutory Forms:**
  - `General Law City (Council-Manager default)` (Cal. Gov. Code § 36501 et seq.): Statutory default upon incorporation.
  - `Charter City` (Cal. Const. Art. XI § 3; Cal. Gov. Code § 34450 et seq.): Charter commission election or city council submission approved by voters.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Cal. Const. Art. II § 6(a)`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `Cal. Elec. Code § 14050 - 14057 (California Voter Participation Rights Act / SB 415 mandates consolidation with statewide even-year elections)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `Cal. Elec. Code § 10516 (Plurality default for General Law cities; Charter cities may establish majority runoff or Ranked-Choice Voting, e.g., SF, Oakland, Berkeley)`
  - `District / Ward / At-Large:` Options: `single_member_districts, pure_at_large, by_district_with_at_large_mayor` | Default: `single_member_districts (California Voting Rights Act of 2001, Elec. Code § 14025, forced near-universal transition away from at-large)` (Statute: `Cal. Gov. Code § 34871; Cal. Elec. Code § 14025`)
  - `Mayor Selection:` `direct_popular_election, council_selected_rotating` | Strong vs. Weak: In General Law cities, council selects mayor annually from own membership (Gov. Code § 36801) unless voters establish directly elected mayor (Gov. Code § 34900). Charter cities establish Strong Mayor (e.g. Los Angeles, San Diego, Fresno, San Francisco).
  - `Administration:` `county_election_board_coordinated` | Authority: `Cal. Elec. Code § 10002, § 10400 et seq. (Consolidated with County Registrar of Voters)` | Cost Rule: Proportional reimbursement of actual election costs to County Registrar
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Cal. Gov. Code § 36512`
  - `[FACT]` Council must within 60 days either: (1) appoint a replacement for the unexpired term, or (2) call a special election. City may enact an ordinance pre-specifying appointment or mandatory special election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `20.0%` of `registered_voters` | Window: `120 days`
    - `Authority:` `Cal. Const. Art. II § 19; Cal. Elec. Code Div. 11 (§ 11000 et seq.)`
    - `Mechanics:` Two-question ballot: (1) 'Shall [Official] be recalled?' (Yes/No), and (2) 'Candidates to succeed [Official] if recalled.' Tiered signature thresholds: 30% (<1,000 voters), 25% (1k-10k), 20% (10k-50k), 15% (50k-100k), 10% (>=100k).
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `10.0%` | Exempt Subjects: `tax_reduction_impairing_contracts, administrative_matters`
    - `Authority:` `Cal. Const. Art. II § 11; Cal. Elec. Code Div. 9 Ch. 3 (§ 9200 et seq.)` | Notes: 10% of registered voters for regular election; 15% forces special election. Council must within 10 days either: (a) adopt ordinance without alteration, (b) call special election, or (c) order 30-day impact report.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Cal. Const. Art. II § 11; Cal. Elec. Code Div. 9 Ch. 3 (§ 9235 et seq.)` | Notes: Petition signed by 10% of registered voters filed within 30 days of ordinance adoption suspends ordinance until council entirely repeals or voters approve at election.
- **Named Exceptions & Hero Charters:**
  - **City of Los Angeles:** Charter City; Strong Mayor with full executive/veto authority; 15 single-member council districts; Primary in March/June even years, runoff in November even years.
  - **City and County of San Francisco:** Consolidated City-County; 11-member Board of Supervisors elected by Ranked-Choice Voting (RCV); directly elected Mayor; even-year November elections.
  - **Oakland:** Charter City; uses multi-round Ranked-Choice Voting for Mayor and City Council under Charter § 1105.
- **Epistemic First-Party Sources:** `Cal. Const. Art. II, XI; Cal. Gov. Code Title 4; Cal. Elec. Code Div. 9, 10, 11, 14; League of California Cities Municipal Law Handbook (2025/2026)`

---

### US-CO — Colorado
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Colo. Const. Art. XX (Home Rule Amendment); C.R.S. Title 31`
  - `[FACT]` Plenary constitutional home rule (Art. XX § 6); home rule charters supersede state statutory law on local and municipal matters.
- **Primary Statutory Forms:**
  - `Statutory City (Mayor-Council)` (C.R.S. § 31-4-101 et seq.): General law classification default.
  - `Statutory City (Council-Manager)` (C.R.S. § 31-4-201 et seq.): Voter petition and election.
  - `Statutory Town (Board of Trustees)` (C.R.S. § 31-4-301 et seq.): Incorporated municipalities < 2,000 pop.
  - `Home Rule City / Town` (Colo. Const. Art. XX; C.R.S. § 31-2-201): Charter convention drafted and voter adopted.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `C.R.S. § 31-10-302`)
  - `Election Timing:` `spring_even_year, odd_year_november_consolidated` (Statute: `C.R.S. § 31-10-103 (Statutory cities: first Tuesday in April of even-numbered years; Home rule cities coordinate with November odd-year coordinated election)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `C.R.S. § 31-10-1205 (Plurality default; candidate receiving highest number of votes elected; home rule charters may require runoff, e.g. Denver)`
  - `District / Ward / At-Large:` Options: `wards_with_two_council_members_each, pure_at_large, hybrid_wards_and_at_large` | Default: `wards_with_two_council_members_each (Statutory cities: C.R.S. § 31-4-101)` (Statute: `C.R.S. § 31-4-101, § 31-4-301`)
  - `Mayor Selection:` `direct_popular_election, board_selected_from_membership` | Strong vs. Weak: Direct election in Statutory Cities (2-yr term; C.R.S. § 31-4-102; votes on ties, holds veto overridden by 2/3). In statutory towns, Mayor chosen from Board of Trustees or directly elected (C.R.S. § 31-4-301).
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `C.R.S. Title 31 Art. 10 (Colorado Municipal Election Code of 1965) or coordinated under C.R.S. Title 1` | Cost Rule: 100% municipal if standalone; shared if coordinated with County Clerk
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `C.R.S. § 31-4-103, § 31-4-303`
  - `[FACT]` City council / Board of Trustees fills vacancy by majority vote within 60 days, or calls special election. Appointee serves until next regular municipal election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `25.0%` of `votes_cast_for_office` | Window: `60 days`
    - `Authority:` `Colo. Const. Art. XXI § 4; C.R.S. § 31-4-501 et seq.`
    - `Mechanics:` Two-question ballot: (1) 'Shall [Officer] be recalled?' (2) Successor ballot. Petitions require 25% of the entire vote cast for all candidates for that office at the last preceding election.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `appropriations_for_support_and_maintenance, administrative_actions`
    - `Authority:` `Colo. Const. Art. V § 1(9); C.R.S. Title 31 Art. 11` | Notes: 5% signatures for regular election; 15% forces special election. Council has 20 days to adopt ordinance in full or submit to voters.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Colo. Const. Art. V § 1(9); C.R.S. § 31-11-105` | Notes: 10% of registered electors filed within 30 days of ordinance publication suspends ordinance until council repeals or election occurs.
- **Named Exceptions & Hero Charters:**
  - **City and County of Denver:** Consolidated City-County (Colo. Const. Art. XX); Strong Mayor system; 13-member council (11 districts, 2 at-large); nonpartisan spring general election in May of odd-numbered years (2023, 2027) with runoff in June.
  - **Colorado Springs:** Home Rule Charter; Council-Mayor form (adopted 2010); directly elected strong mayor + 9 councilmembers; odd-year April elections.
- **Epistemic First-Party Sources:** `Colo. Const. Art. V, XX, XXI; C.R.S. Title 31 (Powers & Elections); Colorado Municipal League Municipal Governance Manual (2025/2026)`

---

### US-CT — Connecticut
- **Option Family:** `new_england_town_meeting`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `Conn. Gen. Stat. Title 7; Conn. Const. Art. X`
  - `[FACT]` Home Rule Act of 1957 (C.G.S. § 7-188 et seq.); towns and cities may adopt or amend charters within powers delegated by General Statutes.
- **Primary Statutory Forms:**
  - `Town Meeting / Board of Selectmen` (C.G.S. § 7-10 et seq., § 7-130 et seq.): Traditional New England town governance default.
  - `Mayor-Council` (C.G.S. § 7-193): Charter adoption under Home Rule Act.
  - `Council-Manager` (C.G.S. § 7-193): Charter adoption under Home Rule Act.
- **Electoral Framework:**
  - `Ballot Type:` `partisan_mandatory` (Statute: `C.G.S. § 9-164, § 9-372 et seq. (Partisan municipal elections default; party nominations via primary or caucus; independent petitions)`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `C.G.S. § 9-164 (First Tuesday after first Monday in November of odd-numbered years; primary held in September)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `C.G.S. § 9-173 (Plurality election; candidate receiving highest number of votes elected)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, multi_member_districts` | Default: `pure_at_large_with_minority_representation_caps` (Statute: `C.G.S. § 9-167a (Mandatory minority representation quotas: on a 3-member board, max 2 of same party; 5-member, max 3; 9-member, max 6)`)
  - `Mayor Selection:` `direct_popular_election, first_selectman_ballot_rule` | Strong vs. Weak: In town meeting form, First Selectman is directly elected by virtue of receiving the highest votes among selectmen candidates (C.G.S. § 9-188). In cities, Mayor directly elected with veto defined by charter.
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `C.G.S. Title 9 (Town Clerk and Registrars of Voters administer municipal elections locally)` | Cost Rule: 100% borne by town/city
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `True`
  - `Statutes:` `C.G.S. § 9-220, § 9-222`
  - `[FACT]` Selectmen of the same political party as vacating member appoint successor within 30 days. However, under § 9-222, voters may petition (5% of electors) for a special town election to fill the selectman vacancy.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `C.G.S. Title 7 & 9 (Absent in general law; barred by state courts absent express statutory authorization)`
    - `Mechanics:` Recall is prohibited under general Connecticut law. Towns cannot adopt recall by home-rule charter.
  - `Municipal Initiative:` Authorized: `False` | Type: `town_meeting_warrant` | Threshold: `None%` | Exempt Subjects: `appropriations, general_legislation_in_cities`
    - `Authority:` `C.G.S. Title 7` | Notes: In town meeting towns, 20 or 50 electors can petition to place a warrant article on the town meeting agenda (C.G.S. § 7-1). In charter cities, citizen ordinance initiative is generally absent unless authorized by specific charter.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `14 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `C.G.S. § 7-7` | Notes: Under C.G.S. § 7-7, 200 electors or 10% of electors may petition to remove any question or ordinance passed at a town meeting to an 'adjourned town meeting' vote by voting machine.
- **Named Exceptions & Hero Charters:**
  - **Hartford:** Strong Mayor-Council charter; Mayor is chief executive; 9-member Court of Common Council elected at-large with minority party representation rules; partisan odd-year November elections.
  - **New Haven:** Mayor-Aldermanic charter; 30 single-member wards (Board of Alders); directly elected mayor; partisan odd-year elections.
- **Epistemic First-Party Sources:** `Conn. Gen. Stat. Title 7 (Municipalities), Title 9 (Elections); Conn. Const. Art. X; Connecticut Conference of Municipalities Handbook (2025)`

---

### US-DE — Delaware
- **Option Family:** `mid_atlantic_partisan_dillon`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `22 Del. C. Ch. 8 (Home Rule); 15 Del. C. Ch. 75`
  - `[FACT]` Home Rule Act of 1961 (22 Del. C. § 801 et seq.) allows cities > 1,000 to amend charters, but state legislature routinely grants and amends special legislative charters.
- **Primary Statutory Forms:**
  - `Council-Manager (Special Legislative Charter)` (22 Del. C. § 802): Dominant form in Delaware charters.
  - `Mayor-Council (Special Legislative Charter)` (22 Del. C. § 802): Wilmington, Newark, Dover.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `15 Del. C. § 7551 et seq. (Municipal Election Law mandates nonpartisan elections for all municipalities except City of Wilmington)`)
  - `Election Timing:` `spring_annual, odd_year_autumn` (Statute: `15 Del. C. § 7553 (Election dates set by individual municipal charters, typically spring dates in March, April, or May; Wilmington holds elections in November of presidential years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `15 Del. C. § 7558 (Plurality election; highest vote getter elected)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, hybrid_districts_and_at_large` | Default: `pure_at_large (smaller towns) / council districts (Wilmington, Newark)` (Statute: `Governed by individual municipal charters`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: In Wilmington, strong mayor directly elected. In council-manager charters (Newark, Dover), mayor is presiding officer with ceremonial duties.
  - `Administration:` `hybrid_clerk_and_county` | Authority: `15 Del. C. Ch. 75 (State Department of Elections provides voting machines and voter registry; Municipal Board of Elections administers polling places)` | Cost Rule: State Department provides machines without fee; municipality bears local board costs
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `15 Del. C. § 7559; Local Charters`
  - `[FACT]` Governed by local charter. Council typically appoints successor until next regular municipal election; special election called if vacancy occurs early in term.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `22 Del. C. Title 22 (Absent in general state law)`
    - `Mechanics:` No statewide municipal recall statute. Only available if explicitly drafted into a special legislative charter enacted by the General Assembly.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_ordinances`
    - `Authority:` `22 Del. C. Ch. 8` | Notes: Citizen ordinance initiative is not authorized by general Delaware law; exists only where explicitly granted in individual city charters (e.g. Newark Charter § 901).
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `22 Del. C. Ch. 8` | Notes: General law provides no protest referendum on ordinances; mandatory voter referendum applies only to municipal bond issues and charter amendments.
- **Named Exceptions & Hero Charters:**
  - **City of Wilmington:** Only municipality in Delaware conducting PARTISAN elections (15 Del. C. § 7501); Mayor-Council charter; 8 council districts + 4 at-large + President; quadrennial elections consolidated with presidential November election.
  - **Newark:** Council-Manager charter; nonpartisan elections on second Tuesday in April; charter grants citizen initiative and referendum (Newark Charter Art. IX).
- **Epistemic First-Party Sources:** `15 Del. C. Ch. 75 (Municipal Elections); 22 Del. C. Ch. 8 (Home Rule); Delaware League of Local Governments Handbook (2025)`

---

### US-FL — Florida
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Fla. Const. Art. VIII § 2; F.S. Ch. 166 (Municipal Home Rule Powers Act)`
  - `[FACT]` Broad constitutional and statutory home rule; municipalities possess governmental, corporate, and proprietary powers to enact legislation on any municipal subject except where expressly preempted by state law.
- **Primary Statutory Forms:**
  - `Commission-Manager` (F.S. § 166.021): Dominant municipal charter form in Florida.
  - `Mayor-Council (Strong Mayor)` (F.S. § 166.021): Adopted in major cities (Tampa, Jacksonville, Orlando, Miami, St. Petersburg).
  - `City Commission` (F.S. § 166.021): Traditional commission form.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `F.S. § 166.021, § 166.032 (Municipal charters universally prescribe nonpartisan elections; party emblems barred on municipal ballots)`)
  - `Election Timing:` `spring_annual, odd_year_autumn, even_year_november_consolidated` (Statute: `F.S. § 100.3605, § 101.75 (Municipalities may set election dates by charter or ordinance; commonly March spring dates, or consolidated with August primary / November general)`)
  - `Runoff / Voting Rule:` `locally_selectable` | Trigger: `50.0%` | Statute: `F.S. § 100.3605 (Charters specify plurality or majority runoff; in cities requiring majority, top two advance to second election)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, hybrid_districts_and_at_large` | Default: `pure_at_large (small cities) / single_member_districts (large metros)` (Statute: `Governed by municipal charters; subject to Florida Voting Rights Act compliance`)
  - `Mayor Selection:` `direct_popular_election, commission_selected_rotating` | Strong vs. Weak: Direct election in Mayor-Council charters (strong executive administration, veto power). In Commission-Manager charters, mayor is typically commission member selected by colleagues or directly elected as ceremonial chair.
  - `Administration:` `county_election_board_coordinated` | Authority: `F.S. § 100.3605, § 101.001 (County Supervisor of Elections conducts municipal elections under interlocal agreement)` | Cost Rule: Municipality reimburses Supervisor of Elections for actual operational expenses
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `6 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `F.S. § 166.031; Local Charters`
  - `[FACT]` Governed strictly by municipal charter. Typically commission appoints successor within 30-60 days. If vacancy occurs with > 6 months remaining, special election is triggered.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `True` | Threshold: `10.0%` of `registered_voters` | Window: `30 days`
    - `Authority:` `F.S. § 100.361 (Uniform Municipal Recall Statute)`
    - `Mechanics:` Two-tiered petition process: (1) Initial petition signed by 10% (or 7.5% in cities > 25k, 5% in > 100k) of registered electors containing specific grounds. Official files defensive statement within 5 days. (2) Second petition requires additional 15% signatures within 60 days. Recall election held with Yes/No question.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `10.0%` | Exempt Subjects: `budget_and_appropriations, zoning_regulations`
    - `Authority:` `F.S. § 166.031 (Charter amendments); Charters (Ordinances)` | Notes: Charter amendment guaranteed by statute upon 10% registered voter petition (F.S. § 166.031). General ordinance initiative is not statewide mandate; available only if enacted in municipal charter.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `F.S. § 166.031; Municipal Charters` | Notes: Governed by individual municipal charters. Where provided, 10% voter petition within 30 days suspends ordinance pending council reconsideration or referendum.
- **Named Exceptions & Hero Charters:**
  - **City of Jacksonville:** Consolidated City-County (Duval County); 19-member City Council (14 districts, 5 at-large); directly elected Strong Mayor with veto; unitary first election in March, runoff in May.
  - **City of Miami:** Mayor-Commission-Manager charter; 5 single-member commission districts; directly elected Mayor with veto power (overridden by 4/5 vote); nonpartisan November odd-year elections with runoff.
  - **City of Tampa:** Strong Mayor-Council charter; 7 councilmembers (4 districts, 3 at-large); nonpartisan March elections with April runoff in odd years (2023, 2027).
- **Epistemic First-Party Sources:** `Fla. Const. Art. VIII; Florida Statutes Ch. 100, 101, 166; Florida League of Cities Municipal Governance Manual (2025/2026)`

---

### US-GA — Georgia
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `Ga. Const. Art. IX § II; O.C.G.A. Title 36 (Municipal Home Rule Act of 1965)`
  - `[FACT]` Statutory home rule (O.C.G.A. § 36-35-1 et seq.); General Assembly retains authority to enact, amend, or revoke municipal charters by local act.
- **Primary Statutory Forms:**
  - `Mayor-Council` (O.C.G.A. Title 36; Local Charters): Dominant form across Georgia cities.
  - `Council-Manager` (O.C.G.A. Title 36; Local Charters): Enacted by local charter act.
  - `Commission` (O.C.G.A. Title 36; Local Charters): Enacted by local charter act.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_default_partisan_optional` (Statute: `O.C.G.A. § 21-2-139 (Nonpartisan default for municipal elections; municipality may opt by charter or ordinance to conduct partisan elections)`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `O.C.G.A. § 21-2-9(b) (First Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `majority_50_plus_1` | Trigger: `50.0%` | Statute: `O.C.G.A. § 21-2-501 (MANDATORY MAJORITY RULE: candidate must receive 50%+1 of votes; top-two runoff held 28 days later)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_posts_and_wards` | Default: `single_member_wards (medium/large cities) / numbered posts at-large (small towns)` (Statute: `Governed by local municipal charter acts; O.C.G.A. § 36-35-4.1`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Mayor directly elected at-large in nearly all charters. Strong Mayor (Atlanta) has full veto and appointment; Weak Mayor presides with tie-breaking vote only.
  - `Administration:` `county_election_board_coordinated` | Authority: `O.C.G.A. § 21-2-45 (Municipality may contract with County Board of Elections and Registration to conduct elections, or conduct via Municipal Election Superintendent)` | Cost Rule: Municipality pays county actual operational costs pursuant to intergovernmental contract
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `12 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `O.C.G.A. § 36-30-13; Local Charters`
  - `[FACT]` Governed by charter. General rule: if vacancy occurs with > 12 months remaining in term, mandatory special election; if < 12 months, council appoints successor for remainder of term.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `True` | Threshold: `30.0%` of `registered_voters` | Window: `90 days`
    - `Authority:` `O.C.G.A. Title 21 Ch. 4 (Public Officers Recall Act)`
    - `Mechanics:` Mandatory judicial review: officer may file application in Superior Court to review legal sufficiency of alleged grounds before petition circulation. Petitions require 30% of registered electors (45 days in small towns). Standalone Yes/No recall vote.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `O.C.G.A. § 36-35-3` | Notes: Citizen initiative is authorized ONLY for proposing municipal charter amendments (petition signed by 20% of registered electors under O.C.G.A. § 36-35-3(b)). Citizen initiative for general ordinances is PROHIBITED.
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `O.C.G.A. Title 36` | Notes: No general statutory protest referendum mechanism on municipal ordinances.
- **Named Exceptions & Hero Charters:**
  - **City of Atlanta:** Mayor-Council charter (Ga. Laws 1996, p. 4469); Strong Mayor with veto (overridden by 2/3); 16-member Council (12 districts, 3 at-large posts, 1 Council President elected at-large); nonpartisan odd-year November elections with 50%+1 runoff.
  - **Augusta-Richmond County:** Consolidated City-County (Ga. Laws 1995, p. 3648); Commission-Administrator form; 10 commissioners (8 districts, 2 super-districts) + directly elected Mayor; nonpartisan general election held in May of even years concurrently with state general primary.
- **Epistemic First-Party Sources:** `Ga. Const. Art. IX; O.C.G.A. Title 21 (Elections), Title 36 (Local Government); Georgia Municipal Association Municipal Handbook (2025)`

---

### US-HI — Hawaii
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Haw. Const. Art. VIII; Hawaii Revised Statutes (HRS) Title 6`
  - `[FACT]` County-dominant local governance; Hawaii has zero incorporated municipal corporations (no cities or towns) below the county level. All municipal power resides in 4 unified county governments.
- **Primary Statutory Forms:**
  - `Mayor-Council (Unified County Charter)` (HRS § 46-1.5; County Charters): Universal form across all four counties (Honolulu, Hawaii, Maui, Kauai).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `HRS § 249; County Charters`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `HRS § 11-1 et seq. (Consolidated with statewide Primary in August and General Election in November of even-numbered years)`)
  - `Runoff / Voting Rule:` `top_two_primary_runoff` | Trigger: `50.0%` | Statute: `County Charters (Candidate receiving 50%+1 of votes at August primary is elected outright; otherwise, top two advance to November general)`
  - `District / Ward / At-Large:` Options: `single_member_districts, pure_at_large, residency_districts_elected_at_large` | Default: `single_member_districts (Honolulu: 9 districts; Hawaii: 9 districts; Maui: 9 residency districts; Kauai: 7 at-large)` (Statute: `Governed by individual County Charters`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Mayor is directly elected countywide in all 4 counties with strong executive authority, managing administration, appointments, and veto power.
  - `Administration:` `hybrid_clerk_and_county` | Authority: `HRS Title 2 (State Office of Elections provides unified mail ballot system; County Clerks administer voter registration and processing)` | Cost Rule: Shared cost formula between State and Counties
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `12 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Governed by County Charters (e.g. Honolulu Charter § 3-105, § 5-108)`
  - `[FACT]` Council appoints qualified voter to fill council vacancy. If unexpired term exceeds one year, special election held. Mayor vacancy filled by Managing Director pending special election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `False` | Threshold: `10.0%` of `registered_voters` | Window: `60 days`
    - `Authority:` `Governed by County Charters (e.g. Honolulu Charter Art. XII)`
    - `Mechanics:` Recall governed by charter. Requires 10-15% of registered voters. Standalone Yes/No vote; successor filled via vacancy appointment/election.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `10.0%` | Exempt Subjects: `appropriation_of_money, tax_levies, salaries_of_county_employees`
    - `Authority:` `County Charters (e.g. Honolulu Charter Art. III)` | Notes: 10% of total voters who voted at last mayoral election. Council must consider within 60 days; if rejected, placed on general election ballot.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `60 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `County Charters (e.g. Honolulu Charter Art. III)` | Notes: 10% registered voter petition filed within 60 days suspends ordinance until council repeals or voters ratify.
- **Named Exceptions & Hero Charters:**
  - **City and County of Honolulu:** Consolidated island-wide government; 9 single-member council districts; strong mayor with full cabinet appointment; nonpartisan even-year elections.
  - **Maui County:** 9 residency districts elected countywide; voters across entire county vote on each district seat.
- **Epistemic First-Party Sources:** `Haw. Const. Art. VIII; Hawaii Revised Statutes Title 6; Charter of the City and County of Honolulu (2024/2026 ed.)`

---

### US-ID — Idaho
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `dillons_rule_strict` | Authority: `Idaho Code Title 50; Idaho Const. Art. XII § 2`
  - `[FACT]` Strict Dillon's Rule state; municipalities possess only powers expressly conferred by statute; local police powers cannot conflict with general laws.
- **Primary Statutory Forms:**
  - `Mayor-Council` (Idaho Code § 50-601 et seq.): Default statutory form for all incorporated cities.
  - `Council-Manager` (Idaho Code § 50-801 et seq.): Voter petition and special election adoption.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Idaho Code § 50-403 ('All municipal elections shall be nonpartisan')`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `Idaho Code § 50-403 (First Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `Idaho Code § 50-612, § 50-707 (Plurality default; cities may by ordinance enact majority runoff requirement for mayor or council)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts` | Default: `pure_at_large (cities < 100,000) / single_member_districts (mandated for cities >= 100,000 under Idaho Code § 50-707A)` (Statute: `Idaho Code § 50-707, § 50-707A (Boise mandated into districts by 2020/2022 statute)`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: In Mayor-Council cities, Mayor is directly elected at-large (4-yr term; holds veto overridden by 2/3 council; § 50-608). In Council-Manager cities, council selects mayor from own membership as presiding chair (§ 50-809).
  - `Administration:` `county_election_board_coordinated` | Authority: `Idaho Code § 34-1401 (County clerk conducts all elections within county on consolidated dates)` | Cost Rule: Pro-rata reimbursement of direct election expenses to county
- **Vacancy Succession Procedure:**
  - `Rule Type:` `mayoral_appointment_council_consent` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Idaho Code § 50-608, § 50-704`
  - `[FACT]` Council vacancy: Mayor appoints with consent of council. Mayor vacancy: Council elects one of its own members as mayor for remainder of unexpired term.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `False` | Threshold: `20.0%` of `registered_voters` | Window: `75 days`
    - `Authority:` `Idaho Code Title 34 Ch. 17 (§ 34-1701 et seq.)`
    - `Mechanics:` THE IDAHO RETENTION BARRIER (Idaho Code § 34-1712): Recall is NOT effective unless: (1) A majority votes YES on recall, AND (2) The number of YES votes equals or exceeds the total number of votes cast for the officer at their original election!
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `20.0%` | Exempt Subjects: `appropriations, tax_levies, special_assessments`
    - `Authority:` `Idaho Code § 50-501` | Notes: Petition signed by 20% of registered electors. Council must either pass ordinance within 30 days or submit to voters at next general city election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `20.0%`
    - `Authority:` `Idaho Code § 50-501` | Notes: Petition signed by 20% of electors filed within 30 days suspends ordinance until voted upon.
- **Named Exceptions & Hero Charters:**
  - **City of Boise:** Operated historically under 1864 territorial charter; 2020 statutory amendment (Idaho Code § 50-707A) forced city to divide into 6 geographic council districts; directly elected mayor with 4-year term.
  - **City of Bellevue:** Retains original 1880s territorial charter with unique licensing and local court powers.
- **Epistemic First-Party Sources:** `Idaho Code Title 34 (Elections), Title 50 (Municipal Corporations); Association of Idaho Cities Handbook (2025/2026)`

---

### US-IL — Illinois
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Ill. Const. Art. VII § 6; 65 ILCS 5 (Illinois Municipal Code)`
  - `[FACT]` Automatic constitutional home rule for any municipality > 25,000 pop (or by local referendum in smaller towns). Plenary police power except where expressly preempted by General Assembly.
- **Primary Statutory Forms:**
  - `Aldermanic (Mayor-Council)` (65 ILCS 5/Art. 3.1): Default statutory city form.
  - `Village (President-Trustees)` (65 ILCS 5/Art. 3.1): Default incorporated village form (President + 6 Trustees).
  - `Commission` (65 ILCS 5/Art. 4): Voter referendum adoption (Mayor + 4 Commissioners; nonpartisan).
  - `Managerial` (65 ILCS 5/Art. 5): Voter referendum adoption (Council-Manager; nonpartisan).
- **Electoral Framework:**
  - `Ballot Type:` `partisan_default_nonpartisan_optional` (Statute: `10 ILCS 5/Art. 7, Art. 10; 65 ILCS 5/3.1-25-20 (Partisan in aldermanic/village unless opted nonpartisan; strictly nonpartisan in Commission/Manager forms)`)
  - `Election Timing:` `odd_year_spring` (Statute: `10 ILCS 5/2A-1.1, 5/2A-1.2 (Consolidated Primary on last Tuesday in February; Consolidated Election on first Tuesday in April of odd-numbered years)`)
  - `Runoff / Voting Rule:` `top_two_primary_runoff` | Trigger: `50.0%` | Statute: `65 ILCS 5/4-3-5, 65 ILCS 20/21-12 (In nonpartisan forms and Chicago, primary eliminates all but top two candidates who contest the April election)`
  - `District / Ward / At-Large:` Options: `single_member_wards, two_aldermen_per_ward, pure_at_large` | Default: `two_aldermen_per_ward (Statutory cities: 65 ILCS 5/3.1-20-10) / at-large (Villages: 6 Trustees)` (Statute: `65 ILCS 5/3.1-20-10, 65 ILCS 5/3.1-20-25, 65 ILCS 5/3.1-25-5`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election in all forms (Mayor in cities, President in villages). Holds veto over council ordinances (overridden by 2/3 vote; 65 ILCS 5/3.1-40-45).
  - `Administration:` `county_election_board_coordinated` | Authority: `10 ILCS 5/Art. 6 (County Clerk or Board of Election Commissioners conducts all consolidated elections)` | Cost Rule: Proportionate share billed to municipality under 10 ILCS 5/17-30
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `28 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `65 ILCS 5/3.1-10-50, 5/3.1-10-51`
  - `[FACT]` Mayor/President appoints successor with advice and consent of council within 60 days. If vacancy occurs with > 28 months remaining in 4-year term and > 130 days before consolidated election, appointee serves only until next consolidated election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `65 ILCS 5 (Absent in general law; Illinois courts hold recall unauthorized without express statute)`
    - `Mechanics:` PROHIBITED under general law. Specific statutory recall exists ONLY for Chicago Mayor (added 2018; 10 ILCS 5/Art. 21A; requiring 15% registered voters in every ward) and Commission form (65 ILCS 5/4-7-1; 25% electors).
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `65 ILCS 5` | Notes: Citizen initiative for ordinary municipal ordinances is PROHIBITED. Voter initiative permitted only on structural questions: adopting home rule, altering council size, or changing form of government (Ill. Const. Art. VII § 6(f)).
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `65 ILCS 5` | Notes: Protest referendum against general city ordinances is not authorized. Referenda are limited to back-door referendum questions on municipal bond issues and tax levy increases.
- **Named Exceptions & Hero Charters:**
  - **City of Chicago:** Operates under Revised Cities and Villages Act of 1941 (65 ILCS 20/); 50 single-member wards (50 Aldermen); directly elected Mayor; nonpartisan February election with April top-two runoff; Chicago Board of Election Commissioners; structural recall authorization under 10 ILCS 5/21A.
  - **Village of Oak Park:** Home rule village; Council-Manager plan; 6 trustees elected at-large; nonpartisan April elections.
- **Epistemic First-Party Sources:** `Ill. Const. Art. VII; 65 ILCS 5 (Illinois Municipal Code); 10 ILCS 5 (Election Code); Illinois Municipal League Municipal Handbook (2025/2026)`

---

### US-IN — Indiana
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `Ind. Code Title 36; Ind. Code § 36-1-3 (Home Rule Act)`
  - `[FACT]` Statutory Home Rule; cities have broad internal administrative powers, but Dillon's Rule strictly controls election procedures, taxation, and direct democracy (which are completely barred).
- **Primary Statutory Forms:**
  - `Second Class City (Mayor + 9 Council)` (IC § 36-4-1 et seq.): Cities 35,000 to 599,999 pop (6 district members, 3 at-large).
  - `Third Class City (Mayor + 7 Council)` (IC § 36-4-1 et seq.): Cities < 35,000 pop (5 district members, 2 at-large).
  - `Town (Town Council / Clerk-Treasurer)` (IC § 36-5-1 et seq.): Incorporated towns (3, 5, or 7 councilmembers).
  - `Consolidated First Class City (Unigov)` (IC § 36-3-1 et seq.): Indianapolis-Marion County consolidation.
- **Electoral Framework:**
  - `Ballot Type:` `partisan_mandatory` (Statute: `IC § 3-10-6-1, § 3-10-6-2 (MANDATORY PARTISAN ELECTIONS: candidates run in party primaries in May; general election in November of odd-numbered years)`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `IC § 3-10-6-5 (First Tuesday after first Monday in November of odd-numbered years; e.g. 2023, 2027)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `IC § 3-12-8 (Plurality election in both primary and general elections; no runoffs)`
  - `District / Ward / At-Large:` Options: `hybrid_districts_and_at_large` | Default: `hybrid_districts_and_at_large (2nd Class: 6 districts + 3 at-large; 3rd Class: 5 districts + 2 at-large)` (Statute: `IC § 36-4-6-3, § 36-4-6-4`)
  - `Mayor Selection:` `direct_popular_election, council_selected_town_council_president` | Strong vs. Weak: Direct election in all 2nd and 3rd class cities (4-yr term, full executive administration, veto power overridden by 2/3 council; IC § 36-4-5). In towns, Town Council selects Council President as executive head.
  - `Administration:` `county_election_board_coordinated` | Authority: `IC § 3-10-6-8 (County Election Board conducts municipal elections in all cities)` | Cost Rule: 100% apportioned and billed to municipality under IC § 3-5-3-8
- **Vacancy Succession Procedure:**
  - `Rule Type:` `party_precinct_committeeperson_caucus` | Special Election Cutoff: `None months` | Party Caucus Succession: `True` | Citizen Override: `False`
  - `Statutes:` `IC § 3-13-8-1 et seq. (Cities), IC § 3-13-9-1 et seq. (Towns)`
  - `[FACT]` PARTISAN CAUCUS SUCCESSION: When an elected municipal officer who was elected as a political party nominee vacates, the vacancy is filled SOLELY by a private caucus of the precinct committeepersons of that party within 30 days! If the vacating member was independent, the city council fills by majority vote.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `Ind. Code Title 36; Ind. Const. Art. 6`
    - `Mechanics:` Municipal recall is STRICTLY PROHIBITED in Indiana. Officials can only be removed via judicial impeachment for official misconduct under IC § 5-8-1-35.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_ordinances`
    - `Authority:` `IC § 36-1-3-8 (Home Rule Act express preemption)` | Notes: Citizen initiative for municipal ordinances is STRICTLY PROHIBITED. The Indiana Home Rule Act expressly prohibits municipalities from creating direct legislative mechanisms.
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `IC § 36-1-3-8` | Notes: Citizen protest referendum on city ordinances is PROHIBITED. Voter referenda exist only for public school capital projects and controlled municipal capital project tax caps.
- **Named Exceptions & Hero Charters:**
  - **City of Indianapolis (Unigov):** Consolidated First Class City-County (IC Title 36 Art. 3); City-County Council of 25 members (all single-member districts); directly elected Mayor of Indianapolis; partisan odd-year November elections; countywide urban services district.
  - **City of Fort Wayne:** 2nd Class City; 9-member council (6 districts, 3 at-large); strong mayor; partisan odd-year elections.
- **Epistemic First-Party Sources:** `Ind. Code Title 3 (Elections), Title 36 (Local Government); Indiana General Assembly Codification; Accelerate Indiana Municipalities (AIM) Municipal Guide (2025)`

---

### US-IA — Iowa
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Iowa Const. Art. III § 38A (Municipal Home Rule Amendment); Iowa Code Ch. 364 & 372`
  - `[FACT]` Constitutional Home Rule; municipalities have all powers not inconsistent with state statute; Dillon's Rule is constitutionally abolished.
- **Primary Statutory Forms:**
  - `Mayor-Council` (Iowa Code § 372.4): Default statutory form (Mayor + 5 councilmembers).
  - `Council-Manager-at-Large` (Iowa Code § 372.6): Voter petition and referendum adoption.
  - `Council-Manager-Ward` (Iowa Code § 372.7): Voter petition and referendum adoption.
  - `Commission` (Iowa Code § 372.5): Voter petition and referendum adoption.
  - `Home Rule Charter` (Iowa Code § 372.9): Charter commission drafted and voter adopted.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Iowa Code § 376.3 ('All municipal elections shall be nonpartisan')`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `Iowa Code § 376.1 (First Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `locally_selectable` | Trigger: `50.0%` | Statute: `Iowa Code § 376.4, § 376.6, § 376.9 (City council may by ordinance choose: (1) Primary election system, (2) Runoff election system, or (3) Plurality election)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (5 councilmembers default: Iowa Code § 372.4)` (Statute: `Iowa Code § 372.4, § 372.13`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in Mayor-Council (2- or 4-yr term; holds veto in cities > 500 pop, overridden by 2/3 council; § 372.4). In Council-Manager cities, Mayor is presiding member with no veto.
  - `Administration:` `county_election_board_coordinated` | Authority: `Iowa Code § 47.2, § 376.1 (County Auditor acts as County Commissioner of Elections, conducting all city elections)` | Cost Rule: Apportioned and reimbursed by city to county treasury
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `True`
  - `Statutes:` `Iowa Code § 372.13(2)`
  - `[FACT]` CITIZEN PETITION OVERRIDE: Council may appoint successor within 60 days. However, under Iowa Code § 372.13(2)(a), within 14 days of appointment, voters may file a petition signed by 15% of voters who voted in the last regular election to NULLIFY the council appointment and force a special election!
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `judicial_cause_removal_trial` | Grounds Required: `True` | Threshold: `20.0%` of `votes_cast_for_office` | Window: `None days`
    - `Authority:` `Iowa Code Ch. 66 (Removal for cause via judicial trial only)`
    - `Mechanics:` Political recall does NOT exist under Iowa law. Citizens may file a petition signed by qualified electors in the District Court to initiate a judicial trial for removal for cause.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `Iowa Code Ch. 372` | Notes: General citizen ordinance initiative is NOT authorized by Iowa law. Voter petition initiative is strictly limited to proposing charter amendments (25% voters) or changing statutory form of government.
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `Iowa Code Ch. 372 & 384` | Notes: Citizen protest referendum on general ordinances is absent. Mandatory voter referenda apply to utility franchise grants, municipal bond issuances, and capital projects.
- **Named Exceptions & Hero Charters:**
  - **City of Des Moines:** Council-Manager-at-Large charter; 7 councilmembers (4 wards, 2 at-large, 1 Mayor); odd-year November nonpartisan election with runoff.
  - **City of Cedar Rapids:** Home Rule Charter (adopted 2005); Council-Manager form; 8 councilmembers (5 districts, 3 at-large) + directly elected Mayor.
- **Epistemic First-Party Sources:** `Iowa Const. Art. III § 38A; Iowa Code Ch. 364, 372, 376; Iowa League of Cities Municipal Handbook (2025/2026)`

---

### US-KS — Kansas
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Kan. Const. Art. 12 § 5 (Home Rule Amendment); K.S.A. Ch. 12`
  - `[FACT]` Constitutional Home Rule; cities may pass charter ordinances opting out of non-uniform state statutes.
- **Primary Statutory Forms:**
  - `Mayor-Council (1st / 2nd / 3rd Class)` (K.S.A. § 12-101 et seq.): Default general law forms.
  - `Commission` (K.S.A. § 12-1001 et seq.): Voter petition and election.
  - `Commission-Manager` (K.S.A. § 12-1011 et seq.): Voter petition and election.
  - `Modified Mayor-Council` (K.S.A. § 12-1029): Voter petition and election.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `K.S.A. § 25-2113 ('All elections for city officers shall be nonpartisan')`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `K.S.A. § 25-2107 (Consolidated Primary in August; General Election on first Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `K.S.A. § 25-2120 (Plurality election; candidate with greatest number of votes elected; August primary held only if > 3 candidates file per seat)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `single_member_wards (1st/2nd class mayor-council) / at-large (commission forms)` (Statute: `K.S.A. § 12-104, § 13-304`)
  - `Mayor Selection:` `direct_popular_election, commission_selected_rotating` | Strong vs. Weak: Direct election in Mayor-Council cities (veto power in 1st class cities; overridden by 2/3 council). In commission-manager cities, mayor chosen by commissioners from own membership (K.S.A. § 12-1007).
  - `Administration:` `county_election_board_coordinated` | Authority: `K.S.A. § 25-2110 (County Election Officer conducts all municipal elections)` | Cost Rule: Pro-rata share billed by county to city under K.S.A. § 25-2201
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `K.S.A. § 12-104a, § 14-308`
  - `[FACT]` Governing body fills council vacancy by majority vote. If mayor vacates, President of the Council succeeds as mayor for remainder of unexpired term.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `True` | Threshold: `40.0%` of `votes_cast_for_office` | Window: `90 days`
    - `Authority:` `Kan. Const. Art. 4 § 3; K.S.A. § 25-4301 et seq. (Kansas Recall Act)`
    - `Mechanics:` Strict grounds requirement certified by county attorney or district court before petition circulation. High signature threshold: 40% of votes cast for that office at last general election. Standalone Yes/No ballot.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `25.0%` | Exempt Subjects: `administrative_matters, tax_levies_and_appropriations`
    - `Authority:` `K.S.A. § 12-3013` | Notes: Petition signed by 25% (in 2nd/3rd class) or 40% (in 1st class) of qualified electors. Governing body must pass ordinance without alteration within 20 days or submit to election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `60 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Kan. Const. Art. 12 § 5 (Charter ordinances); K.S.A. § 12-3013` | Notes: Protest referendum is guaranteed by constitution against CHARTER ORDINANCES (10% electors within 60 days suspends ordinance; Kan. Const. Art. 12 § 5(c)(3)).
- **Named Exceptions & Hero Charters:**
  - **Unified Government of Wyandotte County / Kansas City:** Consolidated City-County (K.S.A. § 12-340 et seq.); Commission-Executive form; 10 commissioners (8 districts, 2 at-large) + directly elected CEO/Mayor; nonpartisan odd-year elections.
  - **City of Wichita:** Council-Manager charter; 6 single-member council districts + Mayor elected at-large; nonpartisan odd-year November elections.
- **Epistemic First-Party Sources:** `Kan. Const. Art. 4, 12; K.S.A. Ch. 12, 13, 14, 25; League of Kansas Municipalities Handbook (2025/2026)`

---

### US-KY — Kentucky
- **Option Family:** `consolidated_city_county`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `Ky. Const. §§ 156b, 160; KRS Ch. 67A, 67C, 83A`
  - `[FACT]` Home Rule Act of 1980 (KRS 82.082) grants plenary powers to cities. KRS 67A provides Urban-County Government; KRS 67C provides Consolidated Local Government (Metro).
- **Primary Statutory Forms:**
  - `Mayor-Council` (KRS 83A.130): Statutory default (Mayor + 6-12 councilmembers).
  - `Commission` (KRS 83A.140): Voter petition and election (Mayor + 4 commissioners).
  - `City Manager` (KRS 83A.150): Voter petition and election (Mayor + 4 commissioners + City Manager).
  - `Urban-County Government (LFUCG)` (KRS Ch. 67A): Lexington-Fayette unified consolidation.
  - `Consolidated Local Government (Metro)` (KRS Ch. 67C): Louisville-Jefferson County metro consolidation.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_default_partisan_optional` (Statute: `KRS 83A.050 (Nonpartisan default for cities; city may opt by ordinance to conduct partisan elections; Louisville Metro is PARTISAN under KRS 67C.103)`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `Ky. Const. § 148; KRS 118.025 (Primary on third Tuesday in May; General Election on first Tuesday after first Monday in November of even-numbered years)`)
  - `Runoff / Voting Rule:` `top_two_primary_runoff` | Trigger: `50.0%` | Statute: `KRS 83A.170 (Nonpartisan primary in May eliminates all but top two candidates who advance to November general election; plurality wins in November)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (statutory forms) / hybrid (LFUCG: 12 districts + 3 at-large; Louisville Metro: 26 single-member districts)` (Statute: `KRS 83A.100, KRS 67A.020, KRS 67C.103`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election in all forms (4-yr term). Strong Mayor with full executive administration and veto in Mayor-Council (KRS 83A.130), LFUCG (Charter Sec. 5.02), and Louisville Metro (KRS 67C.105). Weak/presiding mayor in Commission and Manager forms.
  - `Administration:` `county_election_board_coordinated` | Authority: `KRS 117.035 (County Board of Elections conducts all municipal and metro elections)` | Cost Rule: Pro-rata cost share paid by city to county treasury under KRS 117.345
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `3 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `KRS 83A.040, KRS 67A.030, KRS 67C.103`
  - `[FACT]` Council/Commission appoints successor within 30 days. If council fails to act within 30 days, Governor appoints successor! In Louisville Metro, council selects within 30 days; if vacancy occurs with > 3 months before primary and > 2 years on term, election held.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `Ky. Const. §§ 150, 152; OAG 82-436`
    - `Mechanics:` Political recall is PROHIBITED for general elected municipal officers under Ky. Const. §§ 150 and 152. Limited statutory recall exists ONLY for protesting property tax rate increases exceeding the 4% revenue limit under KRS 132.017.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `20.0%` | Exempt Subjects: `appropriations, tax_levies, zoning_map_amendments`
    - `Authority:` `KRS 83A.130(11), 83A.140(8), 83A.150(8)` | Notes: Authorized ONLY in Commission and City Manager forms (petition signed by 20-25% of voters at last general election). Barred in LFUCG and Louisville Metro charters.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `20.0%`
    - `Authority:` `KRS 83A.130, 83A.140, 83A.150` | Notes: Authorized in Commission and City Manager forms (20% voter petition within 30 days suspends ordinance). Barred in LFUCG and Louisville Metro charters.
- **Named Exceptions & Hero Charters:**
  - **Lexington-Fayette Urban County Government (LFUCG):** Consolidated City-County (KRS Ch. 67A); 15-member Council (12 districts, 3 at-large); Vice Mayor is highest at-large vote getter; nonpartisan even-year elections; NO general ordinance initiative/referendum (92I worked example).
  - **Louisville-Jefferson County Metro Government:** Consolidated City-County (KRS Ch. 67C); 26 single-member districts; directly elected Mayor with veto; PARTISAN even-year elections (KRS 67C.103); NO general ordinance initiative/referendum.
  - **City of Bowling Green:** City Manager form (KRS 83A.150); Board of Commissioners (Mayor + 4 Commissioners at-large); nonpartisan even-year elections; statutory initiative/referendum authorized.
- **Epistemic First-Party Sources:** `Ky. Const. §§ 148, 150, 152, 156b, 160; KRS Ch. 67A, 67C, 82, 83A, 117, 118; 92I Implementation Cargo; Kentucky League of Cities Municipal Handbook (2025/2026)`

---

### US-LA — Louisiana
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `La. Const. Art. VI § 5; La. R.S. Title 33`
  - `[FACT]` Broad constitutional home rule for Home Rule Charters (Art. VI § 5). Non-charter municipalities governed by the Lawrason Act (La. R.S. 33:321 et seq.).
- **Primary Statutory Forms:**
  - `Lawrason Act (Mayor-Board of Aldermen)` (La. R.S. 33:321 et seq.): Default general law form for non-charter municipalities.
  - `Commission` (La. R.S. 33:501 et seq.): Optional statutory form.
  - `Home Rule Charter` (La. Const. Art. VI § 5): Charter commission drafting and voter adoption.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `La. R.S. 18:401 et seq. (Louisiana Open Jungle Primary: all candidates appear on same primary ballot regardless of party affiliation)`)
  - `Election Timing:` `spring_even_year, autumn_gubernatorial` (Statute: `La. R.S. 18:402 (Spring dates in presidential years, or fall dates in gubernatorial off-years)`)
  - `Runoff / Voting Rule:` `majority_50_plus_1` | Trigger: `50.0%` | Statute: `La. R.S. 18:511 (Candidate receiving majority of votes cast in primary is elected; if no candidate clears 50%, top two advance to general election runoff 4 weeks later)`
  - `District / Ward / At-Large:` Options: `single_member_districts, pure_at_large, hybrid_wards_and_at_large` | Default: `pure_at_large (Lawrason towns < 10,000) / single_member_districts (cities > 10,000: La. R.S. 33:382)` (Statute: `La. R.S. 33:382`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct popular election across all forms (4-yr term). Mayor holds veto under Lawrason Act (overridden by 2/3 of aldermen; La. R.S. 33:404).
  - `Administration:` `county_election_board_coordinated` | Authority: `La. R.S. Title 18 (Parish Registrar of Voters and Parish Board of Election Supervisors conduct elections on state-owned voting machines)` | Cost Rule: State pays majority of costs; municipality pays proportional share under La. R.S. 18:1400.1
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `12 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `La. R.S. 18:602`
  - `[FACT]` Governing authority fills vacancy within 20 days. If vacancy occurs with > 1 year remaining in term, Governor calls mandatory special election. If governing authority fails to appoint within 20 days, Governor appoints interim.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `False` | Threshold: `33.3%` of `registered_voters` | Window: `180 days`
    - `Authority:` `La. Const. Art. X § 26; La. R.S. Title 18 Ch. 6-C (§ 18:1300.1 et seq.)`
    - `Mechanics:` Universal statutory right. Tiered thresholds: 40% (<1,000 voters), 33.3% (1k-25k), 25% (25k-50k), 20% (>=50k). Standalone Yes/No recall election; if recalled, seat is declared vacant and filled under normal vacancy rules.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `La. R.S. Title 33` | Notes: Citizen ordinance initiative is NOT authorized in Lawrason Act municipalities; available ONLY where explicitly granted in individual Home Rule Charters (e.g. New Orleans, Baton Rouge).
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `La. R.S. Title 33` | Notes: Protest referendum is absent under general municipal law; referendum exists only where specified by charter or for local tax millage renewals.
- **Named Exceptions & Hero Charters:**
  - **City of New Orleans:** Home Rule Charter; Mayor-Council form; 7-member Council (5 single-member districts, 2 at-large); Strong Mayor with executive veto; quadrennial elections in fall of gubernatorial years.
  - **East Baton Rouge Parish / City of Baton Rouge:** Consolidated City-Parish Government; Mayor-President elected parishwide + 12-member Metropolitan Council elected from single-member districts; fall gubernatorial election cycle.
- **Epistemic First-Party Sources:** `La. Const. Art. VI, X; La. R.S. Title 18 (Election Code), Title 33 (Municipalities); Louisiana Municipal Association Legal Handbook (2025/2026)`

---

### US-ME — Maine
- **Option Family:** `new_england_town_meeting`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Maine Const. Art. VIII-A; 30-A M.R.S. § 2101 et seq. (Home Rule Act)`
  - `[FACT]` Constitutional Home Rule; municipalities have full authority to enact charters and ordinances not expressly prohibited by statute.
- **Primary Statutory Forms:**
  - `Town Meeting / Select Board` (30-A M.R.S. § 2521 et seq.): Default traditional town form across Maine.
  - `Council-Manager` (30-A M.R.S. § 2631 et seq.): Voter adoption under home rule charter.
  - `Mayor-Council` (30-A M.R.S. § 2101): Voter adoption under home rule charter.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `30-A M.R.S. § 2528 (Town elections nonpartisan; Secret ballot / Australian ballot system)`)
  - `Election Timing:` `town_meeting_day_march, even_year_november_consolidated` (Statute: `30-A M.R.S. § 2521 (Annual town meeting held in March or April; Cities frequently coordinate with November even-year election under Title 21-A)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `30-A M.R.S. § 2528 (Plurality election; candidate with greatest number of votes elected; Ranked-Choice Voting authorized for local adoption in charters, e.g. Portland)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, hybrid_districts_and_at_large` | Default: `pure_at_large (Towns: Select Board elected at-large with staggered 3-year terms: 30-A M.R.S. § 2526)` (Statute: `30-A M.R.S. § 2526`)
  - `Mayor Selection:` `direct_popular_election, board_selected_select_board_chair` | Strong vs. Weak: In towns, Select Board elects chair. In cities, Mayor is directly elected or chosen by council; administrative power resides in City Manager unless Strong Mayor charter enacted.
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `30-A M.R.S. § 2528; 21-A M.R.S. § 601 et seq. (Town/City Clerk conducts local elections)` | Cost Rule: 100% municipal responsibility
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `30-A M.R.S. § 2602`
  - `[FACT]` Select Board calls a special town meeting or election to fill vacancy. In charter cities, council appoints until next election or calls special election per charter.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `False` | Threshold: `10.0%` of `votes_cast_for_office` | Window: `30 days`
    - `Authority:` `30-A M.R.S. § 2602(6)`
    - `Mechanics:` Authorized in towns by local ordinance (30-A M.R.S. § 2602(6)). Requires petition signed by 10% of votes cast in last gubernatorial election. Town holds special recall election.
  - `Municipal Initiative:` Authorized: `True` | Type: `town_meeting_warrant` | Threshold: `10.0%` | Exempt Subjects: `administrative_contracts`
    - `Authority:` `30-A M.R.S. § 2522 (Town Meeting Warrant Articles)` | Notes: Petition signed by 10% of voters (or 10 voters in small towns) MANDATES Select Board to insert proposed article into the warrant for next Town Meeting.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `30-A M.R.S. § 2528` | Notes: Towns using referendum ballot system may petition ordinances to vote; charter cities define protest referendum by charter.
- **Named Exceptions & Hero Charters:**
  - **City of Portland:** Council-Manager charter with directly elected full-time Mayor; uses Ranked-Choice Voting (RCV) for Mayor, Council, and School Board; 8-member council (5 districts, 3 at-large); November election timing.
  - **City of Lewiston:** Council-Manager charter; 7 single-member wards + Mayor elected at-large; nonpartisan November odd-year elections.
- **Epistemic First-Party Sources:** `Maine Const. Art. VIII-A; 30-A M.R.S. Title 30-A (Municipalities); Maine Municipal Association Legal Handbook (2025/2026)`

---

### US-MD — Maryland
- **Option Family:** `mid_atlantic_partisan_dillon`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Md. Const. Art. XI-E; Md. Code Ann., Local Gov't (LG) Div. II`
  - `[FACT]` Constitutional Home Rule for Municipalities (Art. XI-E); General Assembly barred from enacting local laws for specific municipalities; municipalities adopt and amend charters under LG § 4-301.
- **Primary Statutory Forms:**
  - `Council-Manager` (Md. Code Local Gov't § 4-101 et seq.): Dominant municipal form in Maryland charters.
  - `Mayor-Council` (Md. Code Local Gov't § 4-101 et seq.): Defined by municipal charters (e.g. Annapolis, Frederick, Rockville).
  - `Commission` (Md. Code Local Gov't § 4-101 et seq.): Defined by municipal charters.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Md. Code Local Gov't § 4-108; Charters (Municipal elections nonpartisan in 156 of 157 municipalities; Baltimore City is PARTISAN)`)
  - `Election Timing:` `spring_annual, odd_year_autumn, even_year_november_consolidated` (Statute: `Md. Code Local Gov't § 4-108 (Each municipality fixes election dates by charter; commonly May, June, or November)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `Local Charters (Plurality default; candidate with greatest votes elected; Takoma Park uses Ranked-Choice Voting)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (small towns) / single_member_districts (larger cities)` (Statute: `Governed by municipal charters`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in Mayor-Council charters (Annapolis, Salisbury). Council-selected or weak mayor in Council-Manager charters.
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `Md. Code Local Gov't § 4-108 (Municipal Board of Supervisors of Elections administers local contests; county provides voter registry list)` | Cost Rule: 100% municipal responsibility
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Local Municipal Charters; Md. Code Local Gov't § 4-108`
  - `[FACT]` Governed strictly by individual municipal charters. Typically council appoints successor to fill remainder of unexpired term, or calls special election if vacancy occurs early in term.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `Md. Const. Art. XI-E; Md. Code Local Gov't`
    - `Mechanics:` Municipal recall is absent in general state law. Available only if explicitly authorized in a municipal charter.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `Md. Code Local Gov't § 4-301` | Notes: Citizen initiative is authorized ONLY for proposing municipal charter amendments (petition signed by 20% of qualified voters under LG § 4-305). General ordinance initiative is not authorized under state law.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `40 days` | Suspends Ordinance: `True` | Threshold: `20.0%`
    - `Authority:` `Md. Code Local Gov't § 4-304` | Notes: Mandatory protest referendum applies to charter amendments passed by council (20% voter petition within 40 days forces referendum). Protest referendum on general ordinances exists where provided by charter.
- **Named Exceptions & Hero Charters:**
  - **City of Baltimore:** Independent City not in any county (Md. Const. Art. XI); PARTISAN elections; 14 single-member council districts + Council President and Mayor elected at-large; quadrennial elections consolidated with presidential election.
  - **City of Annapolis:** Mayor-Aldermanic charter; 8 single-member wards + Mayor; PARTISAN elections (primary in September, general in November of post-gubernatorial odd years, e.g. 2021, 2025).
  - **City of Takoma Park:** Council-Manager charter; uses Ranked-Choice Voting (RCV); permits non-citizen residents and 16-17 year olds to vote in municipal elections.
- **Epistemic First-Party Sources:** `Md. Const. Art. XI, XI-E; Md. Code Ann., Local Gov't (LG) Div. II; Maryland Municipal League Governance Guide (2025/2026)`

---

### US-MA — Massachusetts
- **Option Family:** `new_england_town_meeting`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Mass. Const. Amend. Art. 89 (Home Rule Amendment); M.G.L. c. 43B`
  - `[FACT]` Constitutional Home Rule; municipalities may adopt and revise charters locally, but cannot enact private/civil law or levy taxes without statutory authorization.
- **Primary Statutory Forms:**
  - `Open Town Meeting / Select Board` (M.G.L. c. 39 § 9 et seq.): Default town governance (<6,000 pop).
  - `Representative Town Meeting` (M.G.L. c. 43A): Towns > 6,000 pop opting for elected town meeting members.
  - `Faulkner Act Plans A-F` (M.G.L. c. 43 § 1 et seq.): Standardized optional city charter plans (Plan A: Strong Mayor; Plan B: Weak Mayor; Plan C: Commission; Plan D: Council-Manager with council mayor; Plan E: Council-Manager with PR; Plan F: Partisan Mayor-Council).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_default_partisan_optional` (Statute: `M.G.L. c. 43 § 15; c. 53 (Nonpartisan in towns and all Faulkner plans except Plan F which allows partisan primaries)`)
  - `Election Timing:` `town_meeting_day_spring, odd_year_november_consolidated` (Statute: `M.G.L. c. 39 § 9 (Town meetings held in spring between Feb 1 and May 31); M.G.L. c. 43 § 15 (Cities hold municipal elections on first Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `M.G.L. c. 43 § 44D, c. 54 § 85 (Plurality default; in cities with preliminary nonpartisan elections, top two advance to November)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (Towns: Select Board 3 or 5 members) / hybrid (Cities: ward councillors + at-large councillors)` (Statute: `M.G.L. c. 41 § 1, c. 43 § 50`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership, board_selected_select_board_chair` | Strong vs. Weak: Direct election in Faulkner Plan A and modern city charters (Strong Mayor with executive appointments and veto overridden by 2/3 council; c. 43 § 55). In Plan D/E, Council elects mayor as ceremonial chair.
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `M.G.L. c. 54 (Town/City Clerk and Board of Registrars of Voters administer municipal elections locally)` | Cost Rule: 100% municipal responsibility
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `6 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `M.G.L. c. 41 § 10, c. 43 § 59A`
  - `[FACT]` In towns, special town election called by Select Board or remaining members. In cities under Faulkner Act, council fills vacancy or next highest runner-up in preceding election is seated, or special election held if > 6 months remain.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `M.G.L. c. 43 (Absent in general law; exists only in special legislative charters)`
    - `Mechanics:` Recall is absent under general Massachusetts law. A municipality can obtain recall only by petitioning the General Court (state legislature) for a special act charter.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `12.0%` | Exempt Subjects: `budget_appropriations, school_committee_appointments`
    - `Authority:` `M.G.L. c. 43 § 37 - § 44 (Faulkner Act); c. 39 § 10 (Towns)` | Notes: Under Faulkner Act, petition signed by 8% (regular election) or 12% (special election) of registered voters submitted to city council. If council fails to enact within 20 days, placed on ballot. In towns, 10 voters petition warrant article.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `20 days` | Suspends Ordinance: `True` | Threshold: `12.0%`
    - `Authority:` `M.G.L. c. 43 § 42` | Notes: Under Faulkner Act, petition signed by 12% of registered voters filed within 20 days of ordinance passage suspends ordinance until council repeals or voters ratify.
- **Named Exceptions & Hero Charters:**
  - **City of Boston:** Special Legislative Charter (St. 1909, c. 486, as amended 1951, 1982); Strong Mayor-Council form; 13 councilmembers (9 districts, 4 at-large); preliminary nonpartisan election in September, general election in November odd years; mayor possesses absolute veto over appropriations.
  - **City of Cambridge:** Plan E Council-Manager charter; 9 councilmembers and 6 school committee members elected at-large by Single Transferable Vote (Proportional Representation RCV); council elects Mayor from its membership.
- **Epistemic First-Party Sources:** `Mass. Const. Amend. Art. 89; M.G.L. c. 39 (Town Meetings), c. 43 (City Charters); Massachusetts Municipal Association Legal Guide (2025/2026)`

---

### US-MI — Michigan
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Mich. Const. Art. VII § 22; Home Rule City Act (MCL 117.1 et seq.)`
  - `[FACT]` Strong Constitutional Home Rule; cities have broad power to adopt charters and pass laws relating to municipal concerns, subject to constitution and general laws.
- **Primary Statutory Forms:**
  - `Home Rule City (Council-Manager or Mayor-Council)` (MCL 117.1 et seq.): Dominant municipal form across Michigan.
  - `General Law Village` (MCL 61.1 et seq.): Default village classification.
  - `Home Rule Village` (MCL 78.1 et seq.): Charter village.
  - `Fourth Class City` (MCL 81.1 et seq.): Historical statutory code (mostly transitioned to Home Rule).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_default_partisan_optional` (Statute: `MCL 168.644e (Nonpartisan default in Home Rule cities; Fourth Class cities may conduct partisan elections)`)
  - `Election Timing:` `odd_year_november_consolidated, even_year_november_consolidated` (Statute: `MCL 168.644a (Odd-year November consolidated municipal elections; cities may adopt resolution/charter to hold elections in even-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `MCL 168.644f (Plurality election; nonpartisan primary held in August if more than twice the number of candidates file for a seat)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, hybrid_districts_and_at_large` | Default: `pure_at_large (Council-Manager cities) / single_member_districts (Detroit, Flint)` (Statute: `MCL 117.3(a), MCL 117.3(b)`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in Mayor-Council charters (Detroit: strong mayor with full appointment and veto power). In Council-Manager charters (Grand Rapids, Ann Arbor), mayor is council chair directly elected or selected by council.
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `MCL 168.23 et seq. (City or Township Clerk conducts elections; City Board of Election Commissioners sets up voting precincts)` | Cost Rule: 100% municipal/township responsibility
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `MCL 168.321, MCL 201.37; Local Charters`
  - `[FACT]` Governed by city charter. Default under state law: council fills vacancy by majority vote within 30 days for unexpired term, or calls special election if council deadlocks.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `simultaneous_incumbent_replacement` | Grounds Required: `True` | Threshold: `25.0%` of `last_gubernatorial_vote` | Window: `60 days`
    - `Authority:` `Mich. Const. Art. II § 8; MCL 168.951 et seq.`
    - `Mechanics:` Universal constitutional right. Clarity hearing before county election commission. Petitions require 25% of the total votes cast in the electoral district for Governor in the last election. Recall election is a replacement election: incumbent automatically on ballot unless declining.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `budget_appropriations, tax_levies`
    - `Authority:` `Home Rule City Act (MCL 117.4i)` | Notes: Home Rule City Act mandates that each charter may provide for initiative and referendum. Commonly 10-15% of registered electors. Council must adopt or submit to voters.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `MCL 117.4i` | Notes: Charter-authorized protest referendum suspends ordinance pending vote if filed within statutory/charter window.
- **Named Exceptions & Hero Charters:**
  - **City of Detroit:** Home Rule Charter (2012); Strong Mayor-Council form; 9 councilmembers (7 single-member districts, 2 at-large); Mayor holds veto overridden by 2/3 council; nonpartisan odd-year November elections.
  - **City of Grand Rapids:** Council-Manager charter; 6 commissioners elected from 3 two-member wards (staggered 4-year terms) + Mayor elected at-large; nonpartisan August/November even-year elections.
- **Epistemic First-Party Sources:** `Mich. Const. Art. II, VII; MCL Ch. 117 (Home Rule Cities), Ch. 168 (Michigan Election Law); Michigan Municipal League Handbook (2025/2026)`

---

### US-MN — Minnesota
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Minn. Const. Art. XII § 4; Minn. Stat. Ch. 410 (Home Rule) & Ch. 412 (Statutory Cities)`
  - `[FACT]` Constitutional Home Rule; 107 home-rule charter cities have broad local powers. Remaining ~745 cities are Statutory Cities governed by Minn. Stat. Ch. 412.
- **Primary Statutory Forms:**
  - `Statutory Standard Plan` (Minn. Stat. § 412.02 et seq.): Mayor + 4 councilmembers; clerk and treasurer are independently elected.
  - `Statutory Plan A` (Minn. Stat. § 412.541 et seq.): Weak Mayor-Council default for most statutory cities; clerk and treasurer appointed.
  - `Statutory Plan B (Council-Manager)` (Minn. Stat. § 412.601 et seq.): Voter petition and election; Council appoints city manager.
  - `Home Rule Charter City` (Minn. Stat. Ch. 410): Charter commission drafted and voter adopted.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Minn. Stat. § 205.07, § 205.17 ('The municipal ballot shall be nonpartisan')`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `Minn. Stat. § 205.07 (Consolidated with statewide even-year general election on first Tuesday after first Monday in November; statutory odd-year grandfathering phasing out)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `Minn. Stat. § 205.065 (Plurality election; nonpartisan primary in August held if more than twice the candidates file; Ranked-Choice Voting authorized for home rule charters, e.g. Minneapolis, St. Paul)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (Statutory cities: Mayor + 4 Councilmembers elected at-large with staggered 4-year terms: Minn. Stat. § 412.02)` (Statute: `Minn. Stat. § 412.02; Ch. 410`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (2- or 4-yr term). In Statutory Plan A/B, Mayor is an ordinary member of the 5-member council with NO veto power. Strong Mayor exists only by Home Rule Charter (e.g. Minneapolis, St. Paul, Duluth).
  - `Administration:` `county_election_board_coordinated` | Authority: `Minn. Stat. § 205.07 (County Auditor conducts municipal elections concurrently with federal/state general elections)` | Cost Rule: Pro-rata share billed by county to city treasury under Minn. Stat. § 205.17
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `12 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Minn. Stat. § 412.02 subd. 2b`
  - `[FACT]` Council appoints successor within 90 days. If vacancy occurs before the first day to file for the regular city election and > 2 years remain in a 4-year term, appointee serves only until next election, where a special election fills the remainder.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `Minn. Stat. Ch. 412 (Absent in general law; allowed ONLY in Home Rule Charters)`
    - `Mechanics:` Statutory cities CANNOT adopt recall under Minn. Stat. Ch. 412. Available ONLY if explicitly enacted in a Home Rule Charter adopted pursuant to Minn. Const. Art. XII § 4.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `Minn. Stat. Ch. 412` | Notes: Statutory cities lack authority to adopt citizen initiative for ordinances. Authorized ONLY in Home Rule Charters (e.g. Minneapolis, Duluth).
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `Minn. Stat. Ch. 412` | Notes: Protest referendum against general ordinances is absent in statutory cities. Mandatory referenda apply only to issuing capital improvement bonds and adopting optional plans.
- **Named Exceptions & Hero Charters:**
  - **City of Minneapolis:** Home Rule Charter; Executive Mayor-Legislative Council form (adopted by 2021 charter amendment); 13 single-member wards; Mayor is sole executive head with veto; uses Ranked-Choice Voting (RCV); odd-year municipal elections.
  - **City of Saint Paul:** Strong Mayor-Council charter; 7 single-member wards; directly elected mayor with veto; uses Ranked-Choice Voting (RCV); odd-year municipal elections.
- **Epistemic First-Party Sources:** `Minn. Const. Art. XII; Minn. Stat. Ch. 205 (Municipal Elections), Ch. 410 (Home Rule), Ch. 412 (Statutory Cities); League of Minnesota Cities Information in Depth (2025/2026)`

---

### US-MS — Mississippi
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `dillons_rule_strict` | Authority: `Miss. Code Ann. Title 21; Miss. Const. Art. 4 § 88`
  - `[FACT]` Modified statutory home rule (Miss. Code § 21-17-5); municipalities have powers over municipal affairs not inconsistent with state law, but Dillon's Rule strictly controls taxation and elections.
- **Primary Statutory Forms:**
  - `Code Charter (Mayor-Board of Aldermen)` (Miss. Code § 21-3-1 et seq.): Dominant municipal form across Mississippi (~90% of cities).
  - `Commission` (Miss. Code § 21-5-1 et seq.): Optional statutory form (Mayor + 2 Commissioners).
  - `Council-Manager` (Miss. Code § 21-9-1 et seq.): Voter petition and election.
  - `Mayor-Council (Strong Mayor)` (Miss. Code § 21-8-1 et seq.): Cities > 25,000 pop (Jackson, Gulfport, Biloxi, Hattiesburg, Meridian).
- **Electoral Framework:**
  - `Ballot Type:` `partisan_mandatory` (Statute: `Miss. Code § 21-11-1 et seq. (MANDATORY PARTISAN ELECTIONS: municipal primary elections conducted by municipal party executive committees)`)
  - `Election Timing:` `quadrennial_summer_june` (Statute: `Miss. Code § 21-11-7, § 21-11-11 (First primary on first Tuesday in April; Second primary on fourth Tuesday in April; General Election on first Tuesday after first Monday in June every 4 years, e.g. 2021, 2025, 2029)`)
  - `Runoff / Voting Rule:` `majority_50_plus_1` | Trigger: `50.0%` | Statute: `Miss. Code § 23-15-305 (MANDATORY MAJORITY in party primaries: candidate must receive majority of votes; top-two runoff held 3 weeks later in April; plurality wins in June general election)`
  - `District / Ward / At-Large:` Options: `single_member_wards, hybrid_wards_and_at_large, pure_at_large` | Default: `hybrid_wards_and_at_large (Code Charter cities > 10,000: 6 aldermen from wards, 1 at-large: Miss. Code § 21-3-7)` (Statute: `Miss. Code § 21-3-7, § 21-8-7`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (4-yr term). Strong Mayor under Miss. Code § 21-8-15 (Jackson: full veto overridden by 2/3 council). Weak Mayor under Code Charter (presides, votes on ties, holds suspensive veto overridden by 2/3 aldermen; § 21-3-15).
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `Miss. Code § 21-11-1 (Municipal Election Commission administers general elections; Municipal Party Executive Committees conduct party primaries)` | Cost Rule: 100% municipal responsibility
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `6 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Miss. Code § 23-15-857`
  - `[FACT]` Governing body calls special election within 30 to 45 days. However, if vacancy occurs within 6 months of the end of the 4-year term, governing body appoints successor to serve remainder of term without an election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `True` | Threshold: `30.0%` of `registered_voters` | Window: `None days`
    - `Authority:` `Miss. Code Ann. § 25-5-1 et seq.`
    - `Mechanics:` Governor appoints 3-member removal council of citizens; council investigates and verifies grounds; if certified, Governor orders special recall election. Yes/No vote; if recalled, seat is vacant.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `20.0%` | Exempt Subjects: `tax_levies_and_appropriations`
    - `Authority:` `Miss. Code § 21-5-29 (Commission), § 21-9-43 (Manager)` | Notes: Authorized ONLY in Commission and Council-Manager forms (petition signed by 20% of qualified electors). Barred in Code Charter and Mayor-Council cities.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `20.0%`
    - `Authority:` `Miss. Code § 21-5-31, § 21-9-45` | Notes: Authorized in Commission and Council-Manager forms (20% voter petition within 30 days suspends ordinance). Barred in Code Charters.
- **Named Exceptions & Hero Charters:**
  - **City of Jackson:** Mayor-Council charter (Miss. Code § 21-8-1 et seq.); 7 single-member wards + directly elected Mayor; strong executive administration with veto; quadrennial summer election cycle (June 2021, June 2025).
  - **City of Gulfport:** Mayor-Council form; 7 council districts; strong mayor; quadrennial summer elections.
- **Epistemic First-Party Sources:** `Miss. Const. Art. 4 § 88; Miss. Code Ann. Title 21 (Municipalities), Title 23 (Elections), Title 25 (Public Officers); Mississippi Municipal League Municipal Handbook (2025)`

---

### US-MO — Missouri
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Mo. Const. Art. VI § 19, § 19(a); RSMo Ch. 71-80`
  - `[FACT]` Constitutional Home Rule for any city > 5,000 pop (Art. VI § 19(a)). Broad powers not limited by charter or state constitution. Non-charter cities classified as 3rd Class, 4th Class, or Special Charter.
- **Primary Statutory Forms:**
  - `Fourth Class City (Mayor-Board of Aldermen)` (RSMo Ch. 79): Default statutory form for cities 500 to 2,999 pop.
  - `Third Class City (Mayor-Council)` (RSMo Ch. 77): Statutory form for cities 3,000 to 29,999 pop.
  - `Third Class City (Commission / Manager)` (RSMo Ch. 78): Optional statutory forms for 3rd class cities.
  - `Constitutional Charter City` (Mo. Const. Art. VI § 19): Charter commission election and voter adoption (cities > 5,000).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_default_partisan_optional` (Statute: `RSMo § 115.121 (Nonpartisan default across Missouri; 3rd class cities may opt by ordinance to conduct partisan primaries)`)
  - `Election Timing:` `odd_year_spring, annual_spring_april` (Statute: `RSMo § 115.121 (Municipal Election Day on first Tuesday after first Monday in April annually or in odd-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `RSMo § 115.515 (Plurality election default; candidate with highest vote total elected; City of St. Louis uses nonpartisan approval voting with top-two runoff)`
  - `District / Ward / At-Large:` Options: `two_aldermen_per_ward, single_member_wards, pure_at_large` | Default: `two_aldermen_per_ward (4th Class: RSMo § 79.060; 3rd Class: RSMo § 77.030; staggered 2-year terms)` (Statute: `RSMo § 77.030, § 79.060`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (2- or 4-yr term). Mayor presides, votes on ties, holds veto overridden by 2/3 council in 3rd Class (§ 77.270) and 4th Class (§ 79.140).
  - `Administration:` `county_election_board_coordinated` | Authority: `RSMo § 115.023 (County Clerk or Board of Election Commissioners conducts municipal April elections)` | Cost Rule: Proportionate share billed to municipality under RSMo § 115.063
- **Vacancy Succession Procedure:**
  - `Rule Type:` `mayoral_appointment_council_consent` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `RSMo § 77.240, § 79.280`
  - `[FACT]` In 4th Class cities, Mayor appoints successor with consent of Board of Aldermen. In 3rd Class cities, Board calls special election, or Mayor appoints with council consent until next regular election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `25.0%` of `votes_cast_for_office` | Window: `60 days`
    - `Authority:` `RSMo § 77.650 (3rd Class); Charters`
    - `Mechanics:` Authorized in 3rd Class cities (RSMo § 77.650; 25% signatures) and Charter cities. STRICTLY PROHIBITED in 4th Class cities (state law provides no recall mechanism for 4th class aldermen/mayor).
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `25.0%` | Exempt Subjects: `budget_appropriations, tax_levies`
    - `Authority:` `RSMo § 78.200 (3rd Class Commission); Charters` | Notes: Authorized in 3rd Class optional forms (§ 78.200; 25% signatures) and Charter cities. PROHIBITED in 4th Class cities.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `10 days` | Suspends Ordinance: `True` | Threshold: `25.0%`
    - `Authority:` `RSMo § 78.220; Charters` | Notes: In 3rd Class cities, 25% voter petition filed within 10 days of passage suspends ordinance. In Charter cities, window is typically 30 days.
- **Named Exceptions & Hero Charters:**
  - **City of St. Louis:** Independent City not in any county (Mo. Const. Art. VI § 31); Mayor-Council charter; 14 single-member wards (reduced from 28 in 2023) + Comptroller and Mayor; uses NONPARTISAN APPROVAL VOTING primary in March, with top two advancing to April runoff.
  - **City of Kansas City:** Constitutional Charter City; Council-Manager form; 12 councilmembers (6 in-district, 6 at-large) + Mayor elected at-large; nonpartisan primary in April, general election in June of post-gubernatorial odd years (2023, 2027).
- **Epistemic First-Party Sources:** `Mo. Const. Art. VI; RSMo Ch. 71, 77, 78, 79, 115; Missouri Municipal League Municipal Governance Guide (2025/2026)`

---

### US-MT — Montana
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Mont. Const. Art. XI §§ 5, 6; MCA Title 7 Ch. 3`
  - `[FACT]` Self-Government Powers (Art. XI § 6); municipalities with self-government charters possess all powers not prohibited by constitution, law, or charter.
- **Primary Statutory Forms:**
  - `Commission-Executive (Mayor-Council)` (MCA § 7-3-201 et seq.): General government statutory option.
  - `Commission-Manager` (MCA § 7-3-301 et seq.): General government statutory option.
  - `Commission (Chairman)` (MCA § 7-3-401 et seq.): General government statutory option.
  - `Town Meeting Form` (MCA § 7-3-601 et seq.): Available to incorporated towns < 2,000 pop.
  - `Charter Government` (Mont. Const. Art. XI § 5; MCA § 7-3-701): Self-government charter voter adopted.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `MCA § 13-14-111 ('Candidates for municipal office must be nominated and elected on a nonpartisan ballot')`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `MCA § 13-1-104 (First Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `MCA § 13-14-115 (Plurality election; nonpartisan primary held in September if more than twice the candidates file for a seat)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `two_councilmembers_per_ward (Statutory cities: MCA § 7-3-214; staggered 4-year terms)` (Statute: `MCA § 7-3-156, § 7-3-214`)
  - `Mayor Selection:` `direct_popular_election, commission_selected_from_membership` | Strong vs. Weak: Direct election in Commission-Executive (4-yr term; administrative head with veto overridden by 2/3 council; MCA § 7-3-203). Commission-Manager selects presiding mayor from commission membership.
  - `Administration:` `county_election_board_coordinated` | Authority: `MCA § 13-1-401 (County election administrator conducts municipal general and primary elections)` | Cost Rule: Proportionate costs billed to municipality under MCA § 13-1-402
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `3 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `MCA § 7-4-4112; § 7-3-160`
  - `[FACT]` Governing body appoints successor within 30 days. Appointee serves until next regular municipal election; special election called if vacancy occurs > 85 days before election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `True` | Threshold: `20.0%` of `registered_voters` | Window: `90 days`
    - `Authority:` `Mont. Const. Art. XI § 8; MCA Title 2 Ch. 16 Pt. 6 (Montana Recall Act)`
    - `Mechanics:` Statutory grounds required. Officer may challenge legal sufficiency in District Court before petition circulation. 15% (cities > 1,000) or 20% (< 1,000) signatures. Standalone Yes/No recall election; vacancy filled by appointment.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `appropriations, tax_levies, special_assessments`
    - `Authority:` `Mont. Const. Art. XI § 8; MCA Title 7 Ch. 5 Pt. 1 (§ 7-5-131 et seq.)` | Notes: 15% of registered electors. Governing body must pass ordinance without amendment within 60 days or submit to voters at next election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `60 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Mont. Const. Art. XI § 8; MCA § 7-5-132` | Notes: 10% registered voter petition filed within 60 days of ordinance passage suspends ordinance pending election.
- **Named Exceptions & Hero Charters:**
  - **City and County of Butte-Silver Bow:** Consolidated City-County Government (MCA Title 7 Ch. 3 Pt. 11); Chief Executive directly elected + 12-member Council of Commissioners elected by single-member districts; nonpartisan odd-year elections.
  - **Anaconda-Deer Lodge County:** Consolidated City-County; Commission-CEO charter; 5 single-member districts.
- **Epistemic First-Party Sources:** `Mont. Const. Art. XI; MCA Title 7 (Local Government), Title 13 (Elections); Montana League of Cities and Towns Governance Manual (2025/2026)`

---

### US-NE — Nebraska
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Neb. Const. Art. XI § 2 (Home Rule Charters); Neb. Rev. Stat. Ch. 16, 17, 18, 19`
  - `[FACT]` Constitutional Home Rule for cities > 1,000 pop. General statutory cities classified by population: Metropolitan (Omaha: >300k), Primary (Lincoln: 100k-300k), First Class (5k-100k), Second Class (800-5k), Village (100-800).
- **Primary Statutory Forms:**
  - `Mayor-Council (1st / 2nd Class)` (Neb. Rev. Stat. § 16-302 et seq., § 17-107): Default statutory forms.
  - `Commission` (Neb. Rev. Stat. § 19-401 et seq.): Optional commission plan.
  - `City Manager` (Neb. Rev. Stat. § 19-601 et seq.): Voter petition and election.
  - `Home Rule Charter` (Neb. Const. Art. XI § 2): Omaha and Lincoln operate under home rule charters.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Neb. Rev. Stat. § 32-556 ('All municipal offices shall be nonpartisan offices')`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `Neb. Rev. Stat. § 32-401, § 32-556 (Primary on first Tuesday after second Monday in May; General Election on first Tuesday after first Monday in November of even-numbered years)`)
  - `Runoff / Voting Rule:` `top_two_primary_runoff` | Trigger: `50.0%` | Statute: `Neb. Rev. Stat. § 32-556 (Statewide nonpartisan primary in May eliminates all but top two candidates who advance to November general; plurality in November)`
  - `District / Ward / At-Large:` Options: `single_member_wards, two_councilmembers_per_ward, pure_at_large` | Default: `two_councilmembers_per_ward (1st Class cities: § 16-302; 2nd Class: § 17-102; staggered 4-year terms)` (Statute: `Neb. Rev. Stat. § 16-302, § 17-102`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in Mayor-Council (4-yr term; holds veto overridden by 2/3 council; § 16-303). In City Manager cities, Council elects mayor as president (§ 19-617).
  - `Administration:` `county_election_board_coordinated` | Authority: `Neb. Rev. Stat. § 32-401 et seq. (County Election Commissioner or County Clerk conducts municipal elections on statewide ballot)` | Cost Rule: Proportional reimbursement billed to city by county under § 32-1201
- **Vacancy Succession Procedure:**
  - `Rule Type:` `mayoral_appointment_council_consent` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Neb. Rev. Stat. § 32-568, § 32-569`
  - `[FACT]` Mayor appoints qualified elector with approval of council within 8 weeks. If council deadlocks or fails to confirm, mayor calls special election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `False` | Threshold: `35.0%` of `votes_cast_for_office` | Window: `30 days`
    - `Authority:` `Neb. Rev. Stat. § 32-1301 et seq. (Nebraska Recall Act)`
    - `Mechanics:` Universal statutory recall. 35% of total votes cast for that office at last general election. Rapid circulation window (30 days). Standalone Yes/No ballot; if recalled, vacancy filled by appointment.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `annual_appropriation, emergency_measures`
    - `Authority:` `Neb. Rev. Stat. § 18-2501 et seq. (Municipal Initiative and Referendum Act)` | Notes: 15% of registered voters. City council has 30 days to pass measure without amendment or submit to voters.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `15.0%`
    - `Authority:` `Neb. Rev. Stat. § 18-2527` | Notes: 15% registered voter petition filed within 30 days of passage suspends ordinance pending election.
- **Named Exceptions & Hero Charters:**
  - **City of Omaha:** Metropolitan Class Home Rule Charter; Strong Mayor-Council form; 7 single-member council districts; directly elected Mayor with veto; even-year primary/general schedule consolidated under state law.
  - **City of Lincoln:** Primary Class Home Rule Charter; Mayor-Council form; 7 councilmembers (4 districts, 3 at-large); directly elected Mayor; spring odd-year municipal primary/general schedule (April/May) preserved under home rule charter.
- **Epistemic First-Party Sources:** `Neb. Const. Art. XI § 2; Neb. Rev. Stat. Ch. 16, 17, 18, 19, 32; League of Nebraska Municipalities Guide (2025/2026)`

---

### US-NV — Nevada
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `NRS Title 21 (NRS Ch. 266, 268); Nev. Const. Art. 15 § 3`
  - `[FACT]` Limited statutory home rule (NRS 268.0015 - 2015 Local Government Powers Act); General Law cities governed by NRS Ch. 266; 12 cities operate under special legislative charters.
- **Primary Statutory Forms:**
  - `General Law City (Mayor-Council)` (NRS Ch. 266): Statutory default.
  - `Council-Manager (General Law)` (NRS § 266.415): Council creates city manager by ordinance.
  - `Special Legislative Charter City` (NRS Title 21 (Local Charter Acts)): 12 cities (Las Vegas, Reno, Henderson, Sparks, Carson City, etc.).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `NRS § 293C.110 ('All municipal elections must be nonpartisan')`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `NRS § 293C.110 (Preemptively consolidated all municipal elections with statewide even-year Primary in June and General in November)`)
  - `Runoff / Voting Rule:` `top_two_primary_runoff` | Trigger: `50.0%` | Statute: `NRS § 293C.180 (Primary in June eliminates all but top two candidates who advance to November; if a candidate in a charter city receives majority in primary, charter may declare them elected)`
  - `District / Ward / At-Large:` Options: `single_member_wards, pure_at_large, hybrid_wards_and_at_large` | Default: `single_member_wards (Las Vegas: 6 wards; Reno: 6 wards; Henderson: 4 wards)` (Statute: `NRS § 266.095; Individual City Charters`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all cities (4-yr term). 12-YEAR LIFETIME TERM LIMIT applies to all municipal elected officials under Nev. Const. Art. 15 § 3. Council-Manager form dominates; mayor is council member/presiding officer with ceremonial headship.
  - `Administration:` `county_election_board_coordinated` | Authority: `NRS § 293C.110 (County Registrar of Voters / County Clerk conducts municipal elections)` | Cost Rule: Pro-rata reimbursement of direct costs to county
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `NRS § 266.225; Local Charters`
  - `[FACT]` City council appoints qualified elector to fill vacancy within 30 days. If council fails to agree within 30 days, special election called (§ 266.225).
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `25.0%` of `votes_cast_for_office` | Window: `90 days`
    - `Authority:` `Nev. Const. Art. 2 § 9; NRS Ch. 306`
    - `Mechanics:` Universal constitutional right. 25% of voters who actually voted in the election at which the officer was elected. Two-question ballot: (1) 'Shall [Officer] be recalled?' (2) Successor ballot.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `appropriations, tax_levies`
    - `Authority:` `Nev. Const. Art. 19 § 4; NRS § 295.205 et seq.` | Notes: 15% of registered voters. Council has 30 days to enact ordinance without change or submit to voters at next general election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Nev. Const. Art. 19 § 4; NRS § 295.210` | Notes: 10% of registered voters filed within 30 days suspends ordinance until council repeals or voters ratify.
- **Named Exceptions & Hero Charters:**
  - **City of Las Vegas:** Special Legislative Charter; Council-Manager form; 6 single-member wards + Mayor elected at-large; 12-year lifetime term limit; even-year November elections.
  - **Carson City:** Consolidated Municipality (exercising both city and county functions); Board of Supervisors (4 ward supervisors + directly elected Mayor); nonpartisan even-year elections.
- **Epistemic First-Party Sources:** `Nev. Const. Art. 2, 15, 19; NRS Title 21 (Cities), Ch. 293C, Ch. 295, Ch. 306; Nevada League of Cities Handbook (2025/2026)`

---

### US-NH — New Hampshire
- **Option Family:** `new_england_town_meeting`
- **Home Rule Foundation:** `dillons_rule_strict` | Authority: `N.H. Const. Pt. I Art. 39; RSA Title 3 (Towns), Title 4 (Cities), RSA 49-B`
  - `[FACT]` Strict Dillon's Rule; municipal charter options authorized only pursuant to RSA 49-B (Home Rule Municipal Charters) within narrow legislative bounds.
- **Primary Statutory Forms:**
  - `Traditional Town Meeting / Selectmen` (RSA 39:1 et seq., RSA 41:8 et seq.): Default traditional governance for NH towns.
  - `Official Ballot Town Meeting (SB 2)` (RSA 40:13): Voter 3/5 supermajority adoption (deliberative session + voting day).
  - `Town Council / Manager` (RSA 49-D): Voter adoption under RSA 49-B.
  - `City Charter (Mayor-Aldermen or Council-Manager)` (RSA 44 & RSA 49-C): 13 incorporated cities operating under legislative charters.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `RSA 669:1 et seq. (Town elections nonpartisan; city charters prescribe nonpartisan ballots)`)
  - `Election Timing:` `town_meeting_day_march, odd_year_november_consolidated` (Statute: `RSA 669:1 (Annual town meeting on second Tuesday in March; Cities hold municipal elections on first Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `RSA 669:54 (Plurality election; candidate receiving highest number of votes elected; no runoffs)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (Towns: Board of Selectmen 3 or 5 members: RSA 41:8; staggered 3-year terms)` (Statute: `RSA 41:8, RSA 44:4`)
  - `Mayor Selection:` `direct_popular_election, board_selected_select_board_chair` | Strong vs. Weak: In towns, Selectmen elect chair. In cities, Mayor directly elected (Manchester, Nashua: strong executive authority with veto; RSA 44:11).
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `RSA 669:7 (Town/City Clerk and elected Town Moderators conduct all local elections)` | Cost Rule: 100% municipal responsibility
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `RSA 669:61, RSA 669:63`
  - `[FACT]` Remaining Selectmen appoint successor until next annual Town Meeting. In cities, Board of Aldermen fills vacancy or special municipal election called per charter.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `RSA Title 3 & 4 (Absent in general law; NH Supreme Court bars recall absent statute)`
    - `Mechanics:` Recall is PROHIBITED under general law. Removal of municipal officials is available only for cause via Superior Court judicial hearing under RSA 41:16-c.
  - `Municipal Initiative:` Authorized: `True` | Type: `town_meeting_warrant` | Threshold: `None%` | Exempt Subjects: `appropriations_must_be_voted_at_meeting`
    - `Authority:` `RSA 39:3 (Town Meeting Warrant Articles)` | Notes: 25 or more registered voters petition Selectmen to include any warrant article on annual Town Meeting warrant; Selectmen have mandatory duty to insert.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `RSA 40:13 (Official Ballot Referendum / SB 2)` | Notes: Under SB 2, all warrant articles are voted on by secret official ballot on second Tuesday in March following a deliberative session.
- **Named Exceptions & Hero Charters:**
  - **City of Manchester:** Mayor-Aldermen legislative charter; 14 wards (12 single-member, 2 at-large aldermen) + directly elected Mayor; nonpartisan odd-year November elections.
  - **City of Nashua:** Mayor-Aldermen charter; 15 aldermen (9 wards, 6 at-large) + Mayor; odd-year November elections.
- **Epistemic First-Party Sources:** `N.H. Const. Pt. I Art. 39; N.H. RSA Title 3 (Towns), Title 4 (Cities), Title 63 (Elections); New Hampshire Municipal Association Handbook (2025/2026)`

---

### US-NJ — New Jersey
- **Option Family:** `mid_atlantic_partisan_dillon`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `N.J. Const. Art. IV § VII par. 11; Optional Municipal Charter Law (Faulkner Act, N.J.S.A. 40:69A-1 et seq.)`
  - `[FACT]` Constitutional construction in favor of municipal powers; wide menu of statutory forms under Faulkner Act and traditional codes (Borough, Township, Commission, 1923 Manager).
- **Primary Statutory Forms:**
  - `Faulkner Act Plan A (Mayor-Council)` (N.J.S.A. 40:69A-31 et seq.): Strong Mayor directly elected + Council of 5, 7, or 9 members.
  - `Faulkner Act Plan B (Council-Manager)` (N.J.S.A. 40:69A-81 et seq.): Council of 5, 7, or 9 appoints professional Manager.
  - `Faulkner Act Plan C / D (Small Municipality / Administrator)` (N.J.S.A. 40:69A-115, 149): Optional small-city plans.
  - `Borough Form` (N.J.S.A. 40A:60-1 et seq.): Mayor + 6 Councilmembers; weak mayor default for ~218 boroughs.
  - `Township Committee` (N.J.S.A. 40A:63-1 et seq.): Township Committee of 3 or 5 members electing Mayor.
  - `Walsh Act Commission` (N.J.S.A. 40:70-1 et seq.): 3 or 5 commissioners (e.g. Atlantic City).
- **Electoral Framework:**
  - `Ballot Type:` `partisan_default_nonpartisan_optional` (Statute: `N.J.S.A. 19:1-1 et seq. (Partisan general elections default in Boroughs/Townships; Faulkner Act permits nonpartisan option under N.J.S.A. 40:69A-161.1)`)
  - `Election Timing:` `odd_year_november_consolidated, spring_annual, even_year_november_consolidated` (Statute: `N.J.S.A. 40:69A-161.1 (Faulkner cities may hold nonpartisan elections on second Tuesday in May, or in November; Boroughs/Townships hold partisan elections in November annually)`)
  - `Runoff / Voting Rule:` `locally_selectable` | Trigger: `50.0%` | Statute: `N.J.S.A. 40:69A-160, 40:69A-161.1 (Faulkner nonpartisan municipalities may opt for majority runoff or pure plurality; runoff held on 4th Tuesday after election)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (Boroughs: 6 councilmembers elected at-large: N.J.S.A. 40A:60-2) / hybrid in Faulkner cities` (Statute: `N.J.S.A. 40:69A-33, N.J.S.A. 40A:60-2`)
  - `Mayor Selection:` `direct_popular_election, committee_selected_from_membership` | Strong vs. Weak: Direct election in Faulkner Mayor-Council (strong executive with veto; N.J.S.A. 40:69A-41). Weak mayor in Boroughs (presides, votes on ties, holds suspensive veto overridden by 2/3 council; N.J.S.A. 40A:60-5). In Townships, committee selects mayor.
  - `Administration:` `county_election_board_coordinated` | Authority: `N.J.S.A. Title 19 (County Board of Elections and County Clerk conduct November elections; Municipal Clerk conducts May nonpartisan elections)` | Cost Rule: Reimbursed to county in November; 100% municipal in May
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `True` | Citizen Override: `False`
  - `Statutes:` `Municipal Vacancy Law (N.J.S.A. 40A:16-1 et seq.)`
  - `[FACT]` PARTISAN NOMINATION REQUIREMENT: In partisan seats, municipal party committee submits 3 names within 15 days; governing body must appoint one within 30 days! If governing body deadlocks, remaining party members appoint. Next general election fills remainder of term. Nonpartisan seats filled directly by council.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `25.0%` of `registered_voters` | Window: `160 days`
    - `Authority:` `N.J. Const. Art. I par. 2(b); N.J.S.A. 19:27A-1 et seq. (Uniform Recall Election Law)`
    - `Mechanics:` Universal constitutional right across all municipal forms. 25% of registered voters. Two-question ballot: (1) 'Shall [Officer] be recalled?' (2) Successor candidates.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `operating_budget, salaries_of_officers_fixed_by_ordinance, zoning`
    - `Authority:` `Faulkner Act (N.J.S.A. 40:69A-184 et seq.)` | Notes: Authorized ONLY in Faulkner Act municipalities (10% registered voters for regular election; 15% for special election). Council must pass within 20 days or submit to voters. PROHIBITED in traditional Boroughs and Townships.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `20 days` | Suspends Ordinance: `True` | Threshold: `15.0%`
    - `Authority:` `Faulkner Act (N.J.S.A. 40:69A-185)` | Notes: Authorized in Faulkner Act cities (15% registered voter petition filed within 20 days suspends ordinance until council repeals or voters approve).
- **Named Exceptions & Hero Charters:**
  - **City of Newark:** Faulkner Act Mayor-Council Plan; 9 councilmembers (5 wards, 4 at-large); directly elected Strong Mayor; nonpartisan municipal elections held on second Tuesday in May (runoff in June).
  - **City of Jersey City:** Faulkner Act Mayor-Council Plan; 9 councilmembers (6 wards, 3 at-large); directly elected Strong Mayor; nonpartisan elections held in November of odd-numbered years (voter referendum moved date from May to November).
- **Epistemic First-Party Sources:** `N.J. Const. Art. I, IV; N.J.S.A. Title 19 (Elections), Title 40:69A (Faulkner Act), Title 40A (Municipalities); New Jersey State League of Municipalities Municipal Handbook (2025/2026)`

---

### US-NM — New Mexico
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `N.M. Const. Art. X § 6 (Municipal Home Rule Amendment); NMSA 1978 Ch. 3`
  - `[FACT]` Constitutional Home Rule; charter cities have all legislative powers not expressly denied by general law or charter. Non-charter cities governed by NMSA Ch. 3.
- **Primary Statutory Forms:**
  - `Mayor-Council` (NMSA 1978 § 3-12-1 et seq.): Default statutory form across New Mexico.
  - `Commission-Manager` (NMSA 1978 § 3-14-1 et seq.): Cities > 3,000 pop opting into manager plan.
  - `Charter Municipality` (NMSA 1978 § 3-15-1 et seq.): Charter commission drafting and voter adoption.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `NMSA 1978 § 1-22-3 (Local Election Act mandates strictly nonpartisan ballots)`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `NMSA 1978 § 1-22-3 (Regular Local Election held on first Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `NMSA 1978 § 1-22-16 (Plurality default; municipality may by ordinance adopt top-two runoff requirement with 40% or 50% threshold under § 1-22-16(B))`
  - `District / Ward / At-Large:` Options: `single_member_districts, pure_at_large, hybrid_districts_and_at_large` | Default: `single_member_districts (NMSA § 3-12-1; cities divided into 4 to 8 council districts; staggered 4-year terms)` (Statute: `NMSA 1978 § 3-12-1, § 3-14-6`)
  - `Mayor Selection:` `direct_popular_election, commission_selected_from_membership` | Strong vs. Weak: Direct election in Mayor-Council (4-yr term; holds veto overridden by 2/3 council; NMSA § 3-11-5). In Commission-Manager, Commission selects mayor as presiding officer (§ 3-14-10).
  - `Administration:` `county_election_board_coordinated` | Authority: `NMSA 1978 § 1-22-1 et seq. (Local Election Act consolidated all local elections under County Clerk)` | Cost Rule: State Local Election Assessment Fund pays operational costs; no direct municipal billing
- **Vacancy Succession Procedure:**
  - `Rule Type:` `mayoral_appointment_council_consent` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `NMSA 1978 § 3-11-3, § 3-12-1`
  - `[FACT]` Council vacancy: Mayor appoints qualified elector with advice and consent of council. Mayor vacancy: Council elects one of its own members as mayor for remainder of unexpired term.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `True` | Threshold: `20.0%` of `registered_voters` | Window: `60 days`
    - `Authority:` `NMSA 1978 § 3-14-15 (Commission-Manager); Charters`
    - `Mechanics:` Authorized in Commission-Manager cities (§ 3-14-15; 20% signatures) and Charter cities (Albuquerque: 33.3% signatures). Barred in standard Mayor-Council statutory cities.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `20.0%` | Exempt Subjects: `budget_appropriations, tax_levies`
    - `Authority:` `NMSA 1978 § 3-14-17 (Commission-Manager); Charters` | Notes: Authorized in Commission-Manager cities (20% registered voters) and Charter cities. Council must pass within 30 days or submit to election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `20.0%`
    - `Authority:` `NMSA 1978 § 3-14-17` | Notes: In Commission-Manager cities, 20% registered voter petition filed within 30 days suspends ordinance until voted upon.
- **Named Exceptions & Hero Charters:**
  - **City of Albuquerque:** Home Rule Charter; Mayor-Council form (adopted 1974); 9 single-member council districts; directly elected full-time Mayor with veto (overridden by 2/3 council); nonpartisan November odd-year elections with 50%+1 runoff.
  - **City of Santa Fe:** Charter City; Mayor-Council form; 8 councilors (4 two-member districts) + directly elected Mayor; uses Ranked-Choice Voting (RCV) for all municipal offices.
- **Epistemic First-Party Sources:** `N.M. Const. Art. X § 6; NMSA 1978 Ch. 1 (Local Election Act), Ch. 3 (Municipalities); New Mexico Municipal League Handbook (2025/2026)`

---

### US-NY — New York
- **Option Family:** `mid_atlantic_partisan_dillon`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `N.Y. Const. Art. IX (Home Rule); Municipal Home Rule Law (MHRL); Town Law; Village Law`
  - `[FACT]` Constitutional Home Rule; local governments have power to adopt local laws relating to property, affairs, or government, but Dillon's Rule strictly bars local variation on election laws, taxation, and recall.
- **Primary Statutory Forms:**
  - `General City (Mayor-Council)` (General City Law; Second Class Cities Law): 62 incorporated cities operating under individual charters.
  - `Town (Town Board / Supervisor)` (Town Law § 20, § 60): 932 towns; Town Supervisor + 4 Councilpersons.
  - `Village (Mayor-Board of Trustees)` (Village Law § 3-301): 530+ villages; Mayor + 4 Trustees.
  - `Council-Manager` (MHRL § 10; Charter): Optional charter plan (Rochester, Yonkers historically).
- **Electoral Framework:**
  - `Ballot Type:` `partisan_mandatory` (Statute: `N.Y. Election Law § 6-108, § 6-110 (MANDATORY PARTISAN ELECTIONS: party nominations via June primary or town caucus; independent nominating petitions)`)
  - `Election Timing:` `odd_year_november_consolidated, spring_annual` (Statute: `N.Y. Election Law § 8-100 (Primary in June; General Election on first Tuesday after first Monday in November of odd-numbered years; independent villages hold March/June elections)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `N.Y. Election Law § 9-212 (Plurality election; candidate with highest vote total elected; NYC uses Ranked-Choice Voting in primaries only under City Charter § 1057-g)`
  - `District / Ward / At-Large:` Options: `single_member_wards, pure_at_large, hybrid_wards_and_at_large` | Default: `pure_at_large (Towns & Villages) / single_member_districts (Cities per individual charters)` (Statute: `Town Law § 20, Village Law § 3-301, Local City Charters`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct popular election across all cities and villages (2- or 4-yr term). Strong Mayor in major cities (NYC, Buffalo, Syracuse, Albany: executive appointments, veto overridden by 2/3 council). In towns, Supervisor is presiding town board member.
  - `Administration:` `county_election_board_coordinated` | Authority: `N.Y. Election Law § 3-200 et seq. (Bipartisan County Board of Elections conducts all general, primary, and town elections; villages may conduct independent March elections)` | Cost Rule: Apportioned and charged back to municipality under N.Y. Elec. Law § 4-136
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Public Officers Law § 42; Town Law § 64(5); Village Law § 3-312`
  - `[FACT]` Governing board appoints successor until December 31 following next general election. Next general election fills remainder of unexpired term. In villages, Mayor appoints trustee vacancy.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `Matter of Cassella v. City of Schenectady, 281 A.D. 428 (1953); Public Officers Law § 36`
    - `Mechanics:` MUNICIPAL RECALL IS UNCONSTITUTIONAL IN NEW YORK. Appellate Division ruled that local recall charters violate state public officers law and constitution. Removal available ONLY via judicial proceeding in Appellate Division for malfeasance under Public Officers Law § 36.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `Municipal Home Rule Law § 37` | Notes: Citizen initiative for ordinary municipal ordinances is PROHIBITED. Voter initiative permitted ONLY for proposing amendments to a city charter (petition signed by 30,000 electors or 10% of votes cast for Governor under MHRL § 37).
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `45 days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `Municipal Home Rule Law §§ 23, 24` | Notes: No general protest referendum on ordinary ordinances. Permissive referendum (protest petition) applies ONLY to structural local laws enumerated in MHRL § 24 (e.g. changing term of office, reducing council salary, curtailing powers of elected official).
- **Named Exceptions & Hero Charters:**
  - **City of New York (NYC):** Charter of the City of New York; Strong Mayor-Council form; 51 single-member council districts + Comptroller, Public Advocate, and Mayor; PARTISAN elections; uses Ranked-Choice Voting in PARTISAN PRIMARIES only (Charter § 1057-g); odd-year November general elections.
  - **City of Buffalo:** Strong Mayor-Council charter; 9 council districts + directly elected Mayor with veto; odd-year partisan elections.
- **Epistemic First-Party Sources:** `N.Y. Const. Art. IX; N.Y. Municipal Home Rule Law (MHRL); N.Y. Election Law; N.Y. Public Officers Law § 36, § 42; Matter of Cassella v. City of Schenectady, 281 A.D. 428; New York State Conference of Mayors (NYCOM) Handbook (2025/2026)`

---

### US-NC — North Carolina
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `dillons_rule_strict` | Authority: `N.C. Const. Art. VII § 1; N.C.G.S. Ch. 160A`
  - `[FACT]` Strict Dillon's Rule state; General Assembly exercises broad control over municipal powers; municipalities have only powers expressly granted by general law or local charter acts.
- **Primary Statutory Forms:**
  - `Council-Manager` (N.C.G.S. § 160A-147 et seq.): Dominant municipal form across NC (~85% of cities).
  - `Mayor-Council` (N.C.G.S. § 160A-61 et seq.): Statutory default for smaller towns.
- **Electoral Framework:**
  - `Ballot Type:` `charter_determined` (Statute: `N.C.G.S. § 163-291 (State law provides 4 electoral options selectable by charter: (1) Nonpartisan plurality, (2) Nonpartisan runoff, (3) Nonpartisan primary, or (4) Partisan primary and election)`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `N.C.G.S. § 163-279 (First Tuesday after first Monday in November of odd-numbered years; e.g. 2023, 2025, 2027)`)
  - `Runoff / Voting Rule:` `locally_selectable` | Trigger: `50.0%` | Statute: `N.C.G.S. § 163-293 (Under nonpartisan runoff option, majority required; runner-up may demand second election held 4 weeks later; if not demanded, leading candidate elected)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, residency_districts_elected_at_large, hybrid_wards_and_at_large` | Default: `pure_at_large (small towns) / hybrid (Charlotte, Raleigh, Greensboro)` (Statute: `N.C.G.S. § 160A-101`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Mayor elected at-large in ~95% of charters (2- or 4-yr term). Under Council-Manager form, Mayor is presiding council member with ceremonial duties and NO veto power (N.C.G.S. § 160A-69).
  - `Administration:` `county_election_board_coordinated` | Authority: `N.C.G.S. § 163-280 (County Board of Elections conducts all municipal elections)` | Cost Rule: 100% reimbursed by municipality to county board under N.C.G.S. § 163-284
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `N.C.G.S. § 160A-63`
  - `[FACT]` Governing board fills vacancy by majority vote for the remainder of the unexpired term. In partisan cities, board must appoint person recommended by party executive committee.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `N.C.G.S. Ch. 160A (Absent in general law; exists only in ~30 local charter acts)`
    - `Mechanics:` Recall is PROHIBITED under general state law. Available ONLY where enacted by the General Assembly in a specific local legislative charter act (e.g. Raleigh, Durham, Greensboro).
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `N.C.G.S. Ch. 160A` | Notes: Citizen ordinance initiative is PROHIBITED under general law; voter initiative permitted only on structural charter amendments under N.C.G.S. § 160A-104 (10% voter petition).
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `N.C.G.S. Ch. 160A` | Notes: No general statutory protest referendum mechanism on municipal ordinances.
- **Named Exceptions & Hero Charters:**
  - **City of Charlotte:** Council-Manager charter; 11 councilmembers (7 districts, 4 at-large) + Mayor; PARTISAN odd-year elections (primary in September, general in November); no recall.
  - **City of Raleigh:** Council-Manager charter; 8 councilmembers (5 districts, 2 at-large, 1 Mayor); nonpartisan odd-year elections; charter contains legislative recall provision.
- **Epistemic First-Party Sources:** `N.C. Const. Art. VII; N.C.G.S. Ch. 160A (Cities), Ch. 163 (Elections); North Carolina League of Municipalities Handbook (2025/2026)`

---

### US-ND — North Dakota
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `N.D. Const. Art. VII § 6; N.D.C.C. Ch. 40-05.1 (Home Rule)`
  - `[FACT]` Constitutional Home Rule; cities may adopt home rule charters superseding conflicting state statutes on municipal matters.
- **Primary Statutory Forms:**
  - `Council (Mayor-Council)` (N.D.C.C. Ch. 40-08): Default statutory form (Mayor + Aldermen).
  - `Commission` (N.D.C.C. Ch. 40-09): President + 4 Commissioners elected at-large.
  - `Modern Council` (N.D.C.C. Ch. 40-04.1): Council-Manager optional plan.
  - `Home Rule Charter` (N.D.C.C. Ch. 40-05.1): Charter commission drafted and voter adopted.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `N.D.C.C. § 40-21-06 ('All municipal officers must be nominated and elected on nonpartisan ballots')`)
  - `Election Timing:` `even_year_june_consolidated` (Statute: `N.D.C.C. § 40-21-02 (Second Tuesday in June of even-numbered years, consolidated with statewide primary election)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `N.D.C.C. § 40-21-17 (Plurality election; candidate receiving highest number of votes elected; no runoffs; Fargo uses Approval Voting)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `single_member_wards (Council cities: N.D.C.C. § 40-08-01) / at-large (Commission cities: § 40-09-01)` (Statute: `N.D.C.C. § 40-08-01, § 40-09-01`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (4-yr term). In Council cities, Mayor presides, votes on ties, holds veto overridden by 2/3 council (§ 40-08-07). In Commission cities, President of Board of City Commissioners is executive head.
  - `Administration:` `county_election_board_coordinated` | Authority: `N.D.C.C. § 40-21-02 (County Auditor conducts municipal election in June concurrently with state primary)` | Cost Rule: Proportional reimbursement of costs to county under N.D.C.C. § 16.1-05-05
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `N.D.C.C. § 40-08-08, § 40-09-10`
  - `[FACT]` Governing body appoints successor or calls special election. Appointee serves until next biennial municipal election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `simultaneous_incumbent_replacement` | Grounds Required: `False` | Threshold: `25.0%` of `last_gubernatorial_vote` | Window: `90 days`
    - `Authority:` `N.D.C.C. § 44-08-21; N.D. Const. Art. VII § 6`
    - `Mechanics:` Universal statutory recall. 25% of total votes cast for Governor in that jurisdiction in last general election. Replacement election format: incumbent automatically on ballot unless resigning.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `appropriations, tax_levies`
    - `Authority:` `N.D.C.C. Ch. 40-12 (§ 40-12-01 et seq.)` | Notes: Authorized in Commission and Modern Council forms (§ 40-12-02; 15% of votes cast for executive head). Council must enact without alteration within 20 days or submit to voters.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `10 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `N.D.C.C. § 40-12-08` | Notes: 10% voter petition filed within 10 days of passage suspends ordinance until council repeals or election held.
- **Named Exceptions & Hero Charters:**
  - **City of Fargo:** Home Rule Charter; Commission form; 4 Commissioners + Mayor elected at-large; uses APPROVAL VOTING for City Commission and Mayor (adopted by voter initiative 2018); even-year June elections.
  - **City of Bismarck:** Home Rule Charter; Board of City Commissioners (4 commissioners + President/Mayor); even-year June elections.
- **Epistemic First-Party Sources:** `N.D. Const. Art. VII; N.D.C.C. Title 40 (Municipalities), Title 44 (Officers); North Dakota League of Cities Handbook (2025/2026)`

---

### US-OH — Ohio
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Ohio Const. Art. XVIII §§ 3, 7 (1912 Home Rule Amendment); R.C. Title 7`
  - `[FACT]` Plenary Constitutional Home Rule (Art. XVIII § 3); municipalities have all powers of local self-government. Non-charter cities governed by Ohio Revised Code Title 7.
- **Primary Statutory Forms:**
  - `Statutory City Plan (Mayor-Council)` (R.C. § 731.01 et seq., § 733.01 et seq.): Default general law form for non-charter cities (>5,000 pop).
  - `Statutory Village Plan (Mayor-Council)` (R.C. § 731.09 et seq.): Default general law form for villages (<5,000 pop).
  - `Optional Statutory Plans (Commission, Manager, Federal)` (R.C. Ch. 705): Voter referendum adoption under optional charter law.
  - `Constitutional Charter Municipality` (Ohio Const. Art. XVIII § 7): Charter commission drafted and voter adopted.
- **Electoral Framework:**
  - `Ballot Type:` `partisan_default_nonpartisan_optional` (Statute: `R.C. § 3513.01, § 3505.04 (MANDATORY PARTISAN ELECTIONS in statutory cities: candidates run in party primaries in May; Charter cities universally prescribe nonpartisan ballots under Art. XVIII § 3)`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `R.C. § 3501.01, § 3501.02 (Primary on first Tuesday after first Monday in May; General Election on first Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `R.C. § 3505.33 (Plurality election; candidate with highest vote total elected; no general election runoffs)`
  - `District / Ward / At-Large:` Options: `hybrid_wards_and_at_large, pure_at_large, single_member_wards` | Default: `hybrid_wards_and_at_large (Statutory cities: 7 councilmembers: 4 ward, 3 at-large: R.C. § 731.01; 2-year terms)` (Statute: `R.C. § 731.01, § 731.09`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in statutory cities (4-yr term; full executive administration, veto overridden by 2/3 council; R.C. § 731.27, § 733.01). In statutory villages, Mayor presides, votes on ties, holds veto. Charter cities establish strong mayor (Cleveland, Columbus, Cincinnati) or council-manager (Dayton).
  - `Administration:` `county_election_board_coordinated` | Authority: `R.C. § 3501.11 (Bipartisan County Board of Elections conducts all municipal elections)` | Cost Rule: Proportionate share billed by county to municipal treasury under R.C. § 3501.17
- **Vacancy Succession Procedure:**
  - `Rule Type:` `party_precinct_committeeperson_caucus` | Special Election Cutoff: `None months` | Party Caucus Succession: `True` | Citizen Override: `False`
  - `Statutes:` `R.C. § 733.31 (Cities), R.C. § 731.43 (Villages)`
  - `[FACT]` PARTISAN CAUCUS SUCCESSION: In statutory cities, when a partisan municipal officer vacates, the vacancy is filled SOLELY by a private caucus of the central committee members of the political party that nominated the vacating official within 30 days! (R.C. § 733.31). In villages and nonpartisan charter cities, council appoints successor.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `20.0%` of `votes_cast_for_office` | Window: `None days`
    - `Authority:` `Ohio Const. Art. II § 1f; R.C. Ch. 705; Charters`
    - `Mechanics:` Statutory cities under Title 7 lack recall; universally adopted in Charter cities pursuant to Home Rule Amendment (typically 15-25% signatures).
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `10.0%` | Exempt Subjects: `appropriations_for_current_expenses`
    - `Authority:` `Ohio Const. Art. II § 1f; R.C. § 731.28` | Notes: UNIVERSAL CONSTITUTIONAL RIGHT. 10% of electors who voted for Governor at last election. Petition filed with city auditor; auditor certifies to board of elections after 10 days.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Ohio Const. Art. II § 1f; R.C. § 731.29` | Notes: UNIVERSAL CONSTITUTIONAL RIGHT. 10% voter petition filed within 30 days of ordinance passage SUSPENDS ordinance until approved at next general election.
- **Named Exceptions & Hero Charters:**
  - **City of Columbus:** Home Rule Charter; Mayor-Council form; 9 councilmembers (elected by residential districts at-large, transitioned 2023) + Mayor; nonpartisan odd-year primary (May) and general (November).
  - **City of Cleveland:** Home Rule Charter; Mayor-Council form; 17 single-member wards + directly elected Mayor; nonpartisan primary in September, general in November of odd-numbered years.
  - **City of Cincinnati:** Home Rule Charter; Mayor-Council form; 9 councilmembers elected pure at-large + Mayor directly elected with strong administrative power; odd-year November elections.
- **Epistemic First-Party Sources:** `Ohio Const. Art. II § 1f, Art. XVIII §§ 3, 7; Ohio Revised Code Title 7 (Municipalities), Title 35 (Elections); Ohio Municipal League Handbook (2025/2026)`

---

### US-OK — Oklahoma
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Okla. Const. Art. XVIII § 3(a); 11 O.S. § 1-101 et seq. (Oklahoma Municipal Code)`
  - `[FACT]` Constitutional Home Rule for cities > 2,000 pop (Art. XVIII § 3(a)); charter prevails over conflicting state laws relating strictly to municipal affairs.
- **Primary Statutory Forms:**
  - `Statutory Aldermanic` (11 O.S. § 9-101 et seq.): Mayor + 2 aldermen per ward; weak mayor.
  - `Statutory Council-Manager` (11 O.S. § 10-101 et seq.): Council of 5 members; appoints manager.
  - `Statutory Strong-Mayor-Council` (11 O.S. § 11-101 et seq.): Mayor + 4 or 6 councilmembers.
  - `Town (Board of Trustees)` (11 O.S. § 12-101 et seq.): Board of Trustees of 3 or 5 members.
  - `Home Rule Charter` (Okla. Const. Art. XVIII § 3(a); 11 O.S. § 13-101): Charter drafted by board of freeholders.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_default_partisan_optional` (Statute: `11 O.S. § 16-101 et seq. (Nonpartisan default; political party committee may petition for partisan primary: 11 O.S. § 16-106)`)
  - `Election Timing:` `odd_year_spring` (Statute: `11 O.S. § 16-101 (Primary on second Tuesday in February; General Election on first Tuesday in April of odd-numbered years; cities may adopt resolution to hold elections in even-numbered years)`)
  - `Runoff / Voting Rule:` `majority_50_plus_1` | Trigger: `50.0%` | Statute: `11 O.S. § 16-103 (Candidate receiving majority of votes cast at February primary is elected; if no candidate clears 50%, top two advance to April general)`
  - `District / Ward / At-Large:` Options: `single_member_wards, two_aldermen_per_ward, pure_at_large` | Default: `two_aldermen_per_ward (Aldermanic: 11 O.S. § 9-102) / single-member wards (Manager: 11 O.S. § 10-102)` (Statute: `11 O.S. § 9-102, § 10-102`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in Aldermanic and Strong-Mayor (4-yr term; holds veto in Strong-Mayor: 11 O.S. § 11-108). In Council-Manager, Council selects Mayor from its membership as presiding chair (§ 10-105).
  - `Administration:` `county_election_board_coordinated` | Authority: `11 O.S. § 16-105; 26 O.S. § 13-101 (County Election Board conducts all municipal elections on state voting machines)` | Cost Rule: Reimbursed by municipality to County Election Board under 26 O.S. § 13-111
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `11 O.S. § 8-109`
  - `[FACT]` Governing body appoints successor within 60 days. If governing body fails to act within 60 days, Governor calls special election to fill vacancy!
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `25.0%` of `votes_cast_for_office` | Window: `60 days`
    - `Authority:` `Okla. Const. Art. VIII § 8; Charters`
    - `Mechanics:` Charter cities universally provide recall (typically 20-30% signatures). Absent in statutory general plans.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `25.0%` | Exempt Subjects: `appropriations, tax_levies`
    - `Authority:` `Okla. Const. Art. XVIII § 4(a); 11 O.S. § 15-101 et seq.` | Notes: UNIVERSAL CONSTITUTIONAL RIGHT. 25% of total votes cast at last general municipal election. Council has 30 days to enact or call election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `25.0%`
    - `Authority:` `Okla. Const. Art. XVIII § 4(b); 11 O.S. § 15-103` | Notes: UNIVERSAL CONSTITUTIONAL RIGHT. 25% voter petition filed within 30 days of publication suspends ordinance pending election.
- **Named Exceptions & Hero Charters:**
  - **City of Oklahoma City:** Council-Manager charter; 8 single-member wards + Mayor elected at-large; nonpartisan primary in February, general in April of odd years; charter provides initiative, referendum, and recall.
  - **City of Tulsa:** Strong Mayor-Council charter; 9 single-member council districts; directly elected Mayor with veto; nonpartisan elections held concurrently with August primary and November general of even-numbered years.
- **Epistemic First-Party Sources:** `Okla. Const. Art. XVIII § 3(a), § 4; 11 O.S. (Oklahoma Municipal Code); Oklahoma Municipal League Handbook (2025/2026)`

---

### US-OR — Oregon
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Or. Const. Art. XI § 2 (1906 Municipal Home Rule Amendment); ORS Ch. 221`
  - `[FACT]` Plenary Constitutional Home Rule (Art. XI § 2); legal voters of every city and town have plenary power to enact and amend municipal charters; state legislature prohibited from enacting special municipal laws.
- **Primary Statutory Forms:**
  - `Council-Manager (Dominant Charter Form)` (ORS Ch. 221; Charter): Universal charter adoption across majority of Oregon cities.
  - `Mayor-Council (Charter Form)` (ORS Ch. 221; Charter): Adopted by charter (Beaverton, Portland post-2024 reform).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `ORS § 249.002, § 254.005 ('All municipal elections shall be nonpartisan')`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `ORS § 221.230, § 254.056 (Primary on third Tuesday in May; General Election on first Tuesday after first Monday in November of even-numbered years; all mail-ballot)`)
  - `Runoff / Voting Rule:` `top_two_primary_runoff` | Trigger: `50.0%` | Statute: `ORS § 249.088 (Candidate receiving majority of votes in May primary is elected outright; otherwise, top two candidates advance to November general)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, multi_member_proportional_districts` | Default: `pure_at_large (majority of charters) / multi-member districts (Portland: 3 members per district using Single Transferable Vote)` (Statute: `Governed by individual municipal charters`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election across nearly all charters (2- or 4-yr term). Weak/presiding mayor in Council-Manager cities (Eugene, Salem). Portland 2024 reform created executive Mayor with professional City Administrator.
  - `Administration:` `county_election_board_coordinated` | Authority: `ORS § 254.005 et seq. (County Clerk conducts all municipal elections under Oregon's 100% Vote-by-Mail system)` | Cost Rule: Pro-rata share billed by county to city under ORS § 254.046
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `ORS § 221.160; Local Charters`
  - `[FACT]` Council fills vacancy by appointment for unexpired term, or calls special election if specified by charter.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `15.0%` of `last_gubernatorial_vote` | Window: `90 days`
    - `Authority:` `Or. Const. Art. II § 18; ORS Ch. 249`
    - `Mechanics:` Universal constitutional right. 15% of total votes cast for Governor in that jurisdiction. Official has 5 days to resign; if not, special recall election ordered within 35 days. Yes/No recall question + successor candidates.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `appropriations, administrative_actions`
    - `Authority:` `Or. Const. Art. IV § 1(5); ORS § 250.255 et seq.` | Notes: UNIVERSAL CONSTITUTIONAL RIGHT. 15% of total votes cast for Governor. Council has 30 days to enact without change or submit to voters.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Or. Const. Art. IV § 1(5); ORS § 250.255` | Notes: UNIVERSAL CONSTITUTIONAL RIGHT. 10% voter petition filed within 30 days of ordinance adoption suspends ordinance pending election.
- **Named Exceptions & Hero Charters:**
  - **City of Portland:** Historic 2024 Charter Reform (effective 2024/2025): Abolished historic 1913 Commission form; instituted 12-member Council elected from 4 multi-member geographic districts (3 members per district) using SINGLE TRANSFERABLE VOTE (STV / Proportional RCV); directly elected Mayor using Instant Runoff Voting (IRV) overseeing professional City Administrator; even-year November elections.
  - **City of Eugene:** Council-Manager charter; 8 councilors from 4 wards (2 per ward, staggered) + directly elected Mayor who votes on ties; nonpartisan even-year May/November elections.
- **Epistemic First-Party Sources:** `Or. Const. Art. II § 18, Art. IV § 1(5), Art. XI § 2; ORS Ch. 221 (Cities), Ch. 249 & 254 (Elections); League of Oregon Cities Handbook for Municipal Officials (2025/2026)`

---

### US-PA — Pennsylvania
- **Option Family:** `mid_atlantic_partisan_dillon`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `Pa. Const. Art. IX § 2; Home Rule Charter and Optional Plans Law (53 Pa.C.S. § 2901 et seq.)`
  - `[FACT]` Statutory Home Rule; municipalities adopting home rule charters possess broad police powers, but non-charter municipalities are strictly bound by Dillon's Rule under specific statutory codes.
- **Primary Statutory Forms:**
  - `Third Class City Code (Commission default)` (53 P.S. § 35101 et seq. / 11 Pa.C.S.): Mayor + 4 Councilmembers (Commission form) or Mayor-Council.
  - `Borough Code (Mayor-Council)` (8 Pa.C.S. § 101 et seq.): Dominant municipal form for ~950 boroughs (Mayor + 3-7 Councilmembers).
  - `First Class Township` (53 P.S. § 55101 et seq.): Board of Commissioners (5-15 members).
  - `Second Class Township` (53 P.S. § 65101 et seq.): Board of Supervisors (3 or 5 members).
  - `Home Rule Charter / Optional Plan` (53 Pa.C.S. § 2901 et seq.): Voter referendum adoption.
- **Electoral Framework:**
  - `Ballot Type:` `partisan_mandatory` (Statute: `25 P.S. § 2862 et seq. (MANDATORY PARTISAN ELECTIONS: party primaries in May; general election in November of odd-numbered years)`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `Pa. Const. Art. VII § 3; 25 P.S. § 2754 (Municipal Primary on third Tuesday in May; Municipal Election on first Tuesday after first Monday in November of odd-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `25 P.S. § 3156 (Plurality election; candidate with highest vote total elected; no runoffs)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (Boroughs & 3rd Class cities) / wards (Pittsburgh, Philadelphia)` (Statute: `8 Pa.C.S. § 806, 11 Pa.C.S. § 10901`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (4-yr term). In Boroughs, Mayor is weak (presides over police department, votes on council ties, holds suspensive veto overridden by 2/3 council; 8 Pa.C.S. § 1007). Strong Mayor exists in 1st/2nd Class cities (Philly, Pittsburgh) and Home Rule charters.
  - `Administration:` `county_election_board_coordinated` | Authority: `25 P.S. § 2641 et seq. (County Board of Elections conducts all municipal elections)` | Cost Rule: 100% borne by county treasury (no municipal chargeback for general elections)
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `8 Pa.C.S. § 901 (Boroughs), 11 Pa.C.S. § 10901 (Cities)`
  - `[FACT]` Borough/City council fills vacancy by appointment within 30 days. If council fails to act within 30 days, vacancy board fills within 15 days; if still vacant, Court of Common Pleas appoints successor! Appointee serves until next municipal election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `Pa. Const. Art. VI § 7; Citizens Committee to Recall Rizzo v. Board of Elections, 470 Pa. 1 (1976)`
    - `Mechanics:` MUNICIPAL RECALL IS UNCONSTITUTIONAL IN PENNSYLVANIA. The Supreme Court of Pennsylvania held in Citizens Committee to Recall Rizzo (1976) that Article VI Section 7 of the Pennsylvania Constitution establishes the EXCLUSIVE methods for removing elected officers (impeachment or judicial conviction of misbehavior), and local recall charters violate the constitution.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `53 Pa.C.S. § 2971` | Notes: Citizen initiative for general municipal ordinances is ABSENT under standard statutory codes. Available ONLY if explicitly enacted in a Home Rule Charter adopted pursuant to 53 Pa.C.S. § 2971.
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `53 Pa.C.S. § 2971` | Notes: General protest referendum on municipal ordinances does not exist in standard statutory codes. Home Rule charters may authorize protest referenda.
- **Named Exceptions & Hero Charters:**
  - **City of Philadelphia:** Consolidated First Class City-County (53 P.S. § 13101 et seq.; First Class City Home Rule Act); Strong Mayor-Council charter (1951); 17 councilmembers (10 districts, 7 at-large with mandatory minority party quota: maximum 5 of same party); PARTISAN odd-year elections; recall held unconstitutional in Rizzo (1976).
  - **City of Pittsburgh:** Second Class City; Strong Mayor-Council charter; 9 single-member council districts + Mayor; partisan odd-year elections.
- **Epistemic First-Party Sources:** `Pa. Const. Art. VI § 7, Art. VII § 3, Art. IX § 2; 53 Pa.C.S. (Municipalities), Title 8 Pa.C.S. (Boroughs), Title 11 Pa.C.S. (Cities); 25 P.S. (Election Code); Citizens Committee to Recall Rizzo v. Board of Elections, 470 Pa. 1 (1976); Pennsylvania State Association of Boroughs Handbook (2025/2026)`

---

### US-RI — Rhode Island
- **Option Family:** `new_england_town_meeting`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `R.I. Const. Art. XIII (Home Rule); R.I. Gen. Laws Title 45`
  - `[FACT]` Constitutional Home Rule (Art. XIII); electors of each city and town have the right to adopt and amend home-rule charters relating to local administration.
- **Primary Statutory Forms:**
  - `Town Council / Financial Town Meeting` (R.I.G.L. § 45-3-1 et seq., § 45-4-1 et seq.): Traditional Rhode Island town governance.
  - `Council-Manager` (R.I.G.L. Title 45; Home Rule Charter): Adopted by charter in several towns (e.g. South Kingstown, Coventry).
  - `Mayor-Council (Strong Mayor)` (R.I.G.L. Title 45; Home Rule Charter): Cities (Providence, Warwick, Cranston, Pawtucket).
- **Electoral Framework:**
  - `Ballot Type:` `charter_determined` (Statute: `R.I.G.L. Title 17 (Partisan in cities like Providence and Cranston; nonpartisan in towns like Newport and South Kingstown per charter)`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `R.I.G.L. § 17-1-2, § 17-18-1 (Primary in September; General Election on first Tuesday after first Monday in November of even-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `R.I.G.L. § 17-19-36 (Plurality election; candidate with highest vote total elected; no runoffs)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (Town Councils 5 or 7 members: R.I.G.L. § 45-4-1) / wards in cities` (Statute: `R.I.G.L. § 45-4-1; Local Charters`)
  - `Mayor Selection:` `direct_popular_election, council_selected_council_president` | Strong vs. Weak: Direct election in Mayor-Council charters (Providence, Warwick: strong executive administration, veto power). In towns, Town Council selects Council President as presiding officer.
  - `Administration:` `county_election_board_coordinated` | Authority: `R.I.G.L. § 17-7-1 et seq. (Local Board of Canvassers in each city/town administers elections under supervision of State Board of Elections)` | Cost Rule: State Board provides voting equipment; local canvassing board costs borne by municipality
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `R.I.G.L. § 45-4-16; Local Charters`
  - `[FACT]` Governed by municipal charter. Typically council appoints successor or calls special town election if vacancy occurs early in 2-year term.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `False` | Threshold: `20.0%` of `registered_voters` | Window: `60 days`
    - `Authority:` `Charters pursuant to R.I. Const. Art. XIII`
    - `Mechanics:` Authorized ONLY where explicitly enacted in a municipal Home Rule Charter (e.g. Cranston, Warwick). Absent under general state law.
  - `Municipal Initiative:` Authorized: `True` | Type: `town_meeting_warrant` | Threshold: `10.0%` | Exempt Subjects: `administrative_matters`
    - `Authority:` `Financial Town Meeting; Charters` | Notes: Direct democracy exercised via Financial Town Meeting (FTM) where voters directly approve municipal budget and tax levies. In cities, initiative exists only where granted by charter.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Charters; R.I. Const. Art. XIII` | Notes: Governed by municipal charters; protest petitions suspend ordinances where charter provides.
- **Named Exceptions & Hero Charters:**
  - **City of Providence:** Home Rule Charter; Mayor-Council form; 15 single-member council wards + directly elected Mayor; PARTISAN elections; primary in September, general in November of midterm even years (2022, 2026); Mayor holds veto overridden by 2/3 council.
  - **City of Newport:** Council-Manager charter; 7 councilmembers (4 wards, 3 at-large); NONPARTISAN even-year elections; Council elects Mayor from at-large members.
- **Epistemic First-Party Sources:** `R.I. Const. Art. XIII; R.I. Gen. Laws Title 17 (Elections), Title 45 (Towns and Cities); Rhode Island League of Cities and Towns Governance Manual (2025/2026)`

---

### US-SC — South Carolina
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `S.C. Const. Art. VIII; Home Rule Act of 1975 (S.C. Code Ann. Title 5)`
  - `[FACT]` Statutory Home Rule (Act 283 of 1975); municipalities must adopt one of three standardized statutory forms; broad police powers subject to general state preemption.
- **Primary Statutory Forms:**
  - `Mayor-Council (Strong Mayor)` (S.C. Code Ann. § 5-9-10 et seq.): Mayor is chief executive with veto; Council of 4, 6, or 8 members.
  - `Council (Weak Mayor / Council Government)` (S.C. Code Ann. § 5-11-10 et seq.): Council of 5, 7, or 9 members; Mayor is presiding member with no veto.
  - `Council-Manager` (S.C. Code Ann. § 5-13-10 et seq.): Council appoints professional Municipal Manager.
- **Electoral Framework:**
  - `Ballot Type:` `charter_determined` (Statute: `S.C. Code Ann. § 5-15-60 (Municipality must determine by ordinance: (1) Nonpartisan plurality, (2) Nonpartisan runoff, or (3) Partisan primary and general election)`)
  - `Election Timing:` `odd_year_november_consolidated, spring_annual` (Statute: `S.C. Code Ann. § 5-15-50 (Municipality fixes election dates by ordinance; commonly first Tuesday after first Monday in November of odd-numbered years, or spring dates)`)
  - `Runoff / Voting Rule:` `locally_selectable` | Trigger: `50.0%` | Statute: `S.C. Code Ann. § 5-15-61, § 5-15-62 (If nonpartisan runoff option adopted, candidate must receive majority of votes; otherwise top two advance to runoff held 2 weeks later)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, hybrid_wards_and_at_large` | Default: `pure_at_large (small towns) / single_member_districts (Columbia, Charleston)` (Statute: `S.C. Code Ann. § 5-15-20`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (2- or 4-yr term). Strong Mayor under § 5-9-30 (Charleston, Columbia: full administrative appointment, veto overridden by 2/3 council). In Council and Manager forms, Mayor has no veto.
  - `Administration:` `county_election_board_coordinated` | Authority: `S.C. Code Ann. § 5-15-145 (Municipalities may transfer election administration to County Board of Voter Registration and Elections)` | Cost Rule: Municipality reimburses County Board for actual election expenses
- **Vacancy Succession Procedure:**
  - `Rule Type:` `special_election_mandatory` | Special Election Cutoff: `6 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `S.C. Code Ann. § 5-7-200`
  - `[FACT]` Governing body MUST call a special election to fill vacancy for remainder of unexpired term. However, if vacancy occurs within 180 days of regular election, council may leave seat vacant.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `S.C. Code Ann. Title 5; Op. S.C. Att'y Gen. (July 19, 2007)`
    - `Mechanics:` MUNICIPAL RECALL IS PROHIBITED in South Carolina. State statutes provide no recall authority for municipal officers. Removal is available only via Governor under S.C. Const. Art. VI § 8 for indictment of crimes involving moral turpitude.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `appropriation_of_money, tax_levies, salaries_of_city_employees, zoning`
    - `Authority:` `S.C. Code Ann. § 5-17-10 et seq.` | Notes: UNIVERSAL STATUTORY RIGHT. Petition signed by 15% of registered electors. Council must pass ordinance without amendment within 60 days or submit to election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `60 days` | Suspends Ordinance: `True` | Threshold: `15.0%`
    - `Authority:` `S.C. Code Ann. § 5-17-30` | Notes: UNIVERSAL STATUTORY RIGHT. 15% registered elector petition filed within 60 days suspends ordinance until council repeals or election held.
- **Named Exceptions & Hero Charters:**
  - **City of Charleston:** Mayor-Council form (Strong Mayor); 12 single-member council districts; directly elected Mayor with veto; nonpartisan November odd-year elections with 50%+1 runoff.
  - **City of Columbia:** Council-Manager form (transitioned to Mayor-Council hybrid); 6 councilmembers (4 districts, 2 at-large) + Mayor; nonpartisan November odd-year elections with runoff.
  - **City of Greenville:** Council-Manager form; 6 councilmembers (4 districts, 2 at-large) + Mayor; PARTISAN elections (primary in June, general in November of odd-numbered years).
- **Epistemic First-Party Sources:** `S.C. Const. Art. VIII; S.C. Code Ann. Title 5 (Municipal Corporations); Municipal Association of South Carolina (MASC) Handbook (2025/2026)`

---

### US-SD — South Dakota
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `S.D. Const. Art. IX § 2; SDCL Ch. 9-14A (Home Rule)`
  - `[FACT]` Constitutional Home Rule; municipalities adopting home rule charter may exercise any power not prohibited by constitution or statute.
- **Primary Statutory Forms:**
  - `Aldermanic Form (Mayor-Council)` (SDCL Ch. 9-8): Default statutory form (Mayor + 2 Aldermen per ward).
  - `Commissioner Form` (SDCL Ch. 9-9): Mayor + 2 or 4 Commissioners elected at-large.
  - `City Manager` (SDCL Ch. 9-10): Voter petition and referendum adoption.
  - `Home Rule Charter` (SDCL Ch. 9-14A): Charter commission drafted and voter adopted.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `SDCL § 9-13-6 ('All municipal elections shall be nonpartisan')`)
  - `Election Timing:` `annual_spring_april, even_year_june_consolidated` (Statute: `SDCL § 9-13-1 (Second Tuesday in April annually; municipalities may choose to hold election on first Tuesday after first Monday in June consolidated with statewide primary)`)
  - `Runoff / Voting Rule:` `majority_50_plus_1` | Trigger: `50.0%` | Statute: `SDCL § 9-13-26, § 9-13-27 (Secondary election required if no candidate receives majority, unless municipality adopts plurality ordinance under § 9-13-27.1)`
  - `District / Ward / At-Large:` Options: `two_aldermen_per_ward, pure_at_large, hybrid_wards_and_at_large` | Default: `two_aldermen_per_ward (Aldermanic: SDCL § 9-8-1; staggered terms)` (Statute: `SDCL § 9-8-1, § 9-9-1`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (2- or 4-yr term). Mayor presides, votes on ties, holds veto overridden by 2/3 council in Aldermanic form (SDCL § 9-8-3).
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `SDCL Ch. 9-13 (Finance Officer conducts standalone municipal elections; County Auditor conducts if consolidated with June primary)` | Cost Rule: 100% municipal in April; shared in June
- **Vacancy Succession Procedure:**
  - `Rule Type:` `mayoral_appointment_council_consent` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `SDCL § 9-13-14.1, § 9-13-14.2`
  - `[FACT]` Mayor appoints successor with approval of governing body until next annual municipal election, or governing body may call special election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `simultaneous_incumbent_replacement` | Grounds Required: `False` | Threshold: `15.0%` of `registered_voters` | Window: `60 days`
    - `Authority:` `SDCL § 9-13-29 et seq.`
    - `Mechanics:` Universal statutory recall. Petition signed by 15% of registered voters. Incumbent is automatically a candidate on the recall ballot unless declining; challengers run alongside; plurality winner takes office.
  - `Municipal Initiative:` Authorized: `True` | Type: `direct_to_ballot` | Threshold: `5.0%` | Exempt Subjects: `appropriations, administrative_matters`
    - `Authority:` `S.D. Const. Art. III § 1; SDCL Ch. 9-20` | Notes: FIRST STATE IN THE NATION to adopt initiative (1898). Petition signed by 5% of registered voters. Submitted to voters at next annual municipal election or special election.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `20 days` | Suspends Ordinance: `True` | Threshold: `5.0%`
    - `Authority:` `S.D. Const. Art. III § 1; SDCL § 9-20-6` | Notes: Petition signed by 5% of registered voters filed within 20 days after ordinance publication suspends ordinance pending election.
- **Named Exceptions & Hero Charters:**
  - **City of Sioux Falls:** Home Rule Charter; Mayor-Council form; 8 councilmembers (5 districts, 3 at-large) + directly elected Mayor with veto; nonpartisan April elections in even-numbered years.
  - **City of Rapid City:** Aldermanic statutory form; 10 aldermen (5 wards, 2 per ward) + Mayor; June consolidated elections.
- **Epistemic First-Party Sources:** `S.D. Const. Art. III § 1, Art. IX § 2; SDCL Title 9 (Municipalities); South Dakota Municipal League Handbook (2025/2026)`

---

### US-TN — Tennessee
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `Tenn. Const. Art. XI § 9 (Home Rule Amendment of 1953); T.C.A. Title 6`
  - `[FACT]` Tennessee municipalities operate under four distinct authorities: (1) Mayor-Aldermanic Charter (T.C.A. 6-1), (2) City Manager-Commission Charter (T.C.A. 6-18), (3) Modified City Manager-Council Charter (T.C.A. 6-30), or (4) Private Act legislative charters (~70% of cities).
- **Primary Statutory Forms:**
  - `Mayor-Aldermanic Charter` (T.C.A. § 6-1-101 et seq.): General law statutory option.
  - `City Manager-Commission Charter` (T.C.A. § 6-18-101 et seq.): General law statutory option.
  - `Modified Manager-Council Charter` (T.C.A. § 6-30-101 et seq.): General law statutory option.
  - `Private Act Legislative Charter` (Enacted by General Assembly): Special acts tailored for individual municipalities.
  - `Metropolitan Government (Consolidated)` (T.C.A. Title 7): City-county consolidation (Nashville-Davidson).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_default_partisan_optional` (Statute: `T.C.A. § 2-13-208 (Nonpartisan default; private act charters may authorize partisan elections)`)
  - `Election Timing:` `even_year_august_consolidated, even_year_november_consolidated, odd_year_autumn` (Statute: `T.C.A. § 6-53-101; County Election Commission (Municipal elections commonly held in August or November of even-numbered years, or standalone May/September per charter)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `T.C.A. § 2-8-110 (Plurality election; candidate with highest vote total elected; Metropolitan Nashville requires 50%+1 with runoff under Charter § 15.01)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (Commission charters) / wards (Mayor-Aldermanic: T.C.A. § 6-1-201)` (Statute: `T.C.A. § 6-1-201, § 6-18-105`)
  - `Mayor Selection:` `direct_popular_election, commission_selected_from_membership` | Strong vs. Weak: Direct election in Mayor-Aldermanic (T.C.A. § 6-3-101; administrative head, veto power overridden by 2/3 board). In Manager-Commission, Commission elects mayor from membership as ceremonial head (§ 6-20-201).
  - `Administration:` `county_election_board_coordinated` | Authority: `T.C.A. § 2-12-116 (County Election Commission conducts all municipal elections on county voting machines)` | Cost Rule: Municipality reimburses County Election Commission for actual expenses under T.C.A. § 2-12-109
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `T.C.A. § 6-3-107, § 6-20-205`
  - `[FACT]` Board of Aldermen/Commissioners appoints successor for remainder of unexpired term, or until next regular city election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `True` | Threshold: `33.3%` of `registered_voters` | Window: `30 days`
    - `Authority:` `T.C.A. § 6-20-220 (Manager-Commission); Metro Charters`
    - `Mechanics:` Authorized in City Manager-Commission charters (§ 6-20-220; requires 33.3% registered voters) and Metro charters (Nashville: 15% registered voters). ABSENT in general Mayor-Aldermanic charters.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `25.0%` | Exempt Subjects: `appropriations, tax_levies`
    - `Authority:` `T.C.A. § 6-20-215; Metro Charters` | Notes: Authorized in Manager-Commission charters (25% voter petition). Council must pass within 60 days or submit to election. Absent in Mayor-Aldermanic cities.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `25.0%`
    - `Authority:` `T.C.A. § 6-20-218` | Notes: Authorized in Manager-Commission charters (25% voter petition within 30 days suspends ordinance). Absent in Mayor-Aldermanic charters.
- **Named Exceptions & Hero Charters:**
  - **Metropolitan Government of Nashville and Davidson County:** Consolidated City-County (T.C.A. Title 7; Charter 1962); 40-member Metropolitan Council (35 single-member districts, 5 at-large); directly elected Mayor + Vice Mayor presiding; nonpartisan August odd-year elections with September 50%+1 runoff.
  - **City of Memphis:** Private Act Charter; Mayor-Council form; 13 councilmembers (7 single-member districts, 6 from two 3-member super-districts); directly elected Strong Mayor with veto; nonpartisan October odd-year elections.
  - **City of Knoxville:** Mayor-Council charter; 9 councilmembers (6 district, 3 at-large); nonpartisan primary in August, general in November of odd-numbered years.
- **Epistemic First-Party Sources:** `Tenn. Const. Art. XI § 9; T.C.A. Title 2 (Elections), Title 6 (Cities), Title 7 (Metropolitan Governments); University of Tennessee Municipal Technical Advisory Service (MTAS) Handbook (2025/2026)`

---

### US-TX — Texas
- **Option Family:** `southern_runoff_general_law`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Tex. Const. Art. XI § 5 (Home Rule Amendment); Tex. Loc. Gov't Code (TLGC) Title 2`
  - `[FACT]` Constitutional Home Rule for cities > 5,000 pop (TLGC Ch. 9); cities possess inherent powers not denied by constitution or general statute. Cities <= 5,000 pop governed strictly by General Law (Type A, Type B, or Type C).
- **Primary Statutory Forms:**
  - `General Law Type A (Mayor-Aldermen)` (TLGC Ch. 22): Default general law form for cities 600 to 4,999 pop (Mayor + 5 Aldermen).
  - `General Law Type B` (TLGC Ch. 23): Small municipalities 201 to 10,000 pop (Mayor + 5 Aldermen).
  - `General Law Type C (Commission)` (TLGC Ch. 24): Mayor + 2 Commissioners (cities 201 to 4,999 pop).
  - `City Manager (General Law)` (TLGC Ch. 25): Voter petition and election adoption.
  - `Home Rule Charter` (Tex. Const. Art. XI § 5; TLGC Ch. 9): Charter commission drafted and voter adopted (cities > 5,000 pop).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Tex. Elec. Code § 143.002 et seq. ('Independent Candidates for Municipal Office; party labels prohibited on municipal ballots')`)
  - `Election Timing:` `annual_spring_may, even_year_november_consolidated` (Statute: `Tex. Elec. Code § 41.001 (Uniform Election Date on first Saturday in May annually; Home Rule charters may opt for first Tuesday after first Monday in November)`)
  - `Runoff / Voting Rule:` `majority_50_plus_1` | Trigger: `50.0%` | Statute: `TLGC § 22.010; Tex. Elec. Code § 2.021 (MANDATORY MAJORITY RULE in Type A cities: candidate must receive 50%+1 of votes cast; otherwise top-two runoff held; council may adopt plurality ordinance under § 2.022)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, numbered_at_large_places` | Default: `pure_at_large (Type A: TLGC § 22.031) / single-member districts (Home Rule cities)` (Statute: `TLGC § 22.031, § 26.041`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (2-yr default; 3- or 4-yr terms trigger constitutional resign-to-run). In Type A, Mayor presides, votes only on ties, holds veto overridden by 2/3 aldermen (TLGC § 22.042, § 22.032). Strong Mayor in Houston; Council-Manager dominant in Dallas, Austin, San Antonio, Fort Worth, El Paso.
  - `Administration:` `hybrid_clerk_and_county` | Authority: `Tex. Elec. Code § 31.092 (City Secretary conducts May standalone elections, or contracts with County Elections Administrator for joint election under Ch. 271)` | Cost Rule: 100% municipal in May; shared cost under joint election contract
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `TLGC § 22.010, § 22.041; Tex. Const. Art. XI § 11`
  - `[FACT]` In Type A cities with 2-year terms, remaining aldermen appoint successor for unexpired term. RESIGN-TO-RUN MANDATE: Under Tex. Const. Art. XI § 11, if city adopts terms > 2 years, any elected official who announces candidacy for another office with > 1 year remaining automatically VACATES their municipal seat; all vacancies in >2-year term cities MUST be filled by special election within 120 days!
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `20.0%` of `registered_voters` | Window: `45 days`
    - `Authority:` `Tex. Const. Art. XI § 5; Local Home Rule Charters`
    - `Mechanics:` General Law cities (Type A, B, C) lack statutory authority for recall. UNIVERSALLY ADOPTED in Texas Home Rule Charters (typically 10-25% registered voter signatures). Two-question ballot or replacement ballot per charter.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `budget_appropriations, tax_rates, zoning_annexation`
    - `Authority:` `Home Rule Charters (TLGC Ch. 9)` | Notes: Absent in General Law cities. Universally provided in Home Rule Charters. Council must pass without amendment or submit to voters.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `Home Rule Charters (TLGC Ch. 9)` | Notes: Home Rule charters grant protest referendum suspending ordinances pending vote.
- **Named Exceptions & Hero Charters:**
  - **City of Houston:** Only major Texas city with Strong Mayor-Council form; 16 councilmembers (11 districts, 5 at-large); Mayor is chief executive administrator with veto; nonpartisan November odd-year elections with December 50%+1 runoff; 2-year terms.
  - **City of Dallas:** Council-Manager charter; 14 single-member council districts + Mayor elected at-large; nonpartisan May elections in odd years with runoff.
  - **City of Austin:** Council-Manager charter; 10 single-member districts + Mayor elected at-large; nonpartisan November elections consolidated with even-year general election (voter-approved 2022 Proposition Q).
- **Epistemic First-Party Sources:** `Tex. Const. Art. XI §§ 5, 11; Texas Local Government Code Titles 2 & 3; Texas Election Code; Texas Municipal League Handbook for Mayors and Councilmembers (2025/2026)`

---

### US-UT — Utah
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Utah Const. Art. XI § 5; Utah Code Ann. (UCA) Title 10`
  - `[FACT]` Constitutional Home Rule (Art. XI § 5); municipalities have authority to frame charters. Non-charter cities governed by Utah Municipal Code Title 10.
- **Primary Statutory Forms:**
  - `Five-Member Council (Weak Mayor)` (UCA § 10-3b-301 et seq.): Default statutory form for ~80% of Utah cities (Mayor + 5 councilmembers).
  - `Six-Member Council (Weak Mayor)` (UCA § 10-3b-301 et seq.): Mayor + 6 councilmembers.
  - `Mayor-Council (Strong Mayor)` (UCA § 10-3b-201 et seq.): Optional form (Salt Lake City, Provo, Ogden).
  - `Council-Manager` (UCA § 10-3b-401 et seq.): Council appoints manager.
  - `Metro Township` (UCA § 10-2a-401 et seq.): 5-member council for unincorporated townships.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `UCA § 20A-9-404 ('Municipal elections shall be nonpartisan')`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `UCA § 20A-1-201.5, § 20A-1-202 (Municipal Primary on second Tuesday in August; Municipal General Election on first Tuesday after first Monday in November of odd-numbered years; 100% Vote-by-Mail)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `UCA § 20A-1-304 (Plurality election; Municipal Alternative Voting Methods Pilot Project authorizes municipalities to adopt Ranked-Choice Voting / Instant Runoff Voting under UCA § 20A-4-601 et seq.)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts` | Default: `pure_at_large (5-member council statutory default: UCA § 10-3b-301; staggered 4-year terms) / districts in Salt Lake City` (Statute: `UCA § 10-3-205.5`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (4-yr term). Weak Mayor in 5/6-member council: mayor presides, votes ONLY in case of a tie, and has NO veto power (UCA § 10-3b-304). Strong Mayor under § 10-3b-202: executive head with veto overridden by 2/3 council.
  - `Administration:` `county_election_board_coordinated` | Authority: `UCA § 20A-5-400.1 (Municipalities contract with County Clerk to administer mail-ballot elections)` | Cost Rule: Reimbursed by municipality to county under interlocal agreement
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `UCA § 20A-1-510`
  - `[FACT]` City council must give public notice, accept applications, hold an open interview meeting, and appoint a qualified registered voter within 30 calendar days. If council deadlocks after 12 ballots, mayor selects appointee.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `Utah Code Title 10 & 20A; Op. Utah Att'y Gen. (1987)`
    - `Mechanics:` MUNICIPAL RECALL IS PROHIBITED in Utah. The Utah Constitution and statutes provide no recall mechanism for local elected officials. Removal is available only for cause via judicial trial under UCA § 77-6-1.
  - `Municipal Initiative:` Authorized: `True` | Type: `direct_to_ballot` | Threshold: `11.5%` | Exempt Subjects: `budget_appropriations, tax_levies, administrative_actions`
    - `Authority:` `Utah Const. Art. VI § 1(2); UCA Title 20A Ch. 7 Pt. 5 (§ 20A-7-501 et seq.)` | Notes: UNIVERSAL STATUTORY RIGHT. Tiered signature thresholds: 8% (cities > 100k), 11.5% (cities 10k-100k), 16% (cities < 10k) of total votes cast for Governor in that city. Placed directly on municipal general election ballot.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `45 days` | Suspends Ordinance: `False` | Threshold: `11.5%`
    - `Authority:` `Utah Const. Art. VI § 1(2); UCA Title 20A Ch. 7 Pt. 6 (§ 20A-7-601 et seq.)` | Notes: Petition filed within 45 days. Does NOT automatically suspend ordinance unless court injunction issued. Voted on at next general election.
- **Named Exceptions & Hero Charters:**
  - **Salt Lake City:** Mayor-Council statutory form (Strong Mayor); 7 single-member council districts + directly elected Mayor with veto; nonpartisan odd-year mail-ballot elections; participates in Ranked-Choice Voting pilot project.
  - **City of Provo:** Mayor-Council form; 7 councilmembers (5 districts, 2 at-large) + Mayor; odd-year elections.
  - **City of Ogden:** Mayor-Council form; 7 councilmembers (4 districts, 3 at-large) + Mayor with full executive administration.
- **Epistemic First-Party Sources:** `Utah Const. Art. VI § 1, Art. XI § 5; Utah Code Ann. Title 10 (Cities), Title 20A (Election Code); Utah League of Cities and Towns Handbook (2025/2026)`

---

### US-VT — Vermont
- **Option Family:** `new_england_town_meeting`
- **Home Rule Foundation:** `dillons_rule_strict` | Authority: `Vt. Const. Ch. II § 69; 24 V.S.A. (Municipal and County Government)`
  - `[FACT]` Strict Dillon's Rule; all towns and cities are creations of the state legislature; municipal charters and charter amendments MUST be approved and enacted by the General Assembly.
- **Primary Statutory Forms:**
  - `Town Meeting / Selectboard` (24 V.S.A. § 871 et seq.): Default traditional governance for ~237 Vermont towns.
  - `Town Manager Form` (24 V.S.A. Ch. 37 (§ 1231 et seq.)): Town meeting voter adoption (Selectboard appoints Manager).
  - `City Charter (Mayor-Council)` (Special Acts of General Assembly): 9 incorporated cities (Burlington, Rutland, Montpelier, etc.).
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `17 V.S.A. § 2640 et seq. (Town elections nonpartisan; Australian ballot or floor voting)`)
  - `Election Timing:` `town_meeting_day_march` (Statute: `17 V.S.A. § 2640 (TOWN MEETING DAY: First Tuesday in March annually across the entire state)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `17 V.S.A. § 2660 (Plurality election; candidate receiving highest number of votes elected; City of Burlington uses Ranked-Choice Voting under Charter Sec. 5)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (Selectboard 3 or 5 members: 24 V.S.A. § 871; staggered 3-year terms)` (Statute: `24 V.S.A. § 871`)
  - `Mayor Selection:` `direct_popular_election, board_selected_select_board_chair` | Strong vs. Weak: In towns, Selectboard chooses its own Chair annually (24 V.S.A. § 872). In cities, Mayor directly elected (Burlington: strong mayor with veto overridden by 2/3 council).
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `17 V.S.A. § 2640 et seq. (Town Clerk and Board of Civil Authority conduct all Town Meeting elections)` | Cost Rule: 100% town responsibility
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `True`
  - `Statutes:` `24 V.S.A. § 961, § 963`
  - `[FACT]` Remaining Selectboard members appoint a replacement until the next annual Town Meeting. However, under 24 V.S.A. § 963, a petition signed by 5% of voters can force a special town meeting election to fill the vacancy.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `24 V.S.A. (Absent in general law; exists only in specific legislative charters)`
    - `Mechanics:` Recall does NOT exist under general Vermont law. Available ONLY if enacted into a municipal charter by special act of the General Assembly.
  - `Municipal Initiative:` Authorized: `True` | Type: `town_meeting_warrant` | Threshold: `5.0%` | Exempt Subjects: `tax_rates_must_follow_statutory_procedures`
    - `Authority:` `17 V.S.A. § 2642(a) (Town Meeting Warning Petitions)` | Notes: Petition signed by 5% of registered voters MANDATES Selectboard to insert proposed article into the warning for the annual Town Meeting.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `5.0%`
    - `Authority:` `17 V.S.A. § 2661 (Reconsideration or Rescission)` | Notes: Petition signed by 5% of registered voters filed within 30 days of town meeting vote forces a vote on RECONSIDERATION or RESCISSION of the measure.
- **Named Exceptions & Hero Charters:**
  - **City of Burlington:** Legislative Charter (24 V.S.A. Title 24 App. Ch. 3); Mayor-Council form; 12 city councilors (8 wards, 4 districts) + directly elected Mayor with veto; uses Ranked-Choice Voting (RCV) for Mayor and Council (restored by charter amendment 2023/2024); Town Meeting Day in March.
  - **City of Montpelier:** Council-Manager legislative charter; 6 councilors (3 two-member districts) + Mayor; non-citizens authorized to vote in local municipal elections by charter amendment.
- **Epistemic First-Party Sources:** `Vt. Const. Ch. II § 69; 17 V.S.A. Ch. 55 (Local Elections); 24 V.S.A. (Towns and Cities); Vermont League of Cities and Towns Handbook (2025/2026)`

---

### US-VA — Virginia
- **Option Family:** `mid_atlantic_partisan_dillon`
- **Home Rule Foundation:** `dillons_rule_strict` | Authority: `Va. Const. Art. VII; Va. Code Title 15.2 (Counties, Cities and Towns)`
  - `[FACT]` Strict Dillon's Rule state; all 38 cities in Virginia are INDEPENDENT CITIES by constitutional mandate, not part of any county; charters granted and amended exclusively by General Assembly.
- **Primary Statutory Forms:**
  - `Council-Manager (Dominant City Form)` (Va. Code § 15.2-1500 et seq.; Charters): Standard form in majority of Virginia's 38 independent cities.
  - `Mayor-Council (Strong Mayor)` (Special Legislative Charters): Richmond (City Charter Ch. 5).
  - `Town Government (Mayor-Council)` (Va. Code § 15.2-1400 et seq.): 190 incorporated towns nested within counties.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Va. Code § 24.2-500 et seq. (Candidates run as independents or party-endorsed; no formal partisan municipal primary under general law)`)
  - `Election Timing:` `even_year_november_consolidated, odd_year_november_consolidated` (Statute: `Va. Code § 24.2-222.1 (HISTORIC 2021 STATUTE: Abolished historical May municipal elections; mandated all city and town council elections moved to first Tuesday after first Monday in November)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `Va. Code § 24.2-673 (Plurality election; candidate receiving highest number of votes elected; City of Richmond requires winning a plurality in 5 of 9 council districts under Charter § 5.01)`
  - `District / Ward / At-Large:` Options: `single_member_districts, pure_at_large, hybrid_wards_and_at_large` | Default: `pure_at_large (towns and smaller cities) / single_member_districts (Richmond, Norfolk, Portsmouth)` (Statute: `Governed by individual legislative city charters`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in Richmond (Strong Mayor with full administrative control and veto; Charter Ch. 5). In Council-Manager cities (Alexandria, Norfolk, Roanoke), Mayor is chosen by council or directly elected as ceremonial chair with NO veto power.
  - `Administration:` `county_election_board_coordinated` | Authority: `Va. Code § 24.2-109 et seq. (City or County Electoral Board and General Registrar conduct all elections on state-certified voting systems)` | Cost Rule: Independent cities bear 100% of their city electoral board costs
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `6 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Va. Code § 24.2-226, § 24.2-228`
  - `[FACT]` Governing body appoints successor within 45 days. If council deadlocks or fails to act, judges of the Circuit Court make appointment! If vacancy occurs > 120 days before regular election and > 1 year on term, special election ordered.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `judicial_cause_removal_trial` | Grounds Required: `True` | Threshold: `10.0%` of `votes_cast_for_office` | Window: `None days`
    - `Authority:` `Va. Code § 24.2-233 et seq. (Judicial Removal Trial)`
    - `Mechanics:` POLITICAL RECALL DOES NOT EXIST IN VIRGINIA. Citizen petition signed by 10% of qualified voters who voted at last election acts ONLY as an application to the Circuit Court to initiate a judicial trial for removal for cause before a circuit judge.
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `Va. Code Title 15.2` | Notes: Citizen initiative for general municipal ordinances is PROHIBITED under Virginia law.
  - `Municipal Referendum:` Authorized: `False` | Protest Referendum Available: `False` | Window: `None days` | Suspends Ordinance: `False` | Threshold: `None%`
    - `Authority:` `Va. Code Title 15.2` | Notes: No general protest referendum on municipal ordinances. Advisory referenda permitted only upon circuit court order under Va. Code § 24.2-684.
- **Named Exceptions & Hero Charters:**
  - **City of Richmond:** Independent City; Strong Mayor-Council charter; 9 single-member districts; Mayor directly elected under unique '5 of 9 district rule' (candidate must win plurality in at least 5 council districts; otherwise top two advance to runoff); November even-year elections.
  - **City of Virginia Beach:** Independent City; 10 councilmembers (transitioned to 10 single-member geographic voting districts following 2022 Voting Rights Act federal court orders) + directly elected Mayor at-large; November even-year elections.
- **Epistemic First-Party Sources:** `Va. Const. Art. VII; Va. Code Title 15.2 (Local Government), Title 24.2 (Elections); Virginia Municipal League Handbook for Municipal Officials (2025/2026)`

---

### US-WA — Washington
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Wash. Const. Art. XI § 10; RCW Title 35 (Cities) & Title 35A (Optional Municipal Code)`
  - `[FACT]` Constitutional Home Rule for cities > 10,000 pop (Art. XI § 10). Plenary powers for Code Cities under Optional Municipal Code (RCW 35A.11.020).
- **Primary Statutory Forms:**
  - `Code City (Mayor-Council)` (RCW 35A.12.010 et seq.): Dominant municipal form across Washington (~60% of cities).
  - `Code City (Council-Manager)` (RCW 35A.13.010 et seq.): Optional statutory form (~35% of cities).
  - `First Class Charter City` (Wash. Const. Art. XI § 10; RCW 35.22): Cities > 10,000 pop (Seattle, Spokane, Tacoma, Vancouver).
  - `Second Class City / Town` (RCW 35.23, RCW 35.27): Statutory general law classifications.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `RCW § 29A.52.210 ('All city, town, and school district offices shall be nonpartisan')`)
  - `Election Timing:` `odd_year_november_consolidated` (Statute: `RCW § 29A.04.321, § 29A.04.330 (Top-two Primary on first Tuesday in August; General Election on first Tuesday after first Monday in November of odd-numbered years; 100% Vote-by-Mail)`)
  - `Runoff / Voting Rule:` `top_two_primary_runoff` | Trigger: `50.0%` | Statute: `RCW § 29A.52.210, § 29A.52.220 (Top-two primary in August eliminates all but top two candidates who advance to November general election; plurality wins in November)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_districts, hybrid_wards_and_at_large` | Default: `pure_at_large (Code cities: RCW 35A.12.010; 5 or 7 councilmembers with staggered 4-year terms) / districts (Seattle: 7 districts, 2 at-large)` (Statute: `RCW 35A.12.010; Washington Voting Rights Act (RCW Ch. 29A.92)`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in Mayor-Council (4-yr term; chief executive administrator with veto overridden by majority plus one of council: RCW 35A.12.100, 35A.12.130). In Council-Manager, Council selects Mayor from own members as ceremonial chair (RCW 35A.13.030).
  - `Administration:` `county_election_board_coordinated` | Authority: `RCW § 29A.04.216 (County Auditor conducts all municipal elections under Washington's universal Vote-by-Mail system)` | Cost Rule: Proportional share of election costs billed by county to municipality under RCW § 29A.04.410
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `RCW § 42.12.070, RCW 35A.12.050`
  - `[FACT]` Council fills vacancy by majority vote within 90 days. If council deadlocks or fails to act within 90 days, County Commissioners appoint successor! Appointee serves until next regular election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `True` | Threshold: `25.0%` of `votes_cast_for_office` | Window: `180 days`
    - `Authority:` `Wash. Const. Art. I §§ 33, 34; RCW Title 29A Ch. 56 (§ 29A.56.110 et seq.)`
    - `Mechanics:` MANDATORY JUDICIAL SUFFICIENCY HEARING: Petition cannot be circulated until a Superior Court judge conducts a formal hearing to determine whether charges are factually and legally sufficient! 25% (cities 1st/2nd class) or 35% (other cities) of votes cast for that office. Standalone Yes/No vote; vacancy filled by appointment.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `appropriations, tax_levies, administrative_matters`
    - `Authority:` `RCW § 35A.11.080 et seq. (Code Cities); Charters` | Notes: Authorized in Code Cities and First Class Charters (15% registered voters for regular election; 20% for special election). Council must pass within 30 days or submit to voters.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `10.0%`
    - `Authority:` `RCW § 35A.11.080` | Notes: 10% registered voter petition filed within 30 days of ordinance passage suspends ordinance pending election.
- **Named Exceptions & Hero Charters:**
  - **City of Seattle:** First Class Charter City (Wash. Const. Art. XI § 10); Strong Mayor-Council form; 9 councilmembers (7 districts, 2 at-large); directly elected Mayor with veto (overridden by 2/3 council); odd-year mail-ballot primary/general elections; local term limits held UNCONSTITUTIONAL by WA Supreme Court in Koppang v. Hein, 880 P.2d 529 (1994).
  - **City of Spokane:** Mayor-Council charter; 7 councilmembers (6 from 3 two-member districts + Council President elected at-large); directly elected Mayor; odd-year elections.
  - **City of Tacoma:** Council-Manager charter; 8 councilmembers (5 districts, 3 at-large) + directly elected Mayor as council member; odd-year elections.
- **Epistemic First-Party Sources:** `Wash. Const. Art. I §§ 33, 34, Art. XI § 10; RCW Title 29A (Elections), Title 35 (Cities), Title 35A (Code Cities); Koppang v. Hein, 880 P.2d 529 (Wash. 1994); Municipal Research and Services Center (MRSC) Governance Manual (2025/2026)`

---

### US-WV — West Virginia
- **Option Family:** `mid_atlantic_partisan_dillon`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `W. Va. Const. Art. VI § 39(a); W. Va. Code Ch. 8 (Municipal Code); § 8-1-5a (Municipal Home Rule Program)`
  - `[FACT]` Municipal Home Rule Program (permanent since 2019 under W. Va. Code § 8-1-5a); participating cities may pass local ordinances altering state statutory rules on municipal administration, subject to specific prohibited areas.
- **Primary Statutory Forms:**
  - `Plan I (Mayor-Council)` (W. Va. Code § 8-3-2): Mayor + 5-11 councilmembers.
  - `Plan II (Strong Mayor)` (W. Va. Code § 8-3-3): Mayor is chief executive with veto; Council of 5-11 members.
  - `Plan III (Commission)` (W. Va. Code § 8-3-4): 3 Commissioners exercising executive and legislative power.
  - `Plan IV (Manager-Mayor)` (W. Va. Code § 8-3-5): Mayor elected at-large; Council appoints Manager.
  - `Plan V (City Manager)` (W. Va. Code § 8-3-6): Council elects mayor from own membership; appoints Manager.
- **Electoral Framework:**
  - `Ballot Type:` `charter_determined` (Statute: `W. Va. Code § 8-5-5 (Municipality determines by charter or ordinance whether elections are partisan or nonpartisan)`)
  - `Election Timing:` `spring_annual, even_year_may_consolidated, odd_year_autumn` (Statute: `W. Va. Code § 8-5-5 (Election dates set by charter; commonly second Tuesday in June, or consolidated with statewide May primary of even-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `W. Va. Code § 8-5-11 (Plurality election; candidate with highest vote total elected; no runoffs)`
  - `District / Ward / At-Large:` Options: `pure_at_large, single_member_wards, hybrid_wards_and_at_large` | Default: `pure_at_large (smaller towns) / wards (Charleston, Huntington, Wheeling)` (Statute: `W. Va. Code § 8-5-7`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in Plans I, II, and IV (2- or 4-yr term). Strong Mayor under Plan II (full administrative powers, veto overridden by 2/3 council; § 8-3-3). In Plan V, council selects mayor from own membership.
  - `Administration:` `hybrid_clerk_and_county` | Authority: `W. Va. Code § 8-5-13 (City Recorder/Clerk conducts standalone municipal elections; County Clerk conducts if consolidated with state primary)` | Cost Rule: 100% municipal if standalone; proportional share if consolidated
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `W. Va. Code § 8-5-10`
  - `[FACT]` Governing body fills vacancy by majority vote for remainder of unexpired term, unless charter requires special election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `False` | Type: `prohibited` | Grounds Required: `True` | Threshold: `None%` of `not_applicable` | Window: `None days`
    - `Authority:` `W. Va. Code § 8-12-4 (Recall absent in general law; allowed ONLY where explicitly provided in charter)`
    - `Mechanics:` Recall is absent under general state law. Available only if explicitly enacted in a municipal charter under W. Va. Code § 8-12-4(2).
  - `Municipal Initiative:` Authorized: `False` | Type: `prohibited` | Threshold: `None%` | Exempt Subjects: `all_general_ordinances`
    - `Authority:` `W. Va. Code Ch. 8` | Notes: Citizen initiative for ordinary municipal ordinances is not authorized by general state statute; exists only where enacted by local charter.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `15.0%`
    - `Authority:` `W. Va. Code § 8-1-5a (Home Rule Referendum); Charters` | Notes: Under Municipal Home Rule statute (§ 8-1-5a), 15% voter petition filed within 30 days against any proposed home-rule ordinance forces referendum vote.
- **Named Exceptions & Hero Charters:**
  - **City of Charleston:** Plan II Strong Mayor-Council charter; 26 councilmembers (20 wards, 6 at-large); directly elected Mayor with veto; PARTISAN elections; primary in May, general in November of midterm even years (2022, 2026).
  - **City of Huntington:** Plan II Strong Mayor-Council charter; 11 single-member council districts + directly elected Mayor; nonpartisan primary in May, general in November of presidential even years.
- **Epistemic First-Party Sources:** `W. Va. Const. Art. VI § 39(a); W. Va. Code Ch. 8 (Municipal Corporations); West Virginia Municipal League Handbook (2025/2026)`

---

### US-WI — Wisconsin
- **Option Family:** `midwestern_optional_charter`
- **Home Rule Foundation:** `constitutional_home_rule` | Authority: `Wis. Const. Art. XI § 3 (Home Rule Amendment); Wis. Stat. Ch. 62 (Cities) & Ch. 61 (Villages)`
  - `[FACT]` Constitutional Home Rule (Art. XI § 3); cities and villages have power to determine local affairs through charter ordinances enacted under Wis. Stat. § 66.0101.
- **Primary Statutory Forms:**
  - `Mayor-Council (General Charter Law)` (Wis. Stat. Ch. 62): Default statutory form for 190+ Wisconsin cities.
  - `Village Board (President-Trustees)` (Wis. Stat. Ch. 61): Default statutory form for 415+ villages (President + 6 Trustees).
  - `Council-Manager (City or Village)` (Wis. Stat. Ch. 64): Voter referendum adoption under optional manager law.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Wis. Stat. § 5.60 ('The official spring ballot shall be nonpartisan and shall contain no party designations')`)
  - `Election Timing:` `annual_spring_april` (Statute: `Wis. Stat. § 5.02, § 5.60 (Spring Primary on third Tuesday in February; Spring Election on first Tuesday in April annually)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `Wis. Stat. § 5.01(4) (Plurality election; candidate receiving highest number of votes elected; nonpartisan spring primary in February eliminates all but top two candidates if > 2 file)`
  - `District / Ward / At-Large:` Options: `single_member_aldermanic_districts, pure_at_large` | Default: `single_member_aldermanic_districts (Cities: Wis. Stat. § 62.08; staggered 2-year terms) / at-large (Villages: 6 Trustees: § 61.20)` (Statute: `Wis. Stat. § 62.08, § 61.20`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct election across all forms (2- or 4-yr term). Mayor is chief executive; votes on ties; holds veto over ordinances and partial/line-item veto over budget appropriations (overridden by 2/3 council: Wis. Stat. § 62.09(8)(c)). In villages, Village President presides, votes as trustee, holds no veto.
  - `Administration:` `municipal_clerk_locally_administered` | Authority: `Wis. Stat. § 7.15 (Municipal Clerk conducts all municipal elections and maintains local voter rolls under statewide WisVote system)` | Cost Rule: 100% municipal responsibility
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Wis. Stat. § 17.23`
  - `[FACT]` Common Council fills aldermanic vacancy by majority vote for unexpired term, or calls special election. If mayor vacates, Council President serves until successor elected or council appoints interim.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `simultaneous_incumbent_replacement` | Grounds Required: `False` | Threshold: `25.0%` of `last_gubernatorial_vote` | Window: `60 days`
    - `Authority:` `Wis. Const. Art. XIII § 12; Wis. Stat. § 9.10`
    - `Mechanics:` Universal constitutional right. 25% of total votes cast for Governor in that jurisdiction. SIMULTANEOUS REPLACEMENT BALLOT: Incumbent is automatically on recall ballot as candidate unless resigning within 10 days. Challengers file nomination papers. Plurality winner takes office.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `15.0%` | Exempt Subjects: `administrative_matters, zoning, repeal_of_existing_ordinances`
    - `Authority:` `Wis. Stat. § 9.20 (Direct Legislation)` | Notes: UNIVERSAL STATUTORY RIGHT. Petition signed by 15% of votes cast for Governor in municipality. Council must pass without alteration within 30 days or submit to voters at next spring or general election. Under Landt v. City of Wisconsin Dells (1966), direct legislation CANNOT be used to repeal existing legislation.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `60 days` | Suspends Ordinance: `True` | Threshold: `7.0%`
    - `Authority:` `Wis. Stat. § 66.0101 (Charter Ordinances); § 9.20` | Notes: Protest referendum guaranteed against CHARTER ORDINANCES (petition signed by 7% of votes cast for Governor within 60 days forces referendum under Wis. Stat. § 66.0101(8)). Ordinary ordinances are subject to indirect initiative, not protest referendum.
- **Named Exceptions & Hero Charters:**
  - **City of Milwaukee:** First Class City (Wis. Stat. Ch. 62 Subch. II); 15 single-member aldermanic districts + directly elected Mayor; strong executive administration; nonpartisan spring elections (February primary, April general in presidential even years); mayor possesses full veto including item veto.
  - **City of Madison:** Second Class City; 20 single-member aldermanic districts + directly elected Mayor; nonpartisan spring elections (odd years: 2023, 2025, 2027); Council-Mayor hybrid with strong committee structure.
- **Epistemic First-Party Sources:** `Wis. Const. Art. XI § 3, Art. XIII § 12; Wis. Stat. Ch. 5, 7, 9 (Elections), Ch. 17 (Vacancies), Ch. 61 (Villages), Ch. 62 (Cities), Ch. 66 (General Local Law); Landt v. City of Wisconsin Dells, 30 Wis. 2d 438 (1966); League of Wisconsin Municipalities Handbook (2025/2026)`

---

### US-WY — Wyoming
- **Option Family:** `western_constitutional_direct_democracy`
- **Home Rule Foundation:** `statutory_optional_charter` | Authority: `Wyo. Const. Art. 13 § 1 (Home Rule Amendment); Wyo. Stat. Title 15`
  - `[FACT]` Limited statutory home rule; cities and towns may determine local affairs by charter ordinance, but power is strictly subordinate to statewide statutes.
- **Primary Statutory Forms:**
  - `Mayor-Council` (Wyo. Stat. § 15-3-101 et seq., § 15-2-101): Default statutory form for first-class cities (>4,000 pop) and incorporated towns (<4,000 pop).
  - `Council-Manager` (Wyo. Stat. § 15-4-101 et seq.): Voter petition and referendum adoption (Casper, Laramie).
  - `Commission Form` (Wyo. Stat. § 15-4-201 et seq.): Optional commission plan.
- **Electoral Framework:**
  - `Ballot Type:` `nonpartisan_mandatory` (Statute: `Wyo. Stat. § 22-23-103 ('All municipal elections shall be nonpartisan')`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `Wyo. Stat. § 22-23-102 (Primary on first Tuesday after third Monday in August; General Election on first Tuesday after first Monday in November of even-numbered years)`)
  - `Runoff / Voting Rule:` `top_two_primary_runoff` | Trigger: `50.0%` | Statute: `Wyo. Stat. § 22-23-103, § 22-23-401 (Primary in August eliminates all but top two candidates who advance to November general; plurality in November)`
  - `District / Ward / At-Large:` Options: `single_member_wards, two_councilmen_per_ward, pure_at_large` | Default: `two_councilmen_per_ward (1st Class cities: Wyo. Stat. § 15-3-101; staggered 4-year terms) / at-large (Towns: § 15-2-101)` (Statute: `Wyo. Stat. § 15-3-101, § 15-2-101`)
  - `Mayor Selection:` `direct_popular_election, council_selected_from_membership` | Strong vs. Weak: Direct election in Mayor-Council (4-yr term; votes on ties, holds veto overridden by 2/3 council; § 15-3-102). In Council-Manager cities (Casper, Laramie), Council elects Mayor from own members as president (§ 15-4-102).
  - `Administration:` `county_election_board_coordinated` | Authority: `Wyo. Stat. § 22-23-102 (County Clerk conducts all municipal elections concurrently with county/state elections)` | Cost Rule: Proportionate share billed by county to city under Wyo. Stat. § 22-23-104
- **Vacancy Succession Procedure:**
  - `Rule Type:` `council_appointment_with_special_election_threshold` | Special Election Cutoff: `None months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `Wyo. Stat. § 15-1-107`
  - `[FACT]` Governing body fills vacancy by appointment within 60 days. Appointee serves until next general municipal election, where vacancy is filled for unexpired term if > 2 years remain.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `two_question_standalone` | Grounds Required: `False` | Threshold: `25.0%` of `votes_cast_for_office` | Window: `60 days`
    - `Authority:` `Wyo. Stat. § 15-1-1101 et seq.`
    - `Mechanics:` Universal statutory recall across all cities and towns. 25% of total votes cast for that office at last general election. Two-question ballot: (1) 'Shall [Officer] be recalled?' (2) Successor candidates. If recalled, successor takes office.
  - `Municipal Initiative:` Authorized: `True` | Type: `indirect_council_first` | Threshold: `25.0%` | Exempt Subjects: `appropriations, tax_levies`
    - `Authority:` `Wyo. Stat. § 15-4-110 (Commission/Manager); Charters` | Notes: Authorized in Commission and City Manager forms (20-25% of registered electors). Council must pass within 20 days or submit to voters. Limited in Mayor-Council cities.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `20 days` | Suspends Ordinance: `True` | Threshold: `25.0%`
    - `Authority:` `Wyo. Stat. § 15-4-111` | Notes: Authorized in Commission and Manager forms (25% voter petition within 20 days suspends ordinance until voted upon).
- **Named Exceptions & Hero Charters:**
  - **City of Cheyenne:** Mayor-Council form (First Class City); 9 councilmembers (3 wards, 3 members per ward) + directly elected Mayor with veto; nonpartisan even-year elections; municipal recall available under § 15-1-1101.
  - **City of Casper:** Council-Manager form (adopted 1978); 9 councilmembers (3 wards, 3 members per ward); Council elects Mayor from its membership; even-year elections.
- **Epistemic First-Party Sources:** `Wyo. Const. Art. 13 § 1; Wyo. Stat. Title 15 (Cities and Towns), Title 22 (Election Code); Wyoming Association of Municipalities Governance Manual (2025/2026)`

---

### US-DC — District of Columbia
- **Option Family:** `mid_atlantic_partisan_dillon`
- **Home Rule Foundation:** `federal_home_rule_act` | Authority: `U.S. Const. Art. I § 8 cl. 17; District of Columbia Home Rule Act of 1973 (Public Law 93-198; D.C. Official Code Title 1)`
  - `[FACT]` Federal Home Rule Charter; unique municipal-territorial jurisdiction subject to plenary constitutional power of the United States Congress; all local legislation subject to mandatory congressional layover and veto.
- **Primary Statutory Forms:**
  - `Mayor-Council (Home Rule Charter)` (D.C. Code § 1-204.01 et seq.): Universal governance form prescribed by the 1973 Home Rule Act.
- **Electoral Framework:**
  - `Ballot Type:` `partisan_mandatory` (Statute: `D.C. Code § 1-1001.08 (Closed partisan primaries in June of even-numbered years; general election in November)`)
  - `Election Timing:` `even_year_november_consolidated` (Statute: `D.C. Code § 1-1001.05 (Primary on first Tuesday in June; General Election on first Tuesday after first Monday in November of even-numbered years)`)
  - `Runoff / Voting Rule:` `pure_plurality` | Trigger: `None%` | Statute: `D.C. Code § 1-1001.10 (Plurality election; candidate with highest vote total elected; no runoffs; Ranked-Choice Voting ballot initiative approved 2024 taking effect in future cycles)`
  - `District / Ward / At-Large:` Options: `hybrid_wards_and_at_large_with_minority_quota` | Default: `hybrid_wards_and_at_large_with_minority_quota (13-member Council: 8 ward members + 4 at-large members + 1 Chairman elected at-large: D.C. Code § 1-204.01)` (Statute: `D.C. Code § 1-204.01 (MANDATORY MINORITY PARTY QUOTA: For the 4 at-large council seats, no political party may nominate more than two candidates, guaranteeing at least two seats to minority party or independent members)`)
  - `Mayor Selection:` `direct_popular_election` | Strong vs. Weak: Direct popular election (4-yr term). Strong Mayor under D.C. Code § 1-204.22: chief executive administrator with full appointment authority over cabinet agencies, executive orders, and veto power overridden by 2/3 council (§ 1-204.04).
  - `Administration:` `state_election_board` | Authority: `D.C. Code § 1-1001.03 (Independent District of Columbia Board of Elections conducts all primaries, general elections, and ANC elections)` | Cost Rule: 100% borne by District of Columbia municipal-territorial budget
- **Vacancy Succession Procedure:**
  - `Rule Type:` `special_election_mandatory` | Special Election Cutoff: `8 months` | Party Caucus Succession: `False` | Citizen Override: `False`
  - `Statutes:` `D.C. Code § 1-204.01(d), § 1-1001.10`
  - `[FACT]` Board of Elections must call a special election within 114 days to fill vacancy for unexpired term. If vacancy occurs in an at-large seat belonging to a political party, that party's state central committee selects an interim member to serve pending the special election.
- **Direct Democracy Architecture:**
  - `Municipal Recall:` Authorized: `True` | Type: `yes_no_retention` | Grounds Required: `False` | Threshold: `10.0%` of `registered_voters` | Window: `180 days`
    - `Authority:` `D.C. Code § 1-204.111 et seq., § 1-1001.16`
    - `Mechanics:` Home Rule Charter right. Requires signatures of 10% of registered electors District-wide, PLUS at least 10% of registered electors in at least 5 of the 8 election wards! Standalone Yes/No recall vote; if recalled, seat is vacant and filled by special election.
  - `Municipal Initiative:` Authorized: `True` | Type: `direct_to_ballot` | Threshold: `5.0%` | Exempt Subjects: `appropriations_of_funds, laws_violating_human_rights_act, charter_amendments`
    - `Authority:` `D.C. Code § 1-204.101 et seq., § 1-1001.16` | Notes: 5% of registered electors District-wide with 5% in at least 5 of the 8 wards. Must undergo mandatory 30-day (or 60-day) Congressional Layover Review before becoming effective.
  - `Municipal Referendum:` Authorized: `True` | Protest Referendum Available: `True` | Window: `30 days` | Suspends Ordinance: `True` | Threshold: `5.0%`
    - `Authority:` `D.C. Code § 1-204.102, § 1-1001.16` | Notes: 5% of registered electors filed within 30 days of mayoral transmission to Congress suspends the act until voted on at election.
- **Named Exceptions & Hero Charters:**
  - **District of Columbia (Single Metropolitan Jurisdiction):** Unique federal enclave municipal-state hybrid; Advisory Neighborhood Commissions (ANCs: ~345 single-member districts of ~2,000 residents each electing nonpartisan commissioners every 2 years; ANCs receive mandatory 'great weight' in zoning, liquor, and street administrative decisions under D.C. Code § 1-309.10); Congressional Layover Review under D.C. Code § 1-206.02.
- **Epistemic First-Party Sources:** `U.S. Const. Art. I § 8 cl. 17; District of Columbia Home Rule Act (Public Law 93-198); D.C. Official Code Title 1 (Government Organization); D.C. Board of Elections Rules and Regulations (2025/2026)`

---

## 6. IMPLEMENTATION-READY SIMULATION CARGO & TYPESCRIPT CONTRACTS

To support `#98 Municipal Governance`, `Local Candidacy & Elections Engine`, and `Future Local Political Life`, the following pure TypeScript schemas define the domain model for local political life in *Our Civic Duty*:

```typescript
// File: src/simulation/municipal-elections-types.ts
// Authority: 92O National Municipal Elections and Direct Democracy Matrix (2026-09-05)

export type MunicipalOptionFamilyId =
  | 'new_england_town_meeting'
  | 'mid_atlantic_partisan_dillon'
  | 'southern_runoff_general_law'
  | 'midwestern_optional_charter'
  | 'western_constitutional_direct_democracy'
  | 'consolidated_city_county';

export type MunicipalBallotType =
  | 'nonpartisan_mandatory'
  | 'partisan_mandatory'
  | 'nonpartisan_default_partisan_optional'
  | 'partisan_default_nonpartisan_optional'
  | 'charter_determined';

export type MunicipalTimingModel =
  | 'even_year_november_consolidated'
  | 'odd_year_november_consolidated'
  | 'annual_spring_april'
  | 'annual_spring_may'
  | 'odd_year_spring'
  | 'spring_even_year'
  | 'town_meeting_day_march'
  | 'annual_autumn_october'
  | 'quadrennial_summer_june'
  | 'quadrennial_late_summer_august';

export type MunicipalRunoffThresholdType =
  | 'pure_plurality'
  | 'majority_50_plus_1'
  | 'top_two_primary_runoff'
  | 'ranked_choice_instant_runoff'
  | 'locally_selectable';

export type MunicipalVacancyRuleType =
  | 'council_appointment_full_term'
  | 'council_appointment_with_special_election_threshold'
  | 'party_precinct_committeeperson_caucus'
  | 'mayoral_appointment_council_consent'
  | 'special_election_mandatory';

export type MunicipalRecallProcedureType =
  | 'two_question_standalone'
  | 'simultaneous_incumbent_replacement'
  | 'yes_no_retention'
  | 'judicial_cause_removal_trial'
  | 'prohibited';

export interface StateMunicipalFramework {
  readonly jurisdictionId: string; // e.g. 'us-ky', 'us-tx', 'us-ca'
  readonly stateName: string;
  readonly familyId: MunicipalOptionFamilyId;
  readonly homeRuleStatus: 'dillons_rule_strict' | 'statutory_optional_charter' | 'constitutional_home_rule' | 'federal_home_rule_act';
  readonly ballotType: MunicipalBallotType;
  readonly primaryTimingModel: MunicipalTimingModel;
  readonly runoffThresholdType: MunicipalRunoffThresholdType;
  readonly runoffTriggerPct: number | null; // e.g. 50.0
  readonly partyCaucusSuccessionApplies: boolean;
  readonly citizenPetitionCanOverrideVacancy: boolean;
  readonly recallAuthorized: boolean;
  readonly recallProcedureType: MunicipalRecallProcedureType;
  readonly recallRequiresJudicialCause: boolean;
  readonly recallSignatureThresholdPct: number | null;
  readonly ordinanceInitiativeAuthorized: boolean;
  readonly protestReferendumAuthorized: boolean;
  readonly protestReferendumSuspendsOrdinance: boolean;
}
```

### Citizen Recall Petition State Machine

```mermaid
stateDiagram-v2
    [*] --> NoticeOfIntent: Citizens File Notice of Intent with City Clerk
    NoticeOfIntent --> JudicialReview: States requiring cause (WA, GA, FL)
    NoticeOfIntent --> PetitionCirculation: States with political recall (CA, CO, MI, WI, NV, OR)
    
    JudicialReview --> PetitionCirculation: Court certifies legal sufficiency of charges
    JudicialReview --> Quashed: Court dismisses charges as legally insufficient
    
    PetitionCirculation --> SignatureVerification: Signatures filed within window (30 to 180 days)
    PetitionCirculation --> Expired: Circulation window closes with insufficient signatures
    
    SignatureVerification --> RecallElectionScheduled: City Clerk verifies signatures >= threshold
    SignatureVerification --> CuredPeriodOrRejected: Signatures fail verification
    
    RecallElectionScheduled --> OfficialRecalled: Election held; YES > 50% (and meets ID threshold)
    RecallElectionScheduled --> OfficialRetained: Election held; NO >= 50%
    
    OfficialRecalled --> SuccessorTakesOffice: Two-question ballot (CA/CO) or Replacement race (WI/NE)
    OfficialRecalled --> VacancyProcedureTriggered: Retention vote (AK/LA/MI); filled under vacancy rules
```

---

## 7. CATALOG OF UNRESOLVED SOURCE CONFLICTS & FRONTIER FIELDS

1. **North Carolina Nonpartisan Plurality vs. Primary Election Synchronization:**
   - Under N.C.G.S. § 163-291, municipalities may switch between four electoral methods by charter or local ordinance. Several medium-sized North Carolina municipalities maintain charter provisions that reference repealed 1970s election board rules. Local ordinances must be audited against county board of elections practice.
2. **Illinois Non-Home-Rule Term Limit Jurisprudence:**
   - The Illinois Supreme Court in *Leck v. Michaelson* (111 Ill. 2d 523) and subsequent appellate cases has repeatedly split on whether non-home-rule villages can adopt term limits by citizen referendum. While home-rule municipalities clearly can, the statutory authority for non-home-rule municipalities remains an active judicial gray zone.
3. **Texas General Law Type A Runoff vs. Plurality Custom:**
   - TLGC § 22.010 and Tex. Elec. Code § 2.021 mandate majority voting for Type A general-law cities, but permit adopting plurality voting by ordinance under § 2.022. Small Type A cities often leave unrecorded whether the council adopted a formal plurality ordinance or simply operates under unlawful custom.
4. **Kentucky Urban-County / Metro Initiative Immunity:**
   - While KRS 83A.130 and 83A.150 grant explicit statutory initiative and referendum to cities operating under City Manager or Commission forms, KRS Chapters 67A (LFUCG) and 67C (Louisville Metro) contain zero express authorization for general citizen ordinance initiatives. The simulation engine must treat LFUCG and Louisville Metro as lacking general citizen ordinance initiatives.

---

## 8. PRIMARY STATUTORY, CONSTITUTIONAL, AND REGULATORY CITATION REGISTRY

- **State Constitutions:**
  - Ala. Const. Art. IV, VII; Alaska Const. Art. X, XI; Ariz. Const. Art. 4, 8, 13; Ark. Const. Amend. 7; Cal. Const. Art. II, XI; Colo. Const. Art. V, XX, XXI; Conn. Const. Art. X; Fla. Const. Art. VIII; Ga. Const. Art. IX; Haw. Const. Art. VIII; Idaho Const. Art. XII; Ill. Const. Art. VII; Ind. Const. Art. 6; Iowa Const. Art. III § 38A; Kan. Const. Art. 4, 12; Ky. Const. §§ 148, 150, 152, 156b, 160; La. Const. Art. VI, X; Maine Const. Art. VIII-A; Md. Const. Art. XI, XI-E; Mass. Const. Amend. Art. 89; Mich. Const. Art. II, VII; Minn. Const. Art. XII; Miss. Const. Art. 4 § 88; Mo. Const. Art. VI; Mont. Const. Art. XI; Neb. Const. Art. XI; Nev. Const. Art. 2, 15, 19; N.H. Const. Pt. I Art. 39; N.J. Const. Art. I, IV; N.M. Const. Art. X; N.Y. Const. Art. IX; N.C. Const. Art. VII; N.D. Const. Art. VII; Ohio Const. Art. II § 1f, Art. XVIII §§ 3, 7; Okla. Const. Art. XVIII; Or. Const. Art. II, IV, XI; Pa. Const. Art. VI § 7, Art. VII § 3, Art. IX § 2; R.I. Const. Art. XIII; S.C. Const. Art. VIII; S.D. Const. Art. III § 1, Art. IX § 2; Tenn. Const. Art. XI § 9; Tex. Const. Art. XI §§ 5, 11; Utah Const. Art. VI, XI; Vt. Const. Ch. II § 69; Va. Const. Art. VII; Wash. Const. Art. I §§ 33, 34, Art. XI § 10; W. Va. Const. Art. VI § 39(a); Wis. Const. Art. XI § 3, Art. XIII § 12; Wyo. Const. Art. 13 § 1; U.S. Const. Art. I § 8 cl. 17.
- **Seminal Precedents & Legal Treatises:**
  - *Citizens Committee to Recall Rizzo v. Board of Elections*, 470 Pa. 1 (1976) (Municipal recall unconstitutional under Pennsylvania Constitution).
  - *Matter of Cassella v. City of Schenectady*, 281 A.D. 428 (N.Y. App. Div. 1953) (Local recall charters invalid absent explicit state constitutional authorization).
  - *Koppang v. Hein*, 880 P.2d 529 (Wash. 1994) (Local term limits on municipal elected officials unconstitutional without state legislative authorization).
  - *Landt v. City of Wisconsin Dells*, 30 Wis. 2d 438 (1966) (Direct legislation initiative cannot be used to repeal existing municipal legislation).
  - *Gonzales v. City of Tucson*, 727 F.3d 949 (9th Cir. 2013) (Modified ward primary with at-large general election upheld under Voting Rights Act).
  - *Pinnick v. Shannon*, 490 S.W.2d 460 (Ky. 1973) (Urban-county consolidation constitutional under Ky. Const. §§ 156-160).
  - *Hacker v. Baesler*, 812 S.W.2d 706 (Ky. 1991) (Mayoral veto inapplicable to zoning map amendments in consolidated urban-county government).
