import {createRequire} from 'node:module';
import {writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {strict as assert} from 'node:assert';
const require=createRequire('/workspace/team3-ui-profile-0fcf93/package.json');const {chromium}=require('@playwright/test');
const out='/workspace/team3-evidence/oct5-personal-screen-design';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1100,height:1500},deviceScaleFactor:1});
const errors:string[]=[];page.on('pageerror',(e:any)=>errors.push(String(e)));
await page.setContent(readFileSync(out+'/comparison.html','utf8'),{waitUntil:'load'});
const base=await page.evaluate(()=>JSON.stringify((window as any).designFacts));
const dataHash=createHash('sha256').update(base).digest('hex');const checks:any[]=[];
for(const layout of ['a','b','c'])for(const width of [720,390]){
 await page.locator(`[data-layout="${layout}"]`).click();await page.locator(`[data-width="${width}"]`).click();
 await page.locator('.figure img').evaluate(async (img:any)=>{if(!img.complete)await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject});});
 const metrics=await page.locator('#stage').evaluate((node:any)=>({width:node.getBoundingClientRect().width,scrollWidth:node.scrollWidth,clientWidth:node.clientWidth,figure:node.querySelector('.figure').getBoundingClientRect().toJSON(),right:node.querySelector('.right').getBoundingClientRect().toJSON(),naturalWidth:node.querySelector('img').naturalWidth,family:Array.from(node.querySelectorAll('.family li')).map((n:any)=>n.dataset.personId),work:Array.from(node.querySelectorAll('.now')).map((n:any)=>n.dataset.workId)}));
 assert(metrics.naturalWidth>0);assert(metrics.scrollWidth<=metrics.clientWidth+1,'No horizontal panel overflow');assert(metrics.figure.right<=metrics.right.x+1,'Full figure remains left of facts');assert.equal(metrics.family.length,3);assert.deepEqual(metrics.work,['work-relationship_79cdc4b8de27d29c']);assert.equal(await page.evaluate(()=>JSON.stringify((window as any).designFacts)),base);
 await page.locator('#stage').screenshot({path:`${out}/layout-${layout}-${width}.png`});checks.push({layout,width,...metrics,sameDataHash:dataHash});
}
// Actual narrow browser viewport, in addition to embedded panel widths above.
await page.setViewportSize({width:390,height:1200});
for(const layout of ['a','b','c']){
 await page.locator(`[data-layout="${layout}"]`).click();await page.locator('[data-width="390"]').click();
 const metrics=await page.locator('#stage').evaluate((node:any)=>({width:node.getBoundingClientRect().width,scrollWidth:node.scrollWidth,clientWidth:node.clientWidth,figure:node.querySelector('.figure').getBoundingClientRect().toJSON(),right:node.querySelector('.right').getBoundingClientRect().toJSON(),pageScrollWidth:document.documentElement.scrollWidth,pageWidth:document.documentElement.clientWidth}));
 assert(metrics.scrollWidth<=metrics.clientWidth+1);assert(metrics.pageScrollWidth<=metrics.pageWidth+1,'No horizontal page overflow at actual narrow viewport');assert(metrics.figure.right<=metrics.right.x+1);assert.equal(await page.evaluate(()=>JSON.stringify((window as any).designFacts)),base);
 await page.locator('#stage').screenshot({path:`${out}/layout-${layout}-viewport390.png`});checks.push({layout,viewport:390,kind:'actual-browser-viewport',...metrics,sameDataHash:dataHash});
}
await page.setViewportSize({width:1100,height:1500});
await page.locator('[data-layout="a"]').click();await page.locator('[data-mode="history"]').click();assert.equal(await page.locator('[data-work-id="work-relationship_518ca797ed2c8401"]').innerText(),'Store assistant at Neighborhood Market\n2007–2009');
await page.locator('[data-layout="b"]').click();await page.locator('[data-open-history]').click();assert(await page.locator('#history-dialog').isVisible());await page.locator('#history-dialog .close').click();
await page.locator('[data-layout="c"]').click();await page.locator('.history-c>summary').click();assert(await page.locator('.history-c .history').isVisible());
assert.equal(errors.length,0);
await browser.close();writeFileSync(`${out}/render-receipt.json`,JSON.stringify({kind:'isolated-design-artifact-render',checks,historyControls:'all3 verified',correctEndedPeriod:true,consoleErrors:errors,productionRouteTested:false,playerSaveAccessed:false,liveUIOperated:false},null,2)+'\n');console.log(JSON.stringify({renders:checks.length,allSameFacts:dataHash,historyControls:3,errors:0,productionRouteTested:false},null,2));
