# Personal-screen comparison

Three design proposals use Marshall Alexander's same recorded figure and facts. Current work and education come first; full history stays separate. A: Split record is recommended. These are review artifacts. No game layout has been activated.

## Comparisons

Open [comparison.html](comparison.html) in a local browser. It is self-contained.

| Option | Embedded panel | Narrow browser viewport |
| --- | --- | --- |
| A: Split record | [720 pixels](layout-a-720.png) | [390-pixel viewport](layout-a-viewport390.png) |
| B: Compact reference | [720 pixels](layout-b-720.png) | [390-pixel viewport](layout-b-viewport390.png) |
| C: Open sections | [720 pixels](layout-c-720.png) | [390-pixel viewport](layout-c-viewport390.png) |

[Design data](design-data.json), [figure provenance](figure-provenance.json), [render receipt](render-receipt.json), [same generated source records](source-records.json), [independent review](independent-review.txt), and [original report](receipt.md) accompany the images. The original report retains cloud evidence paths; use these relative links locally.

Executed source: 2fe84d26812c78c808caff1e80409acfd5c1a68f. Nine artifact renders and three history controls passed. No simulation, browser, or typecheck was repeated for transport. Editorial approval and implementation remain separate.
