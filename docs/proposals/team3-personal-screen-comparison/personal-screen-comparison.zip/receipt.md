# Personal can show the person before the full history

Choose among three personal-screen proposals built from Marshall Alexander's recorded life. All keep the complete figure on the left, current work and education first on the right, followed by identity, family, and personality. I recommend the split Profile and Full history view. It keeps the current restaurant job apart from the earlier Market job and remains readable in a narrow panel. These are review artifacts. No game layout or new biography has been activated.

## The three comparisons

| Proposal | Profile and history | Embedded comparison | Narrow browser comparison |
| --- | --- | --- | --- |
| A: Split record, recommended | Profile and Full history tabs. Current facts stay together; history has its own reader. | [A at 720 pixels](/workspace/team3-evidence/oct5-personal-screen-design/layout-a-720.png) | [A in a 390-pixel viewport](/workspace/team3-evidence/oct5-personal-screen-design/layout-a-viewport390.png) |
| B: Compact reference | Smaller figure column. Family and personality fold individually; full history opens in a dialog. | [B at 720 pixels](/workspace/team3-evidence/oct5-personal-screen-design/layout-b-720.png) | [B in a 390-pixel viewport](/workspace/team3-evidence/oct5-personal-screen-design/layout-b-viewport390.png) |
| C: Open sections | Profile has fewer navigation controls. A separate history section expands below it, producing the longest combined record. | [C at 720 pixels](/workspace/team3-evidence/oct5-personal-screen-design/layout-c-720.png) | [C in a 390-pixel viewport](/workspace/team3-evidence/oct5-personal-screen-design/layout-c-viewport390.png) |

Measured: the [interactive comparison](/workspace/team3-evidence/oct5-personal-screen-design/comparison.html) uses one person and one data object for all three options. Its controls change the layout and panel width. The artifact is self-contained and makes no network or game-save request. [Artifact generator](/workspace/team3-evidence/oct5-personal-screen-design/build-design.py).

## The same recorded person in each option

Measured: Marshall is 34, born August 2, 1991, with recorded birthplace and residence in Hinsdale, Montana. The current job is Server at Hinsdale Family Restaurant, beginning January 5, 2026. No education enrollment is active. [Actual generated records](/workspace/team3-evidence/oct5-life-history-proposal/actual-records.json).

Measured: each proposed family list contains Sharon Alexander, “your mom”; Paul Alexander, “your dad”; and Roland Alexander, “your younger brother.” These are existing known identities and relationships. They do not establish co-residence or disclose private employment, education, or memories. The household member list remains empty in the source packet. [Family relationship and dossier rows](/workspace/team3-evidence/oct5-life-history-proposal/actual-records.json).

Measured: the full-history readers preserve the ended Store assistant relationship at Neighborhood Market from 2007 through 2009 and the separate active restaurant relationship from 2026. Their employer IDs are unchanged. Education retains three recorded enrollment periods and statuses. Existing upbringing sentences and the recorded lunch-table memory remain in history. [Shared design data](/workspace/team3-evidence/oct5-personal-screen-design/design-data.json).

Measured: the full figure is the existing appearance composer's output from Marshall's saved appearance seed and default recipe. Eight input assets were checked against the executed source. The standing image is 512 by 808 pixels; its complete head and feet are preserved in each profile. Feminine presentation does not replace Marshall's unstated gender. [Figure provenance](/workspace/team3-evidence/oct5-personal-screen-design/figure-provenance.json).

Proposed personality copy reads “In conversation: a slight preference for asking questions.” and “In free time: a slight preference for company.” These phrases are inferred from two dated self records with subtle strength and low confidence. The current upbringing projection emits no leaning lines for this opening. These are proposed labels for editorial review, not a claim that the game currently renders them. [Exact wording and grounding packet](/workspace/team3-evidence/oct5-personal-screen-design/personality-packet.txt).

## What was checked

Measured: nine isolated browser renders used the same facts. Six compared three options at embedded panel widths of 720 and 390 pixels. Three used an actual browser viewport 390 pixels wide. The narrow panels were 360 pixels wide after page margins. Every render kept the figure left of the facts, with no horizontal panel or page overflow. The browser reported zero page errors. [Render receipt](/workspace/team3-evidence/oct5-personal-screen-design/render-receipt.json).

Measured: all three history controls opened their intended readers. The ended Market job displayed “2007–2009.” The profile showed only the active restaurant work ID. Each profile retained all three known family IDs. [Render checks](/workspace/team3-evidence/oct5-personal-screen-design/render-check.mts).

## Next and method

The owner can choose A, B, or C. T8 retains the shared Personal screen writer. Any implementation requires its own exact handoff and changed-path checks. The family-list proposal and proposed personality copy remain proposals; no event knowledge, private biography, conversation, or presence is granted by this comparison.

Executed source: detached main `2fe84d26812c78c808caff1e80409acfd5c1a68f`. Seed: `team3-oct5-proposed-news-exchanges`; place key `3036475`; game date January 5, 2026. The existing generated packet and its successful unchanged-world, unchanged-clock, serialization/reload receipt were reused. No opening or simulation test was repeated.

Final browser command: `OCD_STORAGE_STATE_DIR=/workspace/team3-evidence/storage-state OCD_WORKSPACE_OWNER=team3 npm run storage -- run test -- node --import tsx /workspace/team3-evidence/oct5-personal-screen-design/render-check.mts`. Handle82313 exited0. This checked the isolated design HTML, not the production Personal route. No typecheck or full suite was run for an artifact-only task. [Final command log](/workspace/team3-evidence/oct5-personal-screen-design/render-final.log).

Earlier attempts encountered a nested Git call refusal, Chromium sandbox socket failure, and a blocked file URL. Their logs are preserved. Asset hashes were verified separately, and the successful browser render loaded the self-contained HTML in memory. No live UI port, owner save, production source, or held A87 file was touched.
