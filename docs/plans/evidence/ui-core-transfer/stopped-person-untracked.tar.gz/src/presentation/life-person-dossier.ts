import { ageOnDate, personName } from "../simulation";
import type { EntityId, World } from "../simulation";
import {
  projectHomePlace,
  projectLatestInteraction,
  projectPublicPosition,
  type PlayerVisibleFact,
  type QuickDossierProjection,
} from "./run-a-projection";

/**
 * A dossier for somebody in an ordinary life.
 *
 * The office route already has `projectRunADossier`, and reusing it here was
 * the obvious shortcut and the wrong one: its unsupplied fields fall back to
 * office language — a working habit about constituent-service notes, an
 * unresolved priority about "this afternoon's briefing" — which is fabricated
 * content the moment the person being described is somebody's mother. A
 * ten-year-old's household is not a legislative office and must not be
 * narrated as one.
 *
 * So this projection shares the shape and the canonical helpers, and differs in
 * exactly one respect: where the World has nothing, it says so. An unknown fact
 * stays unknown rather than being filled with plausible prose. Everything here
 * is read from the World the player is actually in; nothing is invented, and no
 * fact the simulation keeps private is exposed.
 */

/** What the life route already knows about somebody, from canonical records. */
export interface LifePersonContext {
  readonly personId: EntityId;
  /**
   * How this life stands to them — "your mother", "your brother" — as the
   * generated household or the current scene records it. Null when the World
   * has not established one; it is never guessed from a name or an age.
   */
  readonly relationship: string | null;
  /** Whether they are physically in the room this moment. */
  readonly present: boolean;
}

function unknownFact(
  id: string,
  label: string,
  value: string,
): PlayerVisibleFact {
  return { id, label, value, access: "unknown" };
}

export function projectLifePersonDossier(
  world: World,
  playerPersonId: EntityId,
  context: LifePersonContext,
): QuickDossierProjection {
  const person = world.people[context.personId];
  if (!person) {
    throw new Error(
      `No person ${context.personId} in this world. A dossier is never shown for a reference the World cannot resolve.`,
    );
  }

  const standing = context.relationship ?? "Known to you";

  /*
   * Only the facts the World actually supports. `projectPublicPosition` and
   * `projectLatestInteraction` already return an honest unknown when there is
   * nothing on record, so they are kept whatever they say — an explicit "no
   * meaningful interaction is known" is information, and hiding it would make
   * an empty dossier look like a complete one.
   */
  const knownFacts: PlayerVisibleFact[] = [
    /*
     * Said once. The standing is already the heading and the impression line,
     * and repeating "your mom" a third time under "What stands out" made a
     * two-word relationship look like the sum of what this life knows about
     * her. When it is NOT recorded, that absence is worth a line of its own.
     */
    ...(context.relationship
      ? []
      : [
          unknownFact(
            "standing",
            "How you know them",
            "How you know them is not recorded.",
          ),
        ]),
    projectPublicPosition(world, person.id),
  ];

  return {
    personId: person.id,
    name: personName(person),
    title: standing,
    /*
     * The subtitle carries something the heading does not. Repeating the
     * standing here put the same two words on consecutive lines; presence is
     * the fact that actually differs between one person and the next.
     */
    role: context.present ? "Here now" : "Not in the room",
    age: {
      id: "age",
      label: "Age",
      value: String(ageOnDate(person.birthDate, world.currentDate)),
      access: "institutionally-accessible",
    },
    homePlace: projectHomePlace(world, person.id),
    relationship: context.relationship
      ? {
          id: "relationship",
          label: "Relationship",
          value: context.relationship,
          access: "personally-known",
        }
      : unknownFact(
          "relationship",
          "Relationship",
          "You have no settled word for what they are to you.",
        ),
    /*
     * The life route keeps no per-person "current read", and inventing one is
     * precisely the failure this module exists to avoid.
     */
    read: unknownFact(
      "read",
      "Current read",
      "You have not formed a settled impression of them.",
    ),
    knownFacts,
    latestInteraction: projectLatestInteraction(
      world,
      person.id,
      playerPersonId,
    ),
    unresolved: unknownFact(
      "unresolved",
      "Unfinished between you",
      "Nothing is recorded as unfinished between you.",
    ),
  };
}
