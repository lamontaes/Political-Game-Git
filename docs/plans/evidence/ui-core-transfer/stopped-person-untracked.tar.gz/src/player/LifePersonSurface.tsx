import {
  conversationReaching,
  type AvailableConversation,
} from "../presentation/player-conversation";
import { projectLifePersonDossier } from "../presentation/life-person-dossier";
import type { LifePersonContext } from "../presentation/life-person-dossier";
import type { EntityId, World } from "../simulation";
import { PlayerConversation } from "./PlayerConversation";
import { QuickDossier } from "./QuickDossier";

/**
 * One person, the one the player actually chose.
 *
 * This is the repair for the recorded main-build failure: the rail knew which
 * person had been clicked and the shell threw it away, opening a generic list
 * of every conversation the life could have. Selecting A and selecting B gave
 * the same screen, so the player had no way to act on a particular person.
 *
 * Here the selection is carried all the way through. The dossier is that
 * person's, projected from the World. Talk opens the conversation whose room
 * actually admits them — and when no room does, the surface says which
 * limitation applies instead of opening a conversation with somebody else.
 *
 * Viewing somebody is not talking to them, and neither is a change to the
 * world: opening this reads, and nothing more.
 */
export function LifePersonSurface({
  world,
  playerPersonId,
  person,
  onClose,
  onWorldChange,
}: {
  readonly world: World;
  readonly playerPersonId: EntityId;
  readonly person: LifePersonContext;
  readonly onClose: () => void;
  readonly onWorldChange: (world: World) => void;
}) {
  const dossier = projectLifePersonDossier(world, playerPersonId, person);
  const reachable: AvailableConversation | null = conversationReaching(
    world,
    playerPersonId,
    person.personId,
  );

  return (
    <div
      className="life-person-surface"
      data-testid="person-surface"
      data-person-id={person.personId}
    >
      <QuickDossier dossier={dossier} onClose={onClose} />

      <div className="life-person-actions">
        {reachable ? (
          <PlayerConversation
            world={world}
            personId={playerPersonId}
            subject={reachable.subject}
            onWorldChange={onWorldChange}
          />
        ) : (
          /*
           * Said specifically, by the room. "Talk" that is greyed out with no
           * reason teaches the player nothing; this names the actual condition
           * — there is no room right now in which this person can be spoken to
           * — without pretending a conversation happened.
           */
          <p className="game-note" data-testid="person-unreachable">
            There is no conversation open with {dossier.name} right now. Nobody
            is in a room with them that this life can speak in.
          </p>
        )}
      </div>
    </div>
  );
}
