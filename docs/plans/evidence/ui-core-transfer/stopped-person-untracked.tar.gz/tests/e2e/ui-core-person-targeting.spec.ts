import { expect, test, type Page } from "@playwright/test";

import { enterLife, startLife } from "./support/creator";

/**
 * UI-CORE-RELEASE — the person the player chose is the person they get.
 *
 * The recorded main-build failure: the people rail emitted the id of the person
 * clicked, `PlayerGame` discarded it, and a generic list of every available
 * conversation opened instead. Choosing A and choosing B produced the same
 * screen with the same participants, so nothing in the game could be done to a
 * particular person.
 *
 * These run on the NORMAL route through the real creator — no fixture, no
 * prototype — because the failure was a normal-play failure.
 */

/** Every person the rail is currently offering, in rail order. */
async function railPeople(page: Page): Promise<string[]> {
  return page
    .locator('[data-testid^="rail-person-"]')
    .evaluateAll((nodes) =>
      nodes.map((node) => node.getAttribute("data-testid") ?? ""),
    );
}

function personIdFrom(testId: string): string {
  return testId.replace("rail-person-", "");
}

async function openRailPerson(page: Page, testId: string) {
  await page.getByTestId(testId).click();
  await expect(page.getByTestId("person-surface")).toBeVisible();
}

/*
 * One life, walked once, then examined.
 *
 * Every check below is about what the shell does with a person AFTER a life
 * exists, so walking the creator four times tested the creator four times and
 * the repair once each. Serial mode over a single page is the honest way to
 * spend that time — the alternative was a longer per-test timeout, which would
 * have hidden how much of it was setup rather than reducing it.
 */
test.describe.configure({ mode: "serial" });

test.describe("UI-CORE-RELEASE person targeting", () => {
  let page: Page;

  /*
   * Setup only. The creator walk is fifteen staged clicks and costs more than
   * the default hook budget on a loaded machine — that is the cost of getting
   * to a life, not a property of the repair. Every assertion below keeps the
   * default timeout, because how fast the shell answers IS under test.
   */
  test.setTimeout(180_000);

  test.beforeAll(async ({ browser }) => {
    test.setTimeout(180_000);
    page = await browser.newPage();
    await page.goto("/");
    await startLife(page, { age: 10, childhood: true });
    await enterLife(page);
    await expect(page.getByTestId("people-rail")).toBeVisible();
  });

  test.afterAll(async () => {
    await page.close();
  });

  /** Leaves the people panel closed and nobody selected. */
  async function resetSelection() {
    const back = page.getByTestId("person-back-to-people");
    if ((await back.count()) > 0) await back.click();
  }

  test("A then B then A each open their own record, never a generic one", async () => {
    await resetSelection();

    const rail = await railPeople(page);
    /*
     * A ten-year-old's generated household is the standing cast, so there is
     * more than one person to confuse with another. If a life ever generated
     * with one person in it, this proof would be vacuous rather than passing.
     */
    expect(rail.length).toBeGreaterThan(1);
    const [first, second] = rail as [string, string];
    const firstId = personIdFrom(first);
    const secondId = personIdFrom(second);
    expect(firstId).not.toBe(secondId);

    await openRailPerson(page, first);
    await expect(page.getByTestId("person-surface")).toHaveAttribute(
      "data-person-id",
      firstId,
    );
    const firstName = await page.locator("#dossier-name").innerText();

    /* B, from inside A's surface: the selection has to actually change. */
    await page.getByTestId("person-back-to-people").click();
    await openRailPerson(page, second);
    await expect(page.getByTestId("person-surface")).toHaveAttribute(
      "data-person-id",
      secondId,
    );
    const secondName = await page.locator("#dossier-name").innerText();
    expect(secondName).not.toBe(firstName);

    /* And back to A: the previous target does not linger. */
    await page.getByTestId("person-back-to-people").click();
    await openRailPerson(page, first);
    await expect(page.getByTestId("person-surface")).toHaveAttribute(
      "data-person-id",
      firstId,
    );
    await expect(page.locator("#dossier-name")).toHaveText(firstName);
  });

  test("the dossier describes that person from the world, and invents nothing", async () => {
    await resetSelection();

    const rail = await railPeople(page);
    await openRailPerson(page, rail[0] as string);

    const surface = page.getByTestId("person-surface");

    /*
     * The office route's dossier fills unsupplied fields with office language.
     * A ten-year-old's household must never be narrated in it.
     */
    await expect(surface).not.toContainText("constituent-service notes");
    await expect(surface).not.toContainText("this afternoon's briefing");

    /* What is not known is shown as not known, not filled in. */
    const unknowns = await surface
      .locator('[data-access="unknown"]')
      .allInnerTexts();
    for (const text of unknowns) {
      expect(text.trim().length).toBeGreaterThan(0);
    }
  });

  test("Talk reaches that person's own conversation, or says why it cannot", async () => {
    await resetSelection();

    const rail = await railPeople(page);
    await openRailPerson(page, rail[0] as string);

    const surface = page.getByTestId("person-surface");
    const conversation = surface.locator('[data-testid^="conversation-"]');
    const unreachable = surface.getByTestId("person-unreachable");

    /*
     * Exactly one of the two, and never neither: a person surface that offers
     * no conversation and no reason is the dead control this repair exists to
     * remove.
     */
    const hasConversation = (await conversation.count()) > 0;
    const hasReason = (await unreachable.count()) > 0;
    expect(hasConversation || hasReason).toBe(true);

    if (hasReason) {
      /* The reason names the person rather than being a generic disabled state. */
      const name = await page.locator("#dossier-name").innerText();
      await expect(unreachable).toContainText(name);
    }
  });

  test("opening a person reads the world and does not move the life on", async () => {
    await resetSelection();

    const before = await page.getByTestId("life-hud").innerText();

    const rail = await railPeople(page);
    await openRailPerson(page, rail[0] as string);
    await page.getByTestId("person-back-to-people").click();

    expect(await page.getByTestId("life-hud").innerText()).toBe(before);
  });
});
