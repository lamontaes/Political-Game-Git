import { expect, test, type Page } from "@playwright/test";

import { enterLife, startLife } from "./support/creator";

/**
 * UI-CORE-RELEASE owner-review captures, on the NORMAL route.
 *
 * OPT-IN, like the prototype's: it writes tracked files, and a spec that
 * rewrites them on every `npm run test:e2e` leaves a dirty tree in every other
 * lane that runs the suite.
 *
 *   UI_CORE_SCREENS=1 npx playwright test tests/e2e/ui-core-review-screens.spec.ts
 */

const ENABLED = process.env.UI_CORE_SCREENS === "1";
const OUT = "docs/plans/active/ui-core-release-screens";

async function shot(page: Page, name: string) {
  await page.waitForTimeout(300);
  await page.screenshot({
    path: `${OUT}/${name}.jpg`,
    type: "jpeg",
    quality: 60,
  });
}

test.describe("UI-CORE-RELEASE review screens", () => {
  test.skip(!ENABLED, "Set UI_CORE_SCREENS=1 to capture review screens.");
  test.setTimeout(300_000);

  test("captures the normal route with a person actually selected", async ({
    page,
  }) => {
    await page.setViewportSize({ width: 1600, height: 900 });
    await page.goto("/");
    await startLife(page, { age: 10, childhood: true });
    await enterLife(page);
    await expect(page.getByTestId("people-rail")).toBeVisible();
    await shot(page, "01-life-scene");

    const rail = await page
      .locator('[data-testid^="rail-person-"]')
      .evaluateAll((nodes) =>
        nodes.map((node) => node.getAttribute("data-testid") ?? ""),
      );

    await page.getByTestId(rail[0] as string).click();
    await expect(page.getByTestId("person-surface")).toBeVisible();
    await shot(page, "02-person-a");

    if (rail.length > 1) {
      await page.getByTestId("person-back-to-people").click();
      await page.getByTestId(rail[1] as string).click();
      await expect(page.getByTestId("person-surface")).toBeVisible();
      await shot(page, "03-person-b");
    }
  });
});
